package com.testing_web.sogeti.___global_tools.parser;

import org.junit.Test;

import com.testing_web.sogeti.___global_tools.excel_utils.ExcelUtils;
import com.testing_web.sogeti.___global_tools.excel_utils.TrataTestCasesByExcel;

public class __EjecutarEscrituraReporteExcel {
	
	 @Test 
	 public void escribirDatosEnExcel() {
		 
		 run("Dep�sitos a plazo", "Dep�sitos a plazo", "BCA");
		 run("Cuentas corrientes", "Cuentas Corrientes", "BCA");
		 run("P�lizas de Cr�dito", "P�lizas de Cr�dito", "BCA");
		 run("Cheques", "Cheques", "BCA");
		 run("Transferencias", "Transferencias", "BCA");
		 run("Traspasos", "Traspasos", "BCA");
		 run("Operatoria Banco Santander", "Operatoria Banco Santander", "BCA");
		 run("Recibos, Cobros y Pagos", "Recibos, Cobros y Pagos", "BCA");
		 run("Abono Pensiones", "Abono Pensiones", "BCA");
		 run("Embargos", "Embargos", "BCA");
		 run("Inem", "INEM", "BCA");
		 run("Blanqueo de Capitales", "Blanqueo de Capitales", "BCA");
		 run("Recaudaci�n de Tributos", "Recaudaci�n de Tributos", "BCA");

		/** CRM */
		
		 run("Planes de Pensiones", "CRM Contrataci�n - Planes de Pensiones", "CRM");
		 run("Dep�sitos a plazo", "CRM Contrataci�n - Dep�sitos a Plazo", "CRM");
		 run("Cuentas corrientes", "CRM Contrataci�n - Cuentas Corrientes", "CRM");
		 run("P�lizas de Cr�dito", "CRM Contrataci�n - P�lizas de Cr�dito", "CRM");
		 run("Avales", "CRM Contrataci�n - Avales", "CRM");
		 run("Leasings", "CRM Contrataci�n - Leasings", "CRM");
		 run("Pr�stamos", "CRM Contrataci�n - Pr�stamos", "CRM");
		 run("Seguros Generales", "CRM Contrataci�n - Seguros Generales", "CRM");

		
		/** TRM **/
		 run("Valores", "Valores", "TRM");
		 run("Avales", "Avales", "TRM");
		 run("Fondos de Inversi�n", "Fondos de Inversi�n", "TRM");
		 run("Fondos de Inversi�n Inversis", "Fondos de Inversi�n Inversis", "TRM");
		 run("Planes de Pensiones", "Planes de Pensiones", "TRM");
		 run("Seguros Generales", "Seguros Generales", "TRM");
		 run("Titulos Arquia", "Titulos Arquia", "TRM");
		 run("Seguros de Vida", "Seguros ahorro vida", "TRM");
		 run("Anticipos (Facturas, Comex, Dto Comercial, Honorarios)", "Anticipos (Facturas, Comex, Dto Comercial, Honorarios)", "TRM");
		
		
		/** CML */
		 run("Leasings", "Leasings", "CML");
		 run("Pr�stamos", "Pr�stamos", "CML");
		 run("Batches BCA", "Batches BCA", "CML");
		
		
		/** FICO **/
		 run("Arqueo de Caja", "Arqueo de Caja", "FICO");

		/** MEPA **/
		 run("Medios de pago", "Medios de Pago (VISA)", "MePa");

		
	 }
	 
	 public void run(String aplicacion, String appExcel, String modulo){
		System.out.println("APP: "+ aplicacion + ".   Modulo: " + modulo);
		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180316_114557ReportFromSpira_total", "Test Cases");
		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup(aplicacion, modulo);
		GeneradorInformeParseo_refactorizado.generar();
		setDataInReport(appExcel, modulo);
		ExcelUtils.descargar();
	 }
	 
	 public void setDataInReport(String app, String workgroup){
		 
			
			/** TCs */
			ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReportXlsx("Reporte_Macro_de_Estado_Testing_Aplicaciones_SAP_Stratesys_y_Arquia", "QA Automation Status");
			
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Dise�ados [Ready to Test]", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCasesReadyForTest));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Dise�ados [Draft](A Omitir)", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCasesOmitir));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TCases incompletos por steps", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCasesReadyForTest));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TCases totales", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCases));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TCases Automatizados Finalizados[Ready for Review]", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCasesComplete));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TCases Automatizados [Ready to Test]", workgroup, app, Integer.toString(0));
			
			/** Critical */
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Dise�ados[Ready to Test]1 - Critical", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCasesReadyForTestCritical));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Dise�ados [Draft](A Omitir) C", workgroup, app, "****");
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TCases Automatizados Finalizados[Ready for Review] C", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_totalTestCasesCompleteCritical));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TCases Automatizados Completados C", workgroup, app, Integer.toString(0));
			
			
			/** TSs */
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TSteps totales", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.testStepsTodos.size()));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TSteps NO duplicados", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_testStepsNoDuplicados));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Ptes. implementar en diccionario", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_stepsNoEntendiblesPorDiccionario));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Metodos Ptes. implementar en framework", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_metodosEntendiblesTotales));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Metodos Implementados en framework", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_metodosEntendiblesCompletadosEnFramework));
			
			/** TSs Critical */
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TSteps totales C", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.testStepsReadyForTestCritical.size()));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("TSteps NO duplicados C", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_testStepsCriticosNoDuplicados));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Ptes. implementar en diccionario C", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_stepsCriticosNoEntendiblesPorDiccionario));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Metodos Ptes. implementar en framework C", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_metodosEntendiblesCriticosAImplementarEnFramework));
			ExcelUtils.escribirNuevaCeldaSegunCabeceraModuloYAplicacion("Metodos Implementados en framework C", workgroup, app, Integer.toString(GeneradorInformeParseo_refactorizado.qtt_metodosEntendiblesCriticosCompletadosEnFramework));
			
			ExcelUtils.updateAndCloseExcel();
	 }
	
}
