package com.testing_web.sogeti.___global_tools.parser;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.xmlbeans.impl.xb.ltgfmt.impl.TestCaseImpl;
import org.trello4j.model.Board;
import org.trello4j.model.Card;
import org.trello4j.model.Checklist;
import org.trello4j.model.Checklist.CheckItem;

import com.google.common.io.Files;
import com.jacob.com.STA;
import com.testing_web.sogeti.___global_tools.excel_utils.ExcelUtils;
import com.testing_web.sogeti.___global_tools.excel_utils.TestCaseExcel;
import com.testing_web.sogeti.___global_tools.excel_utils.TrataTestCasesByExcel;
import com.testing_web.sogeti.___global_tools.parser.deep_learning.MetodoDeclarado;
import com.testing_web.sogeti.___global_tools.parser.deep_learning.ParserTestCasesFromDiccionario_deepLearning;
import com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto.ContextoObject;
import com.testing_web.sogeti.___global_tools.propiedades.Propiedades;
import com.testing_web.sogeti.___global_tools.utils_trello.TrelloCardsUtils;
import com.testing_web.sogeti.___global_tools.utils_trello.TrelloChecklistsUtils;
import com.testing_web.sogeti.___global_tools.utils_trello.TrelloItemsUtils;
import com.testing_web.sogeti.___global_tools.utils_trello.trello_objects.TrelloItemObject;
import com.testing_web.sogeti.___global_tools.utils_trello.trello_objects.TrelloObject;

import lombok.Getter;
import lombok.Setter;
import utils_selenium.FileCommon;
import utils_selenium.GenericCommon;

public class GeneradorInformeParseo_refactorizado {

	private static ParserTestCasesFromDiccionario_deepLearning parserClass;

	private static List<TestCaseExcel> testCasesFromParsedExcel;

	public static List<String> testStepsTodos;
	public static List<String> testStepsTodosReadyForTest;
	public static List<String> testStepsReadyForTestIncompletos;
	public static List<String> testStepsReadyForTestCompletos;

	public static List<String> testStepsReadyForTestCritical;
	private static List<String> testStepsReadyForTestIncompletosCritical;
	private static List<String> testStepsReadyForTestCompletosCritical;
	private static List<String> testStepsCriticalNoBloqueantes;
	

	private static List<TestCaseExcel> testCasesIncompletes;
	@Getter	private static List<TestCaseExcel> testCasesCompletosReadyForTest;
	@Getter	private static List<TestCaseExcel> testCasesCompletosReadyForTestCritical;
	@Getter	private static List<TestCaseExcel> testCasesTodosReadyForTestCritical;
	@Getter	private static List<TestCaseExcel> testCasesIncompletosReadyForTestCritical;

	@Getter	private static List<TestCaseExcel> testCaseCriticalNoBloqueantes;
	@Getter	private static List<TestCaseExcel> testCaseCriticalNoBloqueantesErroresDeDiccionario;
	@Getter	private static List<TestCaseExcel> testCaseCriticalNoBloqueantesErroresDeFramework;
	@Getter	private static List<TestCaseExcel> testCaseCriticalNoBloqueantesErroresDeFrameworkDiccionario;
	
	private static List<String> testStepsReadyForTestIncompletes;
//	private static List<TestCaseExcel> testCaseStatusCritical;
//	private static List<String> testStepsTodosCritical;

	private static List<String> testStepsDuplicados;
	private static List<String> testStepsNoDuplicados;
	private static List<String> testStepsDuplicadosForDiccionario;

	@Getter
	@Setter
	private static List<TestToImplement> testStepsToImplement;
	@Getter
	@Setter
	private static List<TestToImplement> testStepsToImplementInDiccionario;

//	private static int testStepsIncompletesForDiccionario;
//	private static int testStepsIncompletesForFramework;
//
	private static List<String> listadoDiccionariosInexistentes;
	private static List<String> listadoContextosInexistentes;

//	private static List<String> listCompletedMethodsInFramework;

	private static List<String> listTestStepsExcel;
	
//	private static int listTestCasesAffectedByTestStepsDuplicated;
	private static int listTestCasesAffectedByTestStepsCriticalDuplicated;

	private static ContextoObject contexto;

	private static String informe;

//	private static ExcelUtilsNoStatic excelMetodosUnicos;

	private static void recorreEIdentificaTestCasesIncompletos() {

		parserClass = new ParserTestCasesFromDiccionario_deepLearning();

		testCasesFromParsedExcel = new ArrayList<TestCaseExcel>();

		testStepsTodos = new ArrayList<String>();
		testStepsTodosReadyForTest = new ArrayList<String>();
		testStepsReadyForTestIncompletos = new ArrayList<String>();
		testStepsReadyForTestCompletos = new ArrayList<String>();

		testStepsReadyForTestCritical = new ArrayList<String>();
		testStepsReadyForTestIncompletosCritical = new ArrayList<String>();
		testStepsReadyForTestCompletosCritical = new ArrayList<String>();

		testCasesIncompletes = new ArrayList<TestCaseExcel>();
		testCasesCompletosReadyForTest = new ArrayList<TestCaseExcel>();
		testCasesCompletosReadyForTestCritical = new ArrayList<TestCaseExcel>();
		testCasesTodosReadyForTestCritical = new ArrayList<TestCaseExcel>();
		testCasesIncompletosReadyForTestCritical = new ArrayList<TestCaseExcel>();

		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

//		testCaseStatusCritical = new ArrayList<TestCaseExcel>();
//		testStepsTodosCritical = new ArrayList<String>();

		testStepsReadyForTestIncompletes = new ArrayList<String>();

		testStepsDuplicadosForDiccionario = new ArrayList<String>();

		testStepsToImplement = new ArrayList<TestToImplement>();
		testStepsToImplementInDiccionario = new ArrayList<TestToImplement>();

		testCaseCriticalNoBloqueantes = new ArrayList<TestCaseExcel>();
		
		testStepsCriticalNoBloqueantes = new ArrayList<String>();
		
		testCaseCriticalNoBloqueantesErroresDeDiccionario = new ArrayList<TestCaseExcel>();
		testCaseCriticalNoBloqueantesErroresDeFramework = new ArrayList<TestCaseExcel>(); ;
		testCaseCriticalNoBloqueantesErroresDeFrameworkDiccionario = new ArrayList<TestCaseExcel>();
		
//		testStepsIncompletesForDiccionario = 0;
//		testStepsIncompletesForFramework = 0;

		listTestStepsExcel = new ArrayList<String>();
		
//		listCompletedMethodsInFramework = new ArrayList<String>();

		for (TestCaseExcel test : TrataTestCasesByExcel.getParsedTestCases())
			guardarTestCaseEnListadoSiEstaIncompleto(test);

	}

	private static void guardarTestCaseEnListadoSiEstaIncompleto(TestCaseExcel test) {
		// System.out.println("-----" + test.getTestCaseName());
		if (StringUtils.contains(test.getTestCaseStatus(), "Ready for Test")) {

			TestCaseExcel testCase = getTestStepsIncompletos(test);
			if(testCase != null){
				if (!testCase.isCompleto()) {
					TestCaseExcel testCaseIncomplete = new TestCaseExcel();
	
					testCaseIncomplete.setTestCaseName(test.getTestCaseName());
					testCaseIncomplete.setTestStepList(testCase.getTestSteps());
					testCaseIncomplete.setTestCaseStatus(test.getTestCaseStatus());
					testCaseIncomplete.setSampleData(testCase.getSampleData());
					testCaseIncomplete.setExpectedResult(testCase.getExpectedResult());
					testCaseIncomplete.setTestCaseStatus(test.getTestCaseStatus());
					testCaseIncomplete.addDiccionarios(listadoDiccionariosInexistentes);
					testCaseIncomplete.addContextos(listadoContextosInexistentes);
					testCaseIncomplete.setContexto(testCase.getContexto());
					testCaseIncomplete.setTestCaseAplicacion(test.getTestCaseAplicacion());
					testCaseIncomplete.setTestCaseComponent(test.getTestCaseComponent());
					testCaseIncomplete.setTestCasePrioridad(test.getTestCasePrioridad());
	
					for (String ts : testCase.getTestSteps()) {
						testStepsReadyForTestIncompletes.add(ts);
						
						if(!testCaseIncomplete.tieneFirma() && StringUtils.contains(testCaseIncomplete.getTestCasePrioridad(), "Critical")){
							testStepsCriticalNoBloqueantes.add(ts);
						}
						
					}
	
					if (StringUtils.contains(testCaseIncomplete.getTestCasePrioridad(), "Critical")) {
						testCasesTodosReadyForTestCritical.add(testCaseIncomplete);
						testCasesIncompletosReadyForTestCritical.add(testCaseIncomplete);
						
						if(!testCaseIncomplete.tieneFirma() && StringUtils.containsIgnoreCase(testCaseIncomplete.getTestCaseStatus(), "Ready for test"))
							testCaseCriticalNoBloqueantes.add(testCaseIncomplete);

					}
	
					testCasesIncompletes.add(testCaseIncomplete);
					testCasesFromParsedExcel.add(testCaseIncomplete);
				}
	
				else {
					TestCaseExcel testCaseComplete = new TestCaseExcel();
	
					testCaseComplete.setTestCaseName(test.getTestCaseName());
					testCaseComplete.setTestStepList(testCase.getTestSteps());
					testCaseComplete.setSampleData(testCase.getSampleData());
					testCaseComplete.setExpectedResult(testCase.getExpectedResult());
					testCaseComplete.setTestCaseStatus(test.getTestCaseStatus());
					testCaseComplete.setTestCasePrioridad(test.getTestCasePrioridad());
					testCaseComplete.setTestCaseAplicacion(test.getTestCaseAplicacion());
					testCaseComplete.setCompleto(true);
	
					testCasesCompletosReadyForTest.add(testCaseComplete);
	
//					for (String ts : testCase.getTestSteps())
//						if(!testCaseComplete.tieneFirma() && StringUtils.contains(testCaseComplete.getTestCasePrioridad(), "Critical")){
//							testStepsCriticalNoBloqueantes.add(ts);
//						}
					
					if (StringUtils.contains(testCaseComplete.getTestCasePrioridad(), "Critical")) {
						testCasesTodosReadyForTestCritical.add(testCaseComplete);
						
						if(StringUtils.containsIgnoreCase(testCaseComplete.getTestCaseStatus(), "Ready for test"))
							testCasesCompletosReadyForTestCritical.add(testCaseComplete);
						
						if(!testCaseComplete.tieneFirma() && StringUtils.containsIgnoreCase(testCaseComplete.getTestCaseStatus(), "Ready for test"))
							testCaseCriticalNoBloqueantes.add(testCaseComplete);
						
					}
	
					testCasesFromParsedExcel.add(testCaseComplete);
				}
			}
	
			else {
				TestCaseExcel testCaseIncomplete = new TestCaseExcel();
	
				testCaseIncomplete.setTestCaseName(test.getTestCaseName());
				testCaseIncomplete.setTestCaseStatus(test.getTestCaseStatus());
				testCaseIncomplete.setTestCaseStatus(test.getTestCaseStatus());
				testCaseIncomplete.setExpectedResult(test.getExpectedResult());
				testCaseIncomplete.setTestCasePrioridad(test.getTestCasePrioridad());
				testCaseIncomplete.setTestCaseAplicacion(test.getTestCaseAplicacion());
				testCaseIncomplete.addContextos(new ArrayList<>());
	
				testCasesIncompletes.add(testCaseIncomplete);
				testCasesFromParsedExcel.add(testCaseIncomplete);
	
			}
		}
	}

	private static List<String> testStepsEntendiblesByMethods = new ArrayList<String>();
	private static List<String> testStepsEntendiblesByMethodsCritical = new ArrayList<String>();
	
	private static List<String> testStepsCriticalNoBloqueantesEntendibles = new ArrayList<String>();
	
	@SuppressWarnings("static-access")
	private static TestCaseExcel getTestStepsIncompletos(TestCaseExcel test) {

		listadoDiccionariosInexistentes = new ArrayList<String>();
		listadoContextosInexistentes = new ArrayList<String>();

		List<String> listTestSteps = new ArrayList<String>();
		List<String> listTestData = new ArrayList<String>();
		
		List<String> listTestSteps_tmp_criticalNoBloqueantes = new ArrayList<String>();
//		List<String> listTestSteps_tmp_criticalNoBloqueantesCompleted = new ArrayList<String>();
		
		int testStepsIncompletesForFramework_tmp = 0;
		int testStepsIncompletesForDiccionario_tmp = 0;
		// int listadoContextosInexistentes_tmp = 0;
		
		
		// si tiene firma los descartamos
		boolean tieneFirma = false;
		
		String priority = test.getTestCasePrioridad();
		
		System.out.println("TEST:: " + test.getTestCaseName());
		
		for (int a = 0; a < test.getTestSteps().size(); a++) {

			String ts = test.getTestSteps().get(a);
			String ts_tmp = "";
			String td = test.getSampleData().get(a);
			String e = test.getExpectedResult().get(a);

			// TODO
// 			meterlo si solemnte se quiere filtrar por TestCases que no tengan firma y sean criticos
//			PARA TIRAR REPORTE DE EXCEL SE HA DE ''DESCOMENTAR''
			if(StringUtils.contains(ts, "Firma") && 
					(!StringUtils.containsIgnoreCase(ts, "verificar") || !StringUtils.containsIgnoreCase(ts, "icono"))){
				tieneFirma = true;
				break;
			}
			
			listTestStepsExcel.add(ts);
			
			contexto = parserClass.definirContextObject(ts, td, e);

			boolean existeInDiccionario = false;
			boolean existeInFramework = false;
			boolean stepEntendible = false;
			try {
				if (parserClass.existeContexto()) {
					if (parserClass.existeStepsClass()) {
						if (parserClass.excelTestStepActualTieneVariosSteps(ts)) {

							for (String excel_step_extracted : parserClass.extrarPasoDeExcelStep(ts)) {

								if (StringUtils.equalsIgnoreCase(excel_step_extracted,
										"Hay mas de 2 pasos en una celda o se repiten 2 pasos iguales. Esta casuistica no se puede tratar. \n"
												+ ts)) {
									listTestSteps.add(contexto.app + "___" + contexto.contexto
											+ "__EXCESO DE PASOS EN LA CELDA> " + ts);
									listTestData.add(td);
									ts_tmp = contexto.app + "___" + contexto.contexto+ "__EXCESO DE PASOS EN LA CELDA> " + ts;
								} else {

									existeInDiccionario = parserClass
											.existeEstructuraDePasoEnDiccionario(excel_step_extracted);
									existeInFramework = false;

									if (!existeInDiccionario) {
										listTestSteps.add(contexto.app + "___" + contexto.contexto + "__DICIONARIO> "
												+ excel_step_extracted);
										ts_tmp = contexto.app + "___" + contexto.contexto + "__DICIONARIO> " + excel_step_extracted;
//										testStepsIncompletesForDiccionario++;
										testStepsIncompletesForDiccionario_tmp++;
										listTestData.add(td);
									} else {
										// aqui he de recoger los metodos que se
										// declaran
										// y luego recorro un FOR para ver si
										// realmente existen en la clase
										// porque un STEP puede contener N steps
										// reales dentro del framwork
										parserClass.getMetodoDeclarado(excel_step_extracted, td);

										if (parserClass.listadoMetodosTmp.size() != 0) {
											for (MetodoDeclarado metodo : parserClass.listadoMetodosTmp) {
												existeInFramework = parserClass
														.getMetodoClaseSegunTestStep(metodo.getLlamadaMetodo()) != null;
												if (!existeInFramework)
													break;
											}
										} else
											existeInFramework = false;

									}

									if (existeInDiccionario && !existeInFramework) {
										listTestSteps.add(contexto.app + "___" + contexto.contexto + "__FRAMEWORK> "
												+ excel_step_extracted);
										ts_tmp = contexto.app + "___" + contexto.contexto + "__FRAMEWORK> " + excel_step_extracted;
//										testStepsIncompletesForFramework++;
										testStepsIncompletesForFramework_tmp++;
										listTestData.add(td);
									}

									// el step existe en el framework, hay que
									// informarlo en el Excel
									else if (existeInDiccionario && existeInFramework) {
										listTestSteps.add(contexto.app + "___" + contexto.contexto + "__IMPLEMENTADO> "
												+ excel_step_extracted);
										ts_tmp = contexto.app + "___" + contexto.contexto + "__IMPLEMENTADO> " + excel_step_extracted;
										listTestData.add(td);
										stepEntendible = true;
									}
								}
							}

						} else {

							existeInDiccionario = parserClass.existeEstructuraDePasoEnDiccionario(ts);
							existeInFramework = false;

							if (!existeInDiccionario) {
								listTestSteps.add(contexto.app + "___" + contexto.contexto + "__DICIONARIO> " + ts);
								ts_tmp = contexto.app + "___" + contexto.contexto + "__DICIONARIO> " + ts;
//								testStepsIncompletesForDiccionario++;
								testStepsIncompletesForDiccionario_tmp++;
								listTestData.add(td);
								
							} else {
								parserClass.getMetodoDeclarado(ts, td);

								if (parserClass.listadoMetodosTmp.size() != 0) {
									for (MetodoDeclarado metodo : parserClass.listadoMetodosTmp) {
										existeInFramework = parserClass
												.getMetodoClaseSegunTestStep(metodo.getLlamadaMetodo()) != null;
										if (!existeInFramework)
											break;
									}
								} else
									existeInFramework = false;
							}

							if (existeInDiccionario && !existeInFramework) {
								listTestSteps.add(contexto.app + "___" + contexto.contexto + "__FRAMEWORK> " + ts);
								ts_tmp = contexto.app + "___" + contexto.contexto + "__FRAMEWORK> " + ts;
//								testStepsIncompletesForFramework++;
								testStepsIncompletesForFramework_tmp++;
								listTestData.add(td);
							}

							// el step existe en el framework, hay que
							// informarlo en el Excel
							else if (existeInDiccionario && existeInFramework) {

								listTestSteps.add(contexto.app + "___" + contexto.contexto + "__IMPLEMENTADO> " + ts);
								ts_tmp = contexto.app + "___" + contexto.contexto + "__IMPLEMENTADO> " + ts;
								listTestData.add(td);
//								testStepsEntendiblesByMethods.add(contexto.app + "___" + contexto.contexto + "__IMPLEMENTADO> "
//										+ ts);
								stepEntendible = true;
							}
						}

						if(StringUtils.contains(priority, "Critical") && StringUtils.contains(test.getTestCaseStatus(), "Ready for Test"))
							listTestSteps_tmp_criticalNoBloqueantes.add(ts_tmp);
						
						
						if(stepEntendible){
							testStepsEntendiblesByMethods.add(ts);
							
							if(StringUtils.contains(priority, "Critical")){
								testStepsEntendiblesByMethodsCritical.add(ts);
//								testStepsCriticalNoBloqueantesEntendibles.add(ts_tmp);
							}
							
						}
						
					} else {
						addDiccionarioInexistente(test, parserClass.contextObject);
					}

				} else {
					addContextoInexistente(test, parserClass.contextObject);
					// TODO
				}

			} catch (IndexOutOfBoundsException es) {
				// es.printStackTrace();
			}

		}
		
		
		boolean tieneFirma_tmp = false;
		// recorro los que he 
		for(String step : listTestSteps_tmp_criticalNoBloqueantes){
			if(StringUtils.containsIgnoreCase(step, "Firma")){
				tieneFirma_tmp = true;
				break;
			}
		}
		
		if(!tieneFirma_tmp)
			for(String ts : listTestSteps_tmp_criticalNoBloqueantes){
				if(StringUtils.contains(ts, "IMPLEMENTADO"))
					testStepsCriticalNoBloqueantesEntendibles.add(ts);
				
//				testStepsCriticalNoBloqueantes.add(ts);
			}
		

		if(!tieneFirma)
			if (testStepsIncompletesForDiccionario_tmp > 0 || testStepsIncompletesForFramework_tmp > 0
					|| listadoContextosInexistentes.size() > 0)
				return new TestCaseExcel(null, listTestSteps, listTestData, false, contexto.contexto);
			else
				return new TestCaseExcel(null, listTestSteps, listTestData, true, contexto.contexto);
		else	
			return null;
	}

	private static void addContextoInexistente(TestCaseExcel test, ContextoObject co) {

		if (co != null) {
			String contexto = co.contexto;

			if (!listadoContextosInexistentes.contains(contexto))
				listadoContextosInexistentes.add(contexto);

		} else {
			listadoContextosInexistentes.add(test.getTestCaseName());
		}
	}

	private static void addDiccionarioInexistente(TestCaseExcel test, ContextoObject co) {
		String diccionarioClass = StringUtils.capitalize(co.contexto)
				+ StringUtils.capitalize(StringUtils.replace(co.app, ".bp", "")) + "Diccionario";

		if (co != null) {
			if (!listadoDiccionariosInexistentes.contains(diccionarioClass)) {
				listadoDiccionariosInexistentes.add(diccionarioClass);
			}
		} else {
			listadoDiccionariosInexistentes.add(test.getTestCaseName());
		}
	}

	private static boolean existenTestCasesIncompletos() {
		return testCasesIncompletes.size() > 0;
	}

	private static Integer getCountTestCases() {
		return TrataTestCasesByExcel.getNumTestCases();
	}

//	private static Integer getCountTestCasesCompletos_ReadyForTestPriorityCritical() {
//		return getCountTestCasesAllByStatusAndPriority("Ready for test", "Critical", 2);
//	}

//	private static Integer getCountTestCasesIncompletos_ReadyForTestPriorityCritical() {
//		return getCountTestCasesAllByStatusAndPriority("Ready for test", "Critical", 1);
//	}

	private static Integer getCountTestCasesTodos_ReadyForTestPriorityCritical() {
		return getCountTestCasesAllByStatusAndPriority("Ready for test", "Critical", 0);
	}

//	private static Integer getCountTestCasesTodosPriorityCritical() {
//		return getCountTestCasesAllByStatusAndPriority(null, "Critical", 0);
//	}

	private static Integer getCountTestCasesAllByStatusAndPriority(String status, String priority, int mode) {
		int count = 0;

		boolean tieneStatus = (status != null ? true : false);

		List<TestCaseExcel> testcases = null;

		if (mode == 0)
			testcases = testCasesFromParsedExcel;

		else if (mode == 1)
			testcases = testCasesIncompletes;

		else if (mode == 2)
			testcases = testCasesCompletosReadyForTest;

		for (TestCaseExcel testCase : testcases) {
//			System.out.print("-- " + testCase.getTestCaseName());
			if (tieneStatus) {
				if (StringUtils.containsIgnoreCase(testCase.getTestCaseStatus(), status))
					if (StringUtils.containsIgnoreCase(testCase.getTestCasePrioridad(), priority))
						count++;

			} else

			if (StringUtils.containsIgnoreCase(testCase.getTestCasePrioridad(), priority))
				count++;

		}
		return count;
	}

//	private static Integer getCountTestCasesPriority(String priority) {
//		int count = 0;
//
//		for (TestCaseExcel testCase : testCasesFromParsedExcel)
//			if (StringUtils.containsIgnoreCase(testCase.getTestCaseStatus(), "Ready for Test"))
//				if (StringUtils.containsIgnoreCase(testCase.getTestCasePrioridad(), priority))
//					count++;
//
//		return count;
//	}

	private static Integer getCountTestCasesStatusDraft() {
		return getCountTestCasesStatus("Draft");
	}

	private static Integer getCountTestCasesStatusObsolete() {
		return getCountTestCasesStatus("Obsolete");
	}

	private static Integer getCountTestCasesStatusObsoleto() {
		return getCountTestCasesStatus("Obsoleto");
	}

	private static Integer getCountTestCasesStatusRedyForReview() {
		return getCountTestCasesStatus("Ready for Review");
	}

	private static Integer getCountTestCasesStatusRedyForTest() {
		return getCountTestCasesStatus("Ready for Test");
	}

	private static Integer getCountTestCasesStatus(String status) {

		int count = 0;

		for (TestCaseExcel testCase : testCasesFromParsedExcel)
			if (StringUtils.containsIgnoreCase(testCase.getTestCaseStatus(), status))
				count++;

		return count;

	}

//	private static Integer getCountTestStepsCritical() {
//
//		int count = 0;
//
//		for (TestCaseExcel test : testCasesFromParsedExcel)
//			if (StringUtils.contains(test.getTestCaseStatus(), "Ready for Test"))
//				if (StringUtils.containsIgnoreCase(test.getTestCasePrioridad(), "Critical")) {
//					testCaseStatusCritical.add(test);
//					for (String ts : test.getTestSteps()) {
//						testStepsTodosCritical.add(ts);
//						count = count + 1;
//					}
//
//				}
//
//		return count;
//	}

	private static Integer getCountTestStepsCriticalNoDuplicated() {

		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsReadyForTestCritical)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}

		return testStepsNoDuplicados.size();

	}
	
	private static Integer getCountTestStepsCriticalNoBloqueantesNoDuplicados() {
		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsCriticalNoBloqueantes)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}

		return testStepsNoDuplicados.size();
		
	}
	
	private static Integer getCountTestCasesCriticalNoBloqueantesErroresDiccionario(){
		
		int count_error_diccionario = 0;
		int res = 0;
		int nobloc = 0;
		for(int a = 0; a < testCaseCriticalNoBloqueantes.size(); a++){
			
			if(!testCaseCriticalNoBloqueantes.get(a).isCompleto()){
				TestCaseExcel e = testCaseCriticalNoBloqueantes.get(a);
				System.out.println("TEST: " + e.getTestCaseName());
				nobloc++;
				for(String step : e.getTestSteps()){
					System.out.println("Step: " + step);
					if(StringUtils.containsIgnoreCase(step, "DICIONARIO")){
						count_error_diccionario++;
					}
				
					if(StringUtils.containsIgnoreCase(step, "FRAMEWORK")){
						count_error_diccionario = 0;
						break;
					}
					
				}
				
				if(count_error_diccionario != 0){
					res++;
					testCaseCriticalNoBloqueantes.remove(a);
					a--;
				}
				
				

				System.out.println("Error diccionario: "  + (count_error_diccionario != 0));
				count_error_diccionario= 0;
			}
		}
				
		return res;
	}
	
	private static Integer getCountTestCasesCriticalNoBloqueantesErroresFramework(){
		
		int count_error_framework = 0;
		int res = 0;
		
		for(int a = 0; a < testCaseCriticalNoBloqueantes.size(); a++){
			if(!testCaseCriticalNoBloqueantes.get(a).isCompleto()){
				
				for(String step : testCaseCriticalNoBloqueantes.get(a).getTestSteps()) {
					
					if(StringUtils.containsIgnoreCase(step, "FRAMEWORK")){
						count_error_framework++;
					}
						
					if(StringUtils.containsIgnoreCase(step, "DICIONARIO")){
						count_error_framework = 0;
						break;
					}
					
				}
				
				if(count_error_framework != 0){
					res++;
					testCaseCriticalNoBloqueantes.remove(a);
					a--;
				}
				
				System.out.println("Error framework: "  + (count_error_framework != 0));
				count_error_framework= 0;
			}
		}	
			
		
		return res;
	}

	private static Integer getCountTestCasesCriticalNoBloqueantesErroresFrameworkDiccionario(){
		
		int count_error_framework = 0;
		int count_error_diccionario = 0;
		int count_res = 0;
		
		for(int a = 0; a < testCaseCriticalNoBloqueantes.size(); a++){
			
			if(!testCaseCriticalNoBloqueantes.get(a).isCompleto()){
			
				TestCaseExcel test = testCaseCriticalNoBloqueantes.get(a);
				
				for(String step : testCaseCriticalNoBloqueantes.get(a).getTestSteps()){
					
					if(StringUtils.containsIgnoreCase(step, "FRAMEWORK"))
						count_error_framework++;
				
					if(StringUtils.containsIgnoreCase(step, "DICIONARIO"))
						count_error_diccionario++;
									
				}
				
				if(count_error_framework != 0 && count_error_diccionario != 0){
					count_res++;
					testCaseCriticalNoBloqueantes.remove(a);
					a--;
				}
				
				count_error_framework = 0;
				count_error_diccionario = 0;
				
			} 
			
		}
		
//		int a = 0;
//		for(TestCaseExcel t : testCaseCriticalNoBloqueantes){
//			if(t.isCompleto() && StringUtils.containsIgnoreCase(t.getTestCaseStatus(), "Ready for test")){
//				a++;
//			}
//		}
		
		return count_res;
	}
	
//	private static Integer getCountTestStepsIncomplete() {
//		Integer count = 0;
//		for (TestCaseExcel test : testCasesIncompletes)
//			if (StringUtils.contains(test.getTestCaseStatus(), "Ready for Test"))
//				count += test.getTestSteps().size();
//
//		return count;
//	}

//	private static Integer getCountTestStepsIncompleteCritical() {
//		Integer count = 0;
//		for (TestCaseExcel test : testCasesIncompletes)
//			if (StringUtils.contains(test.getTestCaseStatus(), "Ready for Test"))
//				if (StringUtils.contains(test.getTestCasePrioridad(), "Critical"))
//					count += test.getTestSteps().size();
//
//		return count;
//	}

	private static void saveAllTestStepsFromTestCases(List<TestCaseExcel> testCases) {
		for (TestCaseExcel tc : testCases) {

			for (String ts : tc.getTestSteps())
				testStepsTodos.add(ts);

			if (StringUtils.contains(tc.getTestCaseStatus(), "Ready for Test"))

				// recojo "Ready for test" y "criticos"

				if (StringUtils.contains(tc.getTestCasePrioridad(), "Critical")) {
					for (String ts : tc.getTestSteps()) {

//						System.out.println("TS: " + ts);
						testStepsReadyForTestCritical.add(ts);

						if (!tc.isCompleto())
							testStepsReadyForTestIncompletosCritical.add(ts);

						if (tc.isCompleto())
							testStepsReadyForTestCompletosCritical.add(ts);
					}

				}

			// recojo "ready for test"
			for (String ts : tc.getTestSteps()) {

				testStepsTodosReadyForTest.add(ts);

				if (!tc.isCompleto())
					testStepsReadyForTestIncompletos.add(ts);

				if (tc.isCompleto())
					testStepsReadyForTestCompletos.add(ts);
			}

		}
	}

	// private static void saveAllTestStepsReadyForTest(List<TestCaseExcel>
	// testCases){
	// if(testStepsReadyForTest != null)
	// return;
	// else{
	//
	// testStepsReadyForTest = new ArrayList<String>();
	//
	// for(TestCaseExcel tc : testCases)
	// if(StringUtils.contains(tc.getTestCaseStatus(), "Ready for Test"))
	// for(String ts : tc.getTestSteps())
	// testStepsReadyForTest.add(ts);
	//
	// }
	//
	// }
	//
	// private static void saveAllTestSteps(List<TestCaseExcel> testCases) {
	//
	// if(testStepsTodos != null)
	// return;
	// else{
	//
	// testStepsTodos = new ArrayList<String>();
	//
	// for(TestCaseExcel tc : testCases)
	// for(String ts : tc.getTestSteps())
	// testStepsTodos.add(ts);
	//
	// }
	//
	// }

	private static void saveAllTestStepsDuplicated() {

		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsReadyForTestIncompletes)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}

	}

	private static void saveAllTestStepsDuplicatedCritical() {

		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsReadyForTestCritical)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}

	}

//	private static Integer getCountTestStepsCriticalComplete() {
//		int count = 0;
//
//		for (TestCaseExcel t : testCaseStatusCritical) {
//			if (StringUtils.contains(t.getTestCasePrioridad(), "Critical"))
//				count += t.getQttMethodsCompleteInFramework(parserClass);
//		}
//
//		return count;
//	}

	// contador de metodos completos en framework.
//	private static Integer getCountTestStepsFromFrameworkComplete() {
//
//		int count = 0;
//
//		for (TestCaseExcel t : testCasesFromParsedExcel)
//			count += t.getQttStepsCompleteInFramework(parserClass);
//
//		return count;
//	}

//	private static Integer getCountTestStepsFromFrameworkIncomplete() {
//		int count = 0;
//
//		for (TestCaseExcel t : testCasesFromParsedExcel)
//			count += t.getQttStepsIncompleteInFramework(parserClass);
//
//		return count;
//	}

//	private static Integer getCountTestStepsIncompleteDuplicate() {
//		int count = 0;
//
//		int test = 0;
//
//		for (TestCaseExcel t : testCasesIncompletes) {
//			if (StringUtils.contains(t.getTestCaseStatus(), "Ready for Test")) {
//				count += t.getQttMethodsCompleteDuplicatedInFramework(parserClass);
//				if (count > 0)
//					test++;
//			}
//
//		}
//
//		listTestCasesAffectedByTestStepsDuplicated = 0;
//		listTestCasesAffectedByTestStepsDuplicated = listTestCasesAffectedByTestStepsDuplicated + test;
//
//		testStepsToImplement = new ArrayList<TestToImplement>(); // despues de
//																	// este
//																	// "for" se
//																	// han
//																	// instanciado
//																	// los
//																	// metodos
//																	// duplicados.
//																	// lo
//																	// reinstancio
//																	// o no?
//		return count;
//	}

	public static boolean isTestCaseComplete(TestCaseExcel testExpected) {
		boolean completo = false;

		for (TestCaseExcel t : testCasesCompletosReadyForTest)
			if (StringUtils.contains(t.getTestCaseStatus(), "Ready for Test"))
				if (StringUtils.equals(t.getTestCaseName(), testExpected.getTestCaseName()))
					completo = true;

		return completo;
	}

//	private static Integer getCountTestStepsCompleteDuplicate() {
//		int count = 0;
//
//		int test = 0;
//
//		for (TestCaseExcel t : testCasesCompletosReadyForTest) {
//			if (StringUtils.contains(t.getTestCaseStatus(), "Ready for Test")) {
//				count += t.getQttMethodsCompleteDuplicatedInFramework(parserClass);
//				if (count > 0)
//					test++;
//			}
//
//		}
//
//		listTestCasesAffectedByTestStepsDuplicated = listTestCasesAffectedByTestStepsDuplicated + test;
//
//		testStepsToImplement = new ArrayList<TestToImplement>(); // despues de
//																	// este
//																	// "for" se
//																	// han
//																	// instanciado
//																	// los
//																	// metodos
//																	// duplicados.
//																	// lo
//																	// reinstancio
//																	// o no?
//		return count;
//	}

	private static Integer getCountTestStepsCriticalCompleteDuplicate() {
		int count = 0;

		int test = 0;

		for (TestCaseExcel t : testCasesCompletosReadyForTest) {
			if (StringUtils.contains(t.getTestCaseStatus(), "Ready for Test")) {
				if (StringUtils.containsIgnoreCase(t.getTestCasePrioridad(), "Critical")) {
					count += t.getQttMethodsCompleteDuplicatedInFramework(parserClass);
					if (count > 0)
						test++;
				}
			}

		}
		listTestCasesAffectedByTestStepsCriticalDuplicated = 0;
		listTestCasesAffectedByTestStepsCriticalDuplicated = listTestCasesAffectedByTestStepsCriticalDuplicated + test;

		testStepsToImplement = new ArrayList<TestToImplement>(); // despues de
																	// este
																	// "for" se
																	// han
																	// instanciado
																	// los
																	// metodos
																	// duplicados.
																	// lo
																	// reinstancio
																	// o no?
		return count;
	}

	private static Integer getCountTestStepsCriticalIncompleteDuplicate() {
		int count = 0;

		int test = 0;

		for (TestCaseExcel t : testCasesIncompletes) {
			if (StringUtils.contains(t.getTestCaseStatus(), "Ready for Test")) {
				if (StringUtils.containsIgnoreCase(t.getTestCasePrioridad(), "Critical")) {
					count += t.getQttMethodsCompleteDuplicatedInFramework(parserClass);
					if (count > 0)
						test++;
				}
			}

		}

		listTestCasesAffectedByTestStepsCriticalDuplicated = listTestCasesAffectedByTestStepsCriticalDuplicated + test;

		testStepsToImplement = new ArrayList<TestToImplement>(); // despues de
																	// este
																	// "for" se
																	// han
																	// instanciado
																	// los
																	// metodos
																	// duplicados.
																	// lo
																	// reinstancio
																	// o no?
		return count;
	}

	private static void getCountTestStepsDuplicados() {
		saveAllTestStepsDuplicated();
	}

	private static void getCountTestStepsDuplicadosYNoDuplicadosCritical() {
		saveAllTestStepsDuplicatedCritical();
	}
	
	private static void getCountTestStepsDuplicadosYNoDuplicadosCriticalNoBloqueantes() {
		saveAllTestStepsDuplicatedCompletedCriticalNoBloqueantes();
	}
	
	private static void getCountTestStepsDuplicadosYNoDuplicadosCriticalNoBloqueantes1() {
		saveAllTestStepsNoDuplicatedCriticalNoBloqueantes();
	}
	
	private static void saveAllTestStepsDuplicatedCompleted() {

		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsEntendiblesByMethods)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}

	}
	
	private static void saveAllTestStepsDuplicatedCompletedCritical() {
		
		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsEntendiblesByMethodsCritical)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}
	}
	
	private static Integer getCountTestStepsNoDuplicadosOfCompletedCritical() {
		saveAllTestStepsDuplicatedCompletedCritical();
		
		int res = testStepsNoDuplicados.size();
		
		testStepsNoDuplicados = new ArrayList<String>();
		testStepsDuplicados = new ArrayList<String>();
		
		return res;
	}
	
	private static void saveAllTestStepsDuplicatedCompletedCriticalNoBloqueantes() {
		
		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsCriticalNoBloqueantesEntendibles)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}
	}
	
	private static void saveAllTestStepsNoDuplicatedCriticalNoBloqueantes() {
		
		testStepsDuplicados = new ArrayList<String>();
		testStepsNoDuplicados = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : testStepsCriticalNoBloqueantes)

			if (tmp_testSteps.contains(ts)) {
				testStepsDuplicados.add(ts);
			} else {
				tmp_testSteps.add(ts);
				testStepsNoDuplicados.add(ts);
			}
	}
	
	private static Integer getCountTestStepsNoDuplicadosOfCompletedCriticalNoBloqueantes() {
		saveAllTestStepsDuplicatedCompletedCriticalNoBloqueantes();
		
		int res = testStepsNoDuplicados.size();
		
		testStepsNoDuplicados = new ArrayList<String>();
		testStepsDuplicados = new ArrayList<String>();
		
		return res;
	}
	
	private static Integer getCountTestStepsNoDuplicadosOfCompleted() {
		
		saveAllTestStepsDuplicatedCompleted();
		
		int res = testStepsNoDuplicados.size();
		
		testStepsNoDuplicados = new ArrayList<String>();
		testStepsDuplicados = new ArrayList<String>();
		
		return res;
	}

	private static Integer getCountTestStepsNoDuplicados() {

		saveAllTestStepsDuplicated();

		return testStepsNoDuplicados.size();
	}

	private static Integer getCountTestStepsByDiccionario() {

		int tsd_diccionario = 1;

		getCountTestStepsDuplicados();

		for (String tsd : testStepsNoDuplicados)
			if (StringUtils.containsIgnoreCase(tsd, "dicionario")) {
				tsd_diccionario++;
				testStepsDuplicadosForDiccionario.add(tsd);
			} else if (StringUtils.containsIgnoreCase(tsd, "framework")) {

			}

		return tsd_diccionario;
	}
	
	private static Integer getCountTestStepsCriticosNoBloqueantesByDiccionario() {
		int tsd_diccionario = 1;

		testStepsDuplicadosForDiccionario = new ArrayList<String>();

		getCountTestStepsDuplicadosYNoDuplicadosCriticalNoBloqueantes1();

		for (String tsd : testStepsNoDuplicados)
			if (StringUtils.containsIgnoreCase(tsd, "dicionario")) {
				tsd_diccionario++;
				testStepsDuplicadosForDiccionario.add(tsd);
			}

		return tsd_diccionario;
	}

	private static Integer getCountTestStepsCriticosByDiccionario() {
		int tsd_diccionario = 1;

		testStepsDuplicadosForDiccionario = new ArrayList<String>();

		getCountTestStepsDuplicadosYNoDuplicadosCritical();

		for (String tsd : testStepsNoDuplicados)
			if (StringUtils.containsIgnoreCase(tsd, "dicionario")) {
				tsd_diccionario++;
				testStepsDuplicadosForDiccionario.add(tsd);
			}

		return tsd_diccionario;
	}
	

//	private static Integer getCountTestStepsWithParametersWithNulls() {
//		int count_parametros_with_nulls = 0;
//
//		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
//			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {
//
//				TestCaseExcel test = testCasesFromParsedExcel.get(a);
//
//				List<String> data = test.getSampleData();
//
//				for (int e = 0; e < data.size(); e++) {
//
//					String strdata = data.get(e);
//
//					if (!StringUtils.equals(strdata, "\n"))
//						if (parserClass.tieneParametrosSampleData(strdata)) {
//
//							List<String> parametros_en_sampleData = parserClass
//									.devolverParametrosSiTieneSampleDataConClave(strdata);
//
//							for (String pesd : parametros_en_sampleData) {
//								if (StringUtils.contains(pesd, "\"\"") || StringUtils.equals(pesd, "\n")) {
//									// System.out.println("*****");
//									// System.out.println("");
//									// System.out.println(testCasesIncompletes.get(a).getTestCaseName());
//									// System.out.println("");
//									// System.out.println(testCasesIncompletes.get(a).getTestSteps().get(e));
//									// System.out.println("");
//									// System.out.println(pesd);
//									count_parametros_with_nulls++;
//									break;
//								}
//							}
//						}
//				}
//			}
//		}
//
//		return count_parametros_with_nulls;
//	}

	private static Integer getCountTestStepsWithApunteContableWord() {

		int count_ts_apuntecontable = 0;

		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {

				List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();

				for (int e = 0; e < steps.size(); e++)
					if (StringUtils.containsIgnoreCase(steps.get(e), "apunte contable") || StringUtils.containsIgnoreCase(steps.get(e), "BCA_Apunte_Contable_Libro_Mayor")) {
						count_ts_apuntecontable++;
						break;
					}

			}
		}

		return count_ts_apuntecontable;
	}
	
	private static Integer getCountTestStepsWithApunteContableWordOnlyRefactored() {

		int count_ts_apuntecontable = 0;

		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {

				List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();

				for (int e = 0; e < steps.size(); e++)
					if (StringUtils.containsIgnoreCase(steps.get(e), "BCA_Apunte_Contable_Libro_Mayor")) {
						count_ts_apuntecontable++;
						break;
					}

			}
		}

		return count_ts_apuntecontable;
	}
	
	private static Integer getCountTestStepsWithApunteContableConFirma() {
		int count_ts_apuntecontable = 0;
	
		
		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {

				int tmp_firma = 0;
				int tmp_apunte = 0;
				
				List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();

				for (int e = 0; e < steps.size(); e++){

					if (StringUtils.containsIgnoreCase(steps.get(e), "BCA_Apunte_Contable_Libro_Mayor") || StringUtils.containsIgnoreCase(steps.get(e), "Verificar el apunte contable") ) 
						tmp_apunte++;
					if (StringUtils.containsIgnoreCase(steps.get(e), "Firmar")) 
						tmp_firma++;
				
				}
				
				
				if(tmp_firma != 0 && tmp_apunte != 0)
					count_ts_apuntecontable++;				

			}
		}

		return count_ts_apuntecontable;
	}
	
	private static Integer getCountTestStepsWithApunteContableWordTcCompleted() {

		int count_ts_apuntecontable = 0;

		for (int a = 0; a < testCasesCompletosReadyForTest.size(); a++) {

			List<String> steps = testCasesCompletosReadyForTest.get(a).getTestSteps();

			for (int e = 0; e < steps.size(); e++)
				if (StringUtils.containsIgnoreCase(steps.get(e), "apunte contable") || StringUtils.containsIgnoreCase(steps.get(e), "BCA_Apunte_Contable_Libro_Mayor")) {
					count_ts_apuntecontable++;
					break;
				}

		
		}

		return count_ts_apuntecontable;
	}
	

//	private static Integer getCountTestStepsCriticalWithApunteContableWord() {
//		int count_ts_apuntecontable = 0;
//
//		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
//			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {
//
//				if (StringUtils.containsIgnoreCase(testCasesFromParsedExcel.get(a).getTestCasePrioridad(),
//						"Critical")) {
//					List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();
//
//					for (int e = 0; e < steps.size(); e++)
//						if (StringUtils.contains(steps.get(e), "DICIONARIO"))
//							if (StringUtils.containsIgnoreCase(steps.get(e), "apunte contable")) {
//								count_ts_apuntecontable++;
//								break;
//							}
//				}
//			}
//		}
//
//		return count_ts_apuntecontable;
//	}

	private static Integer getCountTestCasesReadyForTestWithProcesoFirmaWord() {

		int count_ts_apuntecontable = 0;

		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {

				List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();

				for (int e = 0; e < steps.size(); e++) {
					if (StringUtils.containsIgnoreCase(steps.get(e), "Firma")) {
						count_ts_apuntecontable++;
						break;
					}
				}

			}
		}

		return count_ts_apuntecontable;
	}
	
	private static Integer getCountTestCasesReadyForTestCriticalWithProcesoFirmaWord() {

		int count_ts_firma = 0;

		for (int a = 0; a < testCasesTodosReadyForTestCritical.size(); a++) {
			if (StringUtils.contains((testCasesTodosReadyForTestCritical.get(a).getTestCaseStatus()), "Ready for Test")) {

				List<String> steps = testCasesTodosReadyForTestCritical.get(a).getTestSteps();

				for (int e = 0; e < steps.size(); e++) {
					if (StringUtils.containsIgnoreCase(steps.get(e), "Firma")) {
						count_ts_firma++;
						break;
					}
				}

			}
		}

		return count_ts_firma;
	}

//	private static Integer getCountTestStepsCriticalWithProcesoFirmaWord() {
//
//		int count_ts_apuntecontable = 0;
//
//		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
//			if (StringUtils.contains((testCasesFromParsedExcel.get(a).getTestCaseStatus()), "Ready for Test")) {
//				if (StringUtils.containsIgnoreCase(testCasesFromParsedExcel.get(a).getTestCasePrioridad(),
//						"Critical")) {
//
//					List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();
//
//					for (int e = 0; e < steps.size(); e++) {
//						if (StringUtils.contains(steps.get(e), "FRAMEWORK"))
//							if (StringUtils.containsIgnoreCase(steps.get(e), "Llamar al setup \"Firma")) {
//								count_ts_apuntecontable++;
//								break;
//							}
//					}
//				}
//			}
//		}
//
//		return count_ts_apuntecontable;
//	}

	private static Integer getCountMethodsCriticosEntendiblesToImplementInFramework() {
		int tsd_framework = 0;

		// se recorren y se dividen los metodos por cada Step (ya que pueden
		// haber Steps que tengan mas de un metodo)

		for (int a = 0; a < testCasesTodosReadyForTestCritical.size(); a++) {
			if (StringUtils.contains(testCasesTodosReadyForTestCritical.get(a).getTestCaseStatus(), "Ready for Test")) {

				String testCaseName = testCasesTodosReadyForTestCritical.get(a).getTestCaseName();
				List<String> steps = testCasesTodosReadyForTestCritical.get(a).getTestSteps();
				List<String> data = testCasesTodosReadyForTestCritical.get(a).getSampleData();

				for (int e = 0; e < steps.size(); e++) {

					String td = "";
					String ts = GenericCommon.removeHtmTags(GenericCommon.removeHexaChars(steps.get(e)));
					String app = StringUtils.split(ts, "__")[0];
					String contexto = StringUtils.split(ts, "__")[1];

					if (!StringUtils.contains(ts, "DICIONARIO") && !StringUtils.contains(ts, "IMPLEMENTADO")) {

						try {
							td = data.get(e);
						} catch (IndexOutOfBoundsException ea) {

						}

						String step_simplificado = StringUtils.split(ts, ">")[1];
						step_simplificado = StringUtils.substring(step_simplificado, 1, step_simplificado.length());

						parserClass.getMetodoDeclarado(ts, td);

						List<MetodoDeclarado> metodos = parserClass.getCurrentListadoMetodosByTestStep();

						for (MetodoDeclarado metodo : metodos) {

							contexto = (StringUtils.containsIgnoreCase(metodo.toString(), "common") ? metodo.toString()
									: contexto);

							if (!existeEnStepsToImplement(metodo.getLlamadaMetodo(), app, contexto)) {
								tsd_framework++;
								testStepsToImplement.add(new TestToImplement(app, contexto, testCaseName,
										step_simplificado, metodo.getLlamadaMetodo(), metodo.getCategoria(),
										metodo.getParametros()));
							}
						}

					}

				}

			}
		}

		testStepsToImplement = new ArrayList<TestToImplement>();
		return tsd_framework;
	}

	private static Integer getCountMethodsEntendiblesToImplementInFramework() {

		int tsd_framework = 0;

		// se recorren y se dividen los metodos por cada Step (ya que pueden
		// haber Steps que tengan mas de un metodo)

		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
			if (StringUtils.contains(testCasesFromParsedExcel.get(a).getTestCaseStatus(), "Ready for Test")) {

				String testCaseName = testCasesFromParsedExcel.get(a).getTestCaseName();
				List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();
				List<String> data = testCasesFromParsedExcel.get(a).getSampleData();

				for (int e = 0; e < steps.size(); e++) {

					String td = "";
					String ts = GenericCommon.removeHtmTags(GenericCommon.removeHexaChars(steps.get(e)));
					String app = StringUtils.split(ts, "__")[0];
					String contexto = StringUtils.split(ts, "__")[1];

					if (!StringUtils.contains(ts, "DICIONARIO") && !StringUtils.contains(ts, "IMPLEMENTADO")) {

						try {
							td = data.get(e);
						} catch (IndexOutOfBoundsException ea) {

						}

						String step_simplificado = StringUtils.split(ts, ">")[1];
						step_simplificado = StringUtils.substring(step_simplificado, 1, step_simplificado.length());

						parserClass.getMetodoDeclarado(ts, td);

						List<MetodoDeclarado> metodos = parserClass.getCurrentListadoMetodosByTestStep();

						for (MetodoDeclarado metodo : metodos) {

							contexto = (StringUtils.containsIgnoreCase(metodo.toString(), "common") ? metodo.toString()
									: contexto);

							if (!existeEnStepsToImplement(metodo.getLlamadaMetodo(), app, contexto)) {
								// System.out.println("CCCCC: " + contexto + "
								// AP: " + app + " M: " +
								// metodo.getLlamadaMetodo());
								tsd_framework++;
								testStepsToImplement.add(new TestToImplement(app, contexto, testCaseName,
										step_simplificado, metodo.getLlamadaMetodo(), metodo.getCategoria(),
										metodo.getParametros()));
							}
						}

					}

				}

			}
		}

		testStepsToImplement = new ArrayList<TestToImplement>();
		return tsd_framework;
	}
	
	private static Integer getCountTestStepsCriticalNoBloqueantesByFramework() {
		int tsd_framework = 0;

		// se recorren y se dividen los metodos por cada Step (ya que pueden
		// haber Steps que tengan mas de un metodo)

		for (int a = 0; a < testCaseCriticalNoBloqueantes.size(); a++) {
			if (StringUtils.contains(testCaseCriticalNoBloqueantes.get(a).getTestCaseStatus(), "Ready for Test")) {

				String testCaseName = testCaseCriticalNoBloqueantes.get(a).getTestCaseName();
				List<String> steps = testCaseCriticalNoBloqueantes.get(a).getTestSteps();
				List<String> data = testCaseCriticalNoBloqueantes.get(a).getSampleData();

				for (int e = 0; e < steps.size(); e++) {

					String td = "";
					String ts = GenericCommon.removeHtmTags(GenericCommon.removeHexaChars(steps.get(e)));
					String app = StringUtils.split(ts, "__")[0];
					String contexto = StringUtils.split(ts, "__")[1];

//					System.out.println("TS Critical: " + ts);

					if (!StringUtils.contains(ts, "DICIONARIO") && !StringUtils.contains(ts, "IMPLEMENTADO")) {

						try {
							td = data.get(e);
						} catch (IndexOutOfBoundsException ea) {

						}

						String step_simplificado = StringUtils.split(ts, ">")[1];
						step_simplificado = StringUtils.substring(step_simplificado, 1, step_simplificado.length());

						parserClass.getMetodoDeclarado(ts, td);

						List<MetodoDeclarado> metodos = parserClass.getCurrentListadoMetodosByTestStep();

						for (MetodoDeclarado metodo : metodos) {

							contexto = (StringUtils.containsIgnoreCase(metodo.toString(), "common") ? metodo.toString()
									: contexto);

							if (!existeEnStepsToImplement(metodo.getLlamadaMetodo(), app, contexto)) {
								// System.out.println("CCCCC: " + contexto + "
								// AP: " + app + " M: " +
								// metodo.getLlamadaMetodo());
								tsd_framework++;
								testStepsToImplement.add(new TestToImplement(app, contexto, testCaseName,
										step_simplificado, metodo.getLlamadaMetodo(), metodo.getCategoria(),
										metodo.getParametros()));
							}
						}

					}

				}

			}
		}

		testStepsToImplement = new ArrayList<TestToImplement>();
		return tsd_framework;
	}

	private static Integer getCountTestStepsCriticalByFramework() {

		int tsd_framework = 0;

		// se recorren y se dividen los metodos por cada Step (ya que pueden
		// haber Steps que tengan mas de un metodo)

		for (int a = 0; a < testCasesTodosReadyForTestCritical.size(); a++) {
			if (StringUtils.contains(testCasesTodosReadyForTestCritical.get(a).getTestCaseStatus(), "Ready for Test")) {

				String testCaseName = testCasesTodosReadyForTestCritical.get(a).getTestCaseName();
				List<String> steps = testCasesTodosReadyForTestCritical.get(a).getTestSteps();
				List<String> data = testCasesTodosReadyForTestCritical.get(a).getSampleData();

				for (int e = 0; e < steps.size(); e++) {

					String td = "";
					String ts = GenericCommon.removeHtmTags(GenericCommon.removeHexaChars(steps.get(e)));
					String app = StringUtils.split(ts, "__")[0];
					String contexto = StringUtils.split(ts, "__")[1];

//					System.out.println("TS Critical: " + ts);

					if (!StringUtils.contains(ts, "DICIONARIO") && !StringUtils.contains(ts, "IMPLEMENTADO")) {

						try {
							td = data.get(e);
						} catch (IndexOutOfBoundsException ea) {

						}

						String step_simplificado = StringUtils.split(ts, ">")[1];
						step_simplificado = StringUtils.substring(step_simplificado, 1, step_simplificado.length());

						parserClass.getMetodoDeclarado(ts, td);

						List<MetodoDeclarado> metodos = parserClass.getCurrentListadoMetodosByTestStep();

						for (MetodoDeclarado metodo : metodos) {

							contexto = (StringUtils.containsIgnoreCase(metodo.toString(), "common") ? metodo.toString()
									: contexto);

							if (!existeEnStepsToImplement(metodo.getLlamadaMetodo(), app, contexto)) {
								// System.out.println("CCCCC: " + contexto + "
								// AP: " + app + " M: " +
								// metodo.getLlamadaMetodo());
								tsd_framework++;
								testStepsToImplement.add(new TestToImplement(app, contexto, testCaseName,
										step_simplificado, metodo.getLlamadaMetodo(), metodo.getCategoria(),
										metodo.getParametros()));
							}
						}

					}

				}

			}
		}

		testStepsToImplement = new ArrayList<TestToImplement>();
		return tsd_framework;
	}

//	private static int getCountTestStepsFromFramework() {
//		int count = 0;
//
//		for (TestCaseExcel t : testCasesFromParsedExcel)
//			count += t.getQttStepsCompleteInFramework(parserClass);
//
//		return count;
//	}
	
	private static Integer getCountMethodsCriticosNoBloqueantesEntendiblesCompletosInFramework() {
		int count = 0;
		
		testStepsToImplement = new ArrayList<TestToImplement>();

		for (TestCaseExcel t : testCaseCriticalNoBloqueantes)
			count += t.getQttMethodsCompleteInFramework(parserClass);

		return count;
	}

	private static Integer getCountMethodsCriticosEntendiblesCompletosInFramework() {
		int count = 0;

		for (TestCaseExcel t : testCasesTodosReadyForTestCritical)
			count += t.getQttMethodsCompleteInFramework(parserClass);

		return count;
	}
	

	
//	private static Integer getCountTestStepsEntendiblesByMethodsComplete = 

	private static Integer getCountMethodsEntendiblesCompletosInFramework() {

		int count = 0;

		for (TestCaseExcel t : testCasesFromParsedExcel)
			count += t.getQttMethodsCompleteInFramework(parserClass);

		return count;
	}

	/** Recoge cuantos 'metodos a implementar' tiene un testcase */
//	private static Integer getCountTestStepsByFrameworkByTest(TestCaseExcel test) {
//
//		int tsd_framework = 0;
//
//		// se recorren y se dividen los metodos por cada Step (ya que pueden
//		// haber Steps que tengan mas de un metodo)
//
//		for (int a = 0; a < testCasesFromParsedExcel.size(); a++) {
//			if (StringUtils.equals(test.getTestCaseName(), testCasesFromParsedExcel.get(a).getTestCaseName())) {
//				if (StringUtils.contains(testCasesFromParsedExcel.get(a).getTestCaseStatus(), "Ready for Test")) {
//
//					String testCaseName = testCasesFromParsedExcel.get(a).getTestCaseName();
//					List<String> steps = testCasesFromParsedExcel.get(a).getTestSteps();
//					List<String> data = testCasesFromParsedExcel.get(a).getSampleData();
//
//					for (int e = 0; e < steps.size(); e++) {
//
//						String td = "";
//						String ts = GenericCommon.removeHtmTags(GenericCommon.removeHexaChars(steps.get(e)));
//						String app = StringUtils.split(ts, "__")[0];
//						String contexto = StringUtils.split(ts, "__")[1];
//
//						if (!StringUtils.contains(ts, "DICIONARIO")) {
//
//							try {
//								td = data.get(e);
//							} catch (IndexOutOfBoundsException ea) {
//
//							}
//
//							String step_simplificado = StringUtils.split(ts, ">")[1];
//							step_simplificado = StringUtils.substring(step_simplificado, 1, step_simplificado.length());
//
//							List<MetodoDeclarado> metodos = getMetodosDeclaradosByStep(step_simplificado, td);
//
//							for (MetodoDeclarado metodo : metodos)
//
//								if (!existeEnStepsToImplement(metodo.getLlamadaMetodo(), app, contexto)) {
//									tsd_framework++;
//									testStepsToImplement.add(new TestToImplement(app, contexto, testCaseName,
//											step_simplificado, metodo.getLlamadaMetodo(), metodo.getCategoria(),
//											metodo.getParametros()));
//								}
//
//						}
//
//					}
//
//				}
//
//				testStepsToImplement = new ArrayList<TestToImplement>();
//			}
//		}
//		return tsd_framework;
//	}

	
	
	public static void generar() {

		recorreEIdentificaTestCasesIncompletos();

		if(listadoDiccionariosInexistentes != null){
			if (existenTestCasesIncompletos() || listadoDiccionariosInexistentes.size() > 0) {
				escribirInformacionDelArchivo();
				escribirTestCases();
			}
	
			else {
				escribirInformacionDelArchivo();
				salto();
				threeTab();
				escribirtOK();
			}
	
			crearInstanciaTexto(ExcelUtils.nombreArchivo);
			FileCommon.crearArchivo(informe);
		}
	}

	@SuppressWarnings("deprecation")
	private static void crearInstanciaTexto(String nameFile) {

		// String prefijoAplicacion = System.getProperty("aplicacion");
		// String nameCompostFile = (StringUtils.isNotEmpty(prefijoAplicacion)
		// || prefijoAplicacion != null ? prefijoAplicacion + "_" + nameFile :
		// nameFile);
		String absolutePathNewer = Propiedades.PATH_NEW_REPORTS + "\\" + nameFile + ".txt";
		String absolutePathHistoric = Propiedades.PATH_HISTORIC_REPORTS + "\\" + nameFile + ".txt";

		// get file in "new reports"
		File fileInNewReports = FileCommon.getFile(absolutePathNewer);

		// if the file are in "new reports", check current date with after
		// field.
		if (fileInNewReports != null) {

			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date dateCurrent = new Date();
			dateCurrent = new Date(dateFormat.format(dateCurrent));

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

			Date dateFileExisting = new Date(sdf.format(fileInNewReports.lastModified()).toString());

			// if "dateFileExist" is lower then today, have to copy in historic
			// and create a new instance
			if (dateFileExisting.before(dateCurrent)) {

				File fileInHistoricReport = new File(absolutePathHistoric);

				try {
					// verificar si se mueve o no se mueve (ya que la fecha de
					// modificacion del archivo varia pero la fecha de creacion
					// no)
					Files.move(fileInNewReports, fileInHistoricReport);

					// before moving file... create a new file in "new report".
					createFile(Propiedades.PATH_NEW_REPORTS, nameFile, "txt");

				} catch (IOException e) {
					e.printStackTrace();
				}

				// before moving file... create a new file in "new report".

			} else if (dateFileExisting.equals(dateCurrent)) {
				borrarYCrearTexto(Propiedades.PATH_NEW_REPORTS, nameFile, "txt");
				createFile(Propiedades.PATH_NEW_REPORTS, nameFile, "txt");
			}

		}

		// si el file no existe, lo creo.
		else {
			createFile(Propiedades.PATH_NEW_REPORTS, nameFile, "txt");
		}

	}

	public static void generarTrello() {
		// ordeno por numero de metodos
		ordenarTrelloObjects();

		// genero las tarjetas
		crearCardApiTrello();
	}

	public static void generarExcel() {

		recorreEIdentificaTestCasesIncompletos();

		if (existenTestCasesIncompletos()
				|| (listadoDiccionariosInexistentes != null && listadoDiccionariosInexistentes.size() > 0)) {
			escribirTestCasesExcel();
		}

	}

	private static void escribirtOK() {
		informe += "-- TEST CASE OK --";
	}
	
	public static List<String> tsd= new ArrayList<String>();
	public static List<String> tsnd = new ArrayList<String>();
	
	public static void saveAllTestStepsDuplicatedFromExcelTratar() {
		tsd = new ArrayList<String>();
		tsnd = new ArrayList<String>();

		List<String> tmp_testSteps = new ArrayList<String>();

		for (String ts : TrataTestCasesByExcel.testStepsFromReportExcel)

			if (tmp_testSteps.contains(ts)) {
				tsd.add(ts);
			} else {
				tmp_testSteps.add(ts);
				tsnd.add(ts);
			}
	
	}
	
	public static List<String> tsdc  = new ArrayList<String>();
	public static List<String> tsndc = new ArrayList<String>();
	
//	private static void saveAllTestStepsDuplicatedFromExcelTratarCritical() {
//		tsdc = new ArrayList<String>();
//		tsndc = new ArrayList<String>();
//
//		List<String> tmp_testSteps = new ArrayList<String>();
//
//		for (String ts : TrataTestCasesByExcel.testStepsFromReportExcelCritical)
//
//			if (tmp_testSteps.contains(ts)) {
//				tsdc.add(ts);
//			} else {
//				tmp_testSteps.add(ts);
//				tsndc.add(ts);
//			}
//	
//	}
	
//	private static int getNoDuplicatedByTratarCasesByExcelCritical() {
//		saveAllTestStepsDuplicatedFromExcelTratarCritical();
//
//		return tsndc.size();
//	}
	
//	private static int getNoDuplicatedByTratarCasesByExcel() {
//		saveAllTestStepsDuplicatedFromExcelTratar();
//
//		return tsnd.size();
//	}

	public static int qtt_totalTestCases = 0;
	public static int qtt_totalTestCasesComplete = 0;
	public static int qtt_totalTestCasesCompleteCritical = 0;
	public static int qtt_totalTestCasesCompleteReadyForTest = 0;
	public static int qtt_totalTestCasesCompleteReadyForTestCritical = 0;
	public static int qtt_totalTestCasesReadyForTest = 0;
	public static int qtt_totalTestCasesDraft = 0;
	public static int qtt_totalTestCasesObsolete = 0;
	public static int qtt_totalTestCasesObsoleto = 0;
	public static int qtt_totalTestCasesReadyForReview = 0;
	public static int qtt_totalTestCasesOmitir = 0;
	public static int qtt_totalTestCasesReadyForTestCritical = 0;
	

	public static int qtt_metodosEntendiblesCriticosAImplementarEnFramework = 0;

	public static int qtt_testStepsNoDuplicados = 0;
	public static int qtt_testStepsCriticosNoDuplicados	= 0;
	public static int qtt_stepsNoEntendiblesPorDiccionario = 0;
	public static int qtt_stepsCriticosNoEntendiblesPorDiccionario = 0;

	public static int qtt_metodosEntendiblesNoCompletadosEnFramework = 0;
	public static int qtt_metodosEntendiblesCompletadosEnFramework = 0;
	public static int qtt_metodosEntendiblesTotales = 0;

	public static int qtt_metodosEntendiblesCriticosNoCompletadosEnFramework = 0;
	public static int qtt_metodosEntendiblesCriticosCompletadosEnFramework = 0;

	public static int qtt_metodosCriticosImplementadosDuplicadosNVeces = 0;
	public static int qtt_metodosCriticosImplementadosDeTCIncompletosDuplicadosNVeces = 0;
	public static int qtt_metodosCriticosImplementadosNVeces = 0;
	public static int testCasesCriticosDondeAfecta = 0;

	public static int qtt_tcsReadyForTestCriticalConFirma = 0;
	
	public static int qtt_apuntesContables = 0;
	public static int qtt_apuntesContablesCompletos = 0;
	public static int qtt_apuntesContablesOnlyRefactored = 0;
	public static int qtt_apuntesContablesConFirma = 0;
	public static int qtt_tcsReadyForTestConFirma = 0;
	
	private static void escribirInformacionDelArchivo() {
		informe = "";
		informe = "***********************************************************";
		salto();
		salto();
		twoTab();
		informe += "Nombre del Excel: " + ExcelUtils.nombreArchivo;
		salto();
		twoTab();
		informe += "Ruta del Excel: " + ExcelUtils.PATH;

		// qtt TC
		qtt_totalTestCases = getCountTestCases(); // verify
		qtt_totalTestCasesComplete = testCasesCompletosReadyForTest.size(); // verify
		qtt_totalTestCasesCompleteCritical = testCasesCompletosReadyForTestCritical.size(); // verify
		qtt_totalTestCasesCompleteReadyForTest = 0;
		qtt_totalTestCasesCompleteReadyForTestCritical = 0;

		// int qtt_totalTestCasesIncompletePriorityCritical =
		// getCountTestCasesTodosPriorityCritical();
		// int qtt_totalTestCasesIncompleteReadyForTestPriorityCritical =
		// testCaseStatusCritical.size();

		// qtt TC by status
		qtt_totalTestCasesReadyForTest = getCountTestCasesStatusRedyForTest(); // verify
		qtt_totalTestCasesDraft = getCountTestCasesStatusDraft(); // verify
		qtt_totalTestCasesObsolete = getCountTestCasesStatusObsolete(); // verify
		qtt_totalTestCasesObsoleto = getCountTestCasesStatusObsoleto(); // verify
		qtt_totalTestCasesReadyForReview = getCountTestCasesStatusRedyForReview(); // verify
		qtt_totalTestCasesOmitir = qtt_totalTestCasesDraft + qtt_totalTestCasesObsolete + qtt_totalTestCasesObsoleto
				+ qtt_totalTestCasesReadyForReview; // verify

		qtt_totalTestCasesReadyForTestCritical = getCountTestCasesTodos_ReadyForTestPriorityCritical();

		
		qtt_apuntesContables = getCountTestStepsWithApunteContableWord();
		qtt_apuntesContablesCompletos = getCountTestStepsWithApunteContableWordTcCompleted();
		qtt_apuntesContablesOnlyRefactored = getCountTestStepsWithApunteContableWordOnlyRefactored();
		qtt_apuntesContablesConFirma = getCountTestStepsWithApunteContableConFirma();
		
		qtt_tcsReadyForTestConFirma = getCountTestCasesReadyForTestWithProcesoFirmaWord();
		qtt_tcsReadyForTestCriticalConFirma = getCountTestCasesReadyForTestCriticalWithProcesoFirmaWord();
		
		informe += "********* TEST CASES *********"; // verify
		salto();
		salto();
		twoTab();
		informe += "TC \"Totales\": " + qtt_totalTestCases; // verify
		salto();
		twoTab();
		informe += "TC \"Ready for test\": " + qtt_totalTestCasesReadyForTest; // verify
		salto();
		twoTab();
		informe += "TC \"Critical\": " + qtt_totalTestCasesReadyForTestCritical; // verify
		salto();
		twoTab();
		informe += "TC \"Automatizados\": " + qtt_totalTestCasesComplete; // verify
		salto();
		twoTab();
		informe += "TC \"Critical Automatizados\": " + qtt_totalTestCasesCompleteCritical; // verify
//		salto();
//		twoTab();
//		informe += "TC \"Ready for Test Automatizados\": " + qtt_totalTestCasesCompleteReadyForTest; // verify
//		salto();
//		twoTab();
//		informe += "TC \"Ready for Test Critical Automatizados\": " + qtt_totalTestCasesCompleteReadyForTestCritical; // verify
		salto();
		salto();
		twoTab();
		informe += "TC \"Omitir\": " + qtt_totalTestCasesOmitir; // verify
		salto();
		salto();
		salto();
		salto();
		twoTab();
		informe += "TS \"Critical no bloqueantes\": (por firma)" + testCaseCriticalNoBloqueantes.size();
		salto();
		twoTab();
		informe += "TC \"Firma\": " + qtt_tcsReadyForTestConFirma; // verify
		salto();
		twoTab();
		informe += "TC \"Critical Firma\": " + qtt_tcsReadyForTestCriticalConFirma; // verify
		
		salto();
		twoTab();
		informe += "TC \"Apuntes contables\": " + qtt_apuntesContables; // verify
		salto();
		twoTab();
		informe += "TC \"Apuntes contables\" para automatizar: " + qtt_apuntesContablesCompletos; // verify
		salto();
		twoTab();
		informe += "TC \"Apuntes contables\" only refactored: " + qtt_apuntesContablesOnlyRefactored; // verify
		salto();
		twoTab();
		informe += "TC \"Apuntes contables\" con firma: " + qtt_apuntesContablesConFirma; // verify

		// guarda "testStepsTodos"(todos) / "testStepsReadyForTestCritical"(redy
		// critical) / "testStepsReadyForTest" ( redy for test)
		saveAllTestStepsFromTestCases(testCasesFromParsedExcel);

		testCasesTodosReadyForTestCritical.size();
		qtt_metodosEntendiblesCriticosAImplementarEnFramework = getCountTestStepsCriticalByFramework();
		int qtt_metodosEntendiblesCriticosNoBloqueantesAImplementarEnFramework = getCountTestStepsCriticalNoBloqueantesByFramework();
//		qtt_metodosCompletosCriticosEnFramework = getCountTestStepsCriticalComplete();
//		qtt_stepsNoEntendiblesCriticos = getCountTestStepsCriticosByDiccionario();

		qtt_testStepsNoDuplicados = getCountTestStepsNoDuplicados(); 
		qtt_testStepsCriticosNoDuplicados = getCountTestStepsCriticalNoDuplicated();
		int qtt_testStepsCriticosNoBloqueantesNoDuplicados = getCountTestStepsCriticalNoBloqueantesNoDuplicados();
		qtt_stepsNoEntendiblesPorDiccionario = getCountTestStepsByDiccionario();
		qtt_stepsCriticosNoEntendiblesPorDiccionario = getCountTestStepsCriticosByDiccionario();
		int qtt_stepsCriticosNoBloqueantesNoEntendiblesPorDiccionario = getCountTestStepsCriticosNoBloqueantesByDiccionario();
//		qtt_stepsEntendiblesPorFramework = getCountTestStepsFromFramework();

//		qtt_metodosEntendiblesAImplementarEnFramework = getCountTestStepsCriticalByFramework();

		// ts normal
		qtt_metodosEntendiblesNoCompletadosEnFramework = getCountMethodsEntendiblesToImplementInFramework();
		qtt_metodosEntendiblesCompletadosEnFramework = getCountMethodsEntendiblesCompletosInFramework();
		qtt_metodosEntendiblesTotales = (qtt_metodosEntendiblesNoCompletadosEnFramework
				+ qtt_metodosEntendiblesCompletadosEnFramework);
//		qtt_totalMetodosAImplementarEnElFramework = qtt_metodosEntendiblesNoCompletadosEnFramework
//				+ qtt_metodosEntendiblesCompletadosEnFramework;

		// ts critical
		qtt_metodosEntendiblesCriticosNoCompletadosEnFramework = getCountMethodsCriticosEntendiblesToImplementInFramework();
		qtt_metodosEntendiblesCriticosCompletadosEnFramework = getCountMethodsCriticosEntendiblesCompletosInFramework();
		int qtt_metodosEntendiblesCriticosNoBloqueantesCompletadosEnFramework = getCountMethodsCriticosNoBloqueantesEntendiblesCompletosInFramework();
//		qtt_metodosEntendiblesCriticosTotales = (qtt_metodosEntendiblesCriticosNoCompletadosEnFramework
//				+ qtt_metodosEntendiblesCriticosCompletadosEnFramework);
//		qtt_totalMetodosCriticosAImplementarEnElFramework = qtt_metodosEntendiblesNoCompletadosEnFramework
//				+ qtt_metodosEntendiblesCompletadosEnFramework;

		// recoge metodos 'implementados' y 'duplicados' en el framework
//		qtt_metodosImplementadosDuplicadosNVeces = getCountTestStepsCompleteDuplicate();
//		qtt_metodosImplementadosDeTCIncompletosDuplicadosNVeces = getCountTestStepsIncompleteDuplicate();
//		qtt_metodosImplementadosNVeces = qtt_metodosImplementadosDuplicadosNVeces
//				+ qtt_metodosImplementadosDeTCIncompletosDuplicadosNVeces;
//		testCasesDondeAfecta = listTestCasesAffectedByTestStepsDuplicated;

		qtt_metodosCriticosImplementadosDuplicadosNVeces = getCountTestStepsCriticalCompleteDuplicate();
		qtt_metodosCriticosImplementadosDeTCIncompletosDuplicadosNVeces = getCountTestStepsCriticalIncompleteDuplicate();
		qtt_metodosCriticosImplementadosNVeces = qtt_metodosCriticosImplementadosDuplicadosNVeces
				+ qtt_metodosCriticosImplementadosDeTCIncompletosDuplicadosNVeces;
		testCasesCriticosDondeAfecta = listTestCasesAffectedByTestStepsCriticalDuplicated;

//		qtt_noDuplicadosFromTratarTestCasesByExcel = getNoDuplicatedByTratarCasesByExcel();
//		int qtt_noDuplicadosFromTratarTestCasesByExcelCritical = getNoDuplicatedByTratarCasesByExcelCritical();
		
				
		salto();
		salto();
		twoTab();
		informe += "********* TEST CASES *********";
		salto();
		salto();
		twoTab();
		informe += "TS \"Totales\": " + testStepsTodos.size();
		salto();
		twoTab();
		informe += "TS \"Por hacer\": " + qtt_testStepsNoDuplicados;
		salto();
		twoTab();
		informe += "TS \"Por hacer (Resta)\": " + getCountTestStepsNoDuplicadosOfCompleted(); //testStepsEntendiblesByMethods.size();
//		salto();
//		twoTab();
//		informe += "TS \"Totales from excel\": " + TrataTestCasesByExcel.testStepsFromReportExcel.size();
//		salto();
//		twoTab();
//		informe += "TS \"Totales from excel\" no duplicado: " + qtt_noDuplicadosFromTratarTestCasesByExcel;
		salto();
		salto();
		twoTab();	
		informe += "TS 'A IMPLEMENTAR' en Diccionario:" + qtt_stepsNoEntendiblesPorDiccionario;
		salto();
		salto();
		twoTab();
		informe += "Metodos 'A IMPLEMENTAR' en Framework:" + qtt_metodosEntendiblesTotales; // hay
																							// pasos
																							// que
																							// no
																							// salen
																							// porque
																							// directamente
																							// no
																							// los
																							// coge...
		salto();
		twoTab();
		informe += "Metodos 'NO COMPLETADOS' en Framework:" + qtt_metodosEntendiblesNoCompletadosEnFramework;
		salto();
		salto();
		twoTab();
		informe += "** Metodos totales 'COMPLETOS' en Framework:" + qtt_metodosEntendiblesCompletadosEnFramework
				+ " **";
		salto();
		salto();
		salto();
		twoTab();
		// informe += "-- De los cuales se duplican un TOTAL de '" +
		// qtt_metodosImplementadosNVeces + "' en '"+ testCasesDondeAfecta + "'
		// Test Cases.";
		// salto();
		// salto();
		// twoTab();
		// informe += "Cantidad de TEST CASES con ''apunte contable'': '" +
		// qtt_testCasesTienenApunteContable + "'.";
		// salto();
		// salto();
		// twoTab();
		// informe += "Cantidad de TEST CASES con ''firma'': '" +
		// qtt_testCasesTienenProcesoFirma + "'.";
		salto();
		salto();
		twoTab();
		informe += "****** FIN TOTAL ******";
		salto();
		salto();
		salto();
		salto();
		salto();
		salto();
		salto();
		salto(); // TODO
		salto();
		twoTab();
		informe += "****** CRITICAL ******";
		salto();
		salto();
		twoTab();
		informe += "TS \"Totales\": (desde excel)" + testStepsReadyForTestCritical.size();
		salto();
		twoTab();
		informe += "TS \"Por hacer\" (desde excel): " + qtt_testStepsCriticosNoDuplicados;
		salto();
		twoTab();
		informe += "TS \"Por hacer (Resta)\" (desde excel): " + getCountTestStepsNoDuplicadosOfCompletedCritical(); //testStepsEntendiblesByMethods.size();
//		salto();
//		twoTab();
//		informe += "TS \"Totales from excel\": " + TrataTestCasesByExcel.testStepsFromReportExcelCritical.size();
//		salto();
//		twoTab();
//		informe += "TS \"Totales from excel\" no duplicado: " + qtt_noDuplicadosFromTratarTestCasesByExcelCritical;
		salto();
		twoTab();
		informe += "TS 'A IMPLEMENTAR' en Diccionario (desde excel):" + qtt_stepsCriticosNoEntendiblesPorDiccionario;
		salto();
		salto();
		twoTab();
		informe += "Metodos 'A IMPLEMENTAR' en Framework:" + qtt_metodosEntendiblesCriticosAImplementarEnFramework; // hay
																													// pasos
																													// que
																													// no
																													// salen
																													// porque
																													// directamente
																													// no
																													// los
																													// coge...
		salto();
		twoTab();
		informe += "Metodos 'NO COMPLETADOS' en Framework:" + qtt_metodosEntendiblesCriticosNoCompletadosEnFramework;
		salto();
		salto();
		twoTab();
		informe += "** Metodos totales 'COMPLETOS' en Framework:" + qtt_metodosEntendiblesCriticosCompletadosEnFramework
				+ " **";
		salto();
		salto();
		salto();
		twoTab();
		informe += "-- De los cuales se duplican un TOTAL de '" + qtt_metodosCriticosImplementadosNVeces + "' en '"
				+ testCasesCriticosDondeAfecta + "' Test Cases.";
		twoTab();
		// salto();
		// salto();
		// twoTab();
		// informe += "Cantidad de TEST CASES con ''apunte contable'': '" +
		// qtt_testCasesTienenApunteContable + "'.";
		// salto();
		// salto();
		// twoTab();
		// informe += "Cantidad de TEST CASES con ''firma'': '" +
		// qtt_testCasesTienenProcesoFirma + "'.";
		salto();
		salto();
		salto();
		salto();
		salto();

		
		salto();
		twoTab();
		informe += "****** CRITICAL NO BLOQUEANTE ******";
		salto();
		salto();
		twoTab();
		informe += "TCs Bloqueados por Framework: " + getCountTestCasesCriticalNoBloqueantesErroresFramework();
		salto();
		twoTab();
		informe += "TCs Bloqueados por Diccionario: " + getCountTestCasesCriticalNoBloqueantesErroresDiccionario();
		salto();
		twoTab();
		informe += "TCs Bloqueados por Framework y Diccionario: " + getCountTestCasesCriticalNoBloqueantesErroresFrameworkDiccionario();
		salto();
		salto();
		salto();
		salto();
		twoTab();
		informe += "TS \"Por hacer\" (desde excel): " + qtt_testStepsCriticosNoBloqueantesNoDuplicados;
		salto();
		twoTab();
		informe += "TS \"Por hacer (Resta)\" (desde excel): " + getCountTestStepsNoDuplicadosOfCompletedCriticalNoBloqueantes(); //testStepsEntendiblesByMethods.size();
		salto();
		salto();
		twoTab();
		informe += "TS 'A IMPLEMENTAR' en Diccionario (desde excel):" + qtt_stepsCriticosNoBloqueantesNoEntendiblesPorDiccionario;
		salto();
		salto();
		twoTab();
		informe += "Metodos 'A IMPLEMENTAR' en Framework:" + qtt_metodosEntendiblesCriticosNoBloqueantesAImplementarEnFramework; // hay
																													// pasos
																													// que
																													// no
																													// salen
																													// porque
																													// directamente
																													// no
																													// los
																													// coge...
//		salto();
//		twoTab();
//		informe += "Metodos 'NO COMPLETADOS' en Framework:" + qtt_metodosEntendiblesCriticosNoCompletadosEnFramework;
		salto();
		salto();
		twoTab();
		informe += "** Metodos totales 'COMPLETOS' en Framework:" + qtt_metodosEntendiblesCriticosNoBloqueantesCompletadosEnFramework
				+ " **";
		
		
		informe += "*********** FIN ***********";
		salto();
		salto();
		informe += "***********************************************************";
		salto();
		salto();
	}

	private static void escribirTestCases() {

		testStepsToImplement = new ArrayList<TestToImplement>();

		for (TestCaseExcel test : testCasesFromParsedExcel) {
			if (StringUtils.containsIgnoreCase(test.getTestCaseStatus(), "Ready for Test")) {
				twoTab();
				asterisco();
				informe += "TestCase: " + test.getTestCaseName();
				escribirContextosNoEncontrado(test.getContextos());
				salto();
				salto();
				escribirTestSteps(test, "txt");
				salto();
				salto();
				informe += "***********************************************************";
				salto();
				salto();
				salto();
			}
		}
	}

	@SuppressWarnings("deprecation")
	private static void crearInstanciaExcel(String nameFile) {

		String absolutePathNewer = Propiedades.PATH_NEW_REPORTS + "\\" + nameFile + ".xls";
		String absolutePathHistoric = Propiedades.PATH_HISTORIC_REPORTS + "\\" + nameFile + ".xls";

		// get file in "new reports"
		File fileInNewReports = FileCommon.getFile(absolutePathNewer);

		// if the file are in "new reports", check current date with after
		// field.
		if (fileInNewReports != null) {

			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date dateCurrent = new Date();
			dateCurrent = new Date(dateFormat.format(dateCurrent));

			Date dateFileExisting = FileCommon.getDateFileByAbsolutePath(absolutePathNewer);

			// if "dateFileExist" is lower then today, have to copy in historic
			// and create a new instance
			if (dateFileExisting.before(dateCurrent)) {

				File fileInHistoricReport = new File(absolutePathHistoric);

				try {
					Files.move(fileInNewReports, fileInHistoricReport);

					// before moving file... create a new file in "new report".
					createExcelFile(Propiedades.PATH_NEW_REPORTS, nameFile, "xls");

				} catch (IOException e) {
					e.printStackTrace();
				}

				// this file are the same? (cargar file)
			} else if (dateFileExisting.equals(dateCurrent)) {
				borrarYCrearExcel(Propiedades.PATH_NEW_REPORTS, nameFile, "xls");
				createExcelFile(Propiedades.PATH_NEW_REPORTS, nameFile, "xls");
			}
		}

		// si el file no existe, lo creo.
		else
			createExcelFile(Propiedades.PATH_NEW_REPORTS, nameFile, "xls");

	}

//	@SuppressWarnings("deprecation")
//	private static void crearInstanciaExcelMetodosUnicos(String fileName) {
//
//		String absolutePathNewer = Propiedades.PATH_NEW_REPORTS + "\\" + fileName + ".xls";
//		String absolutePathHistoric = Propiedades.PATH_HISTORIC_REPORTS + "\\" + fileName + ".xls";
//
//		// get file in "new reports"
//		File fileInNewReports = FileCommon.getFile(absolutePathNewer);
//
//		// if the file are in "new reports", check current date with after
//		// field.
//		if (fileInNewReports != null) {
//
//			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
//			Date dateCurrent = new Date();
//			dateCurrent = new Date(dateFormat.format(dateCurrent));
//
//			Date dateFileExisting = FileCommon.getDateFileByAbsolutePath(absolutePathNewer);
//
//			// if "dateFileExist" is lower then today, have to copy in historic
//			// and create a new instance
//			if (dateFileExisting.before(dateCurrent)) {
//
//				File fileInHistoricReport = new File(absolutePathHistoric);
//
//				try {
//					Files.move(fileInNewReports, fileInHistoricReport);
//
//					// before moving file... create a new file in "new report".
//					createExcelFile(Propiedades.PATH_NEW_REPORTS, fileName, "txt");
//
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//
//				// before moving file... create a new file in "new report".
//
//			} else if (dateFileExisting.equals(dateCurrent))
//				createExcelFileMetodosUnicos(Propiedades.PATH_NEW_REPORTS, fileName, "xls");
//
//		}
//
//		// si el file no existe, lo creo.
//		else
//			createExcelFileMetodosUnicos(Propiedades.PATH_NEW_REPORTS, fileName, "xls");
//
//	}

	public static void createFile(String path, String nameFile, String extension) {
		FileCommon.setPath(path);
		FileCommon.setName(nameFile);
		FileCommon.setExtension(extension);
		FileCommon.crearArchivo();
	}

	public static void createExcelFile(String path, String nameFile, String extension) {
		createFile(path, nameFile, extension);
		ExcelUtils.setLineaInicialCreacionExcels(0);
		ExcelUtils.crearExcel(path, "Test Cases", nameFile);
	}

	private static void borrarYCrearExcel(String path, String nameFile, String extension) {
		FileCommon.eliminarArchivo(path + "\\" + nameFile + ".xls");
	}

	private static void borrarYCrearTexto(String path, String nameFile, String extension) {
		FileCommon.eliminarArchivo(path + "\\" + nameFile + ".txt");
	}

//	private static void createExcelFileMetodosUnicos(String path, String nameFile, String extension) {
//		createFile(path, nameFile, extension);
//		ExcelUtils.setLineaInicialCreacionExcels(0);
////		excelMetodosUnicos = new ExcelUtilsNoStatic();
////		excelMetodosUnicos.crearExcel(path, "Report", nameFile);
//	}

	private static List<TrelloObject> listTrelloObjects;

	private static void escribirTestCasesExcel() {

		String app = System.getProperty("nombre_informe_app");

		app = app != null ? app + "_" : "";

		String nameFile = app + "Informe_Excel_" + ExcelUtils.nombreArchivo;

		String prefijoAplicacion = System.getProperty("aplicacion");
		String nameCompostFile = GenericCommon
				.quitarEspacios((StringUtils.isNotEmpty(prefijoAplicacion) || prefijoAplicacion != null
						? prefijoAplicacion + "_" + nameFile : nameFile));

		// create excel instance for "app report"
		crearInstanciaExcel(nameCompostFile);
		ExcelUtils.crearCabeceraDeColumnas("Aplicacion", "Prioridad", "TestCase", "Frontal", "Contexto", "Tipo error",
				"Steps", "Metodo implementado", "Metodos a implementar", "Par�metros", "Validacion Step \n en Informe",
				"Validacion metodo \n en Script", "Validacion\n TestCase\n completo", "Observaciones");

		// create excel instance for "report unique methods"
//		excelMetodosUnicos = new ExcelUtilsNoStatic();
//		excelMetodosUnicos.cargarFichero(
//				"C:\\Users\\ll.saptest\\git\\functional-testing\\testing_common\\src\\main\\java\\informes\\Report_Metodos_Totales_Implementados1.xlsx",
//				"Report");
//		excelMetodosUnicos.eliminarTodasLasLineas();
//		excelMetodosUnicos.setLineaInicialCreacionExcels(0);

		testStepsToImplement = new ArrayList<TestToImplement>();

		listTrelloObjects = new ArrayList<TrelloObject>();

		for (TestCaseExcel test : testCasesFromParsedExcel)
			escribirTestSteps(test, "xls");

		// cuando hay una app definida buscamos un excel que contenga un excel
		// con la app.
		// buscamos un excel que contenga el mismo nombre + aplicacion. y si la
		// fecha es anterior, lo copiamos en historico.

		ExcelUtils.writeAndCloseExcel("\\" + nameCompostFile + ".xls");
//		excelMetodosUnicos.writeAndCloseExcel("");

	}

	private static void ordenarTrelloObjects() {

		ArrayList<Integer> tmp = new ArrayList<Integer>();
		List<TrelloObject> tmpobjects = new ArrayList<TrelloObject>();

		Map<Integer, List<TrelloObject>> mapto2 = new HashMap<Integer, List<TrelloObject>>();

		if (listTrelloObjects != null) {
			for (TrelloObject to : listTrelloObjects) {

				if (mapto2.get(to.getItemsSize()) != null)
					mapto2.get(to.getItemsSize()).add(to);

				else {
					List<TrelloObject> listo = new ArrayList<TrelloObject>();
					listo.add(to);
					mapto2.put(to.getItemsSize(), listo);
				}
			}

			for (Map.Entry<Integer, List<TrelloObject>> entry : mapto2.entrySet()) {
				tmp.add(entry.getKey());
			}

			tmp.sort(Comparator.naturalOrder());

			for (Integer i : tmp) {
				if (i != 0) {
					List<TrelloObject> tobjects = mapto2.get(i);
					for (TrelloObject o : tobjects)
						tmpobjects.add(o);
				}

			}

			listTrelloObjects = tmpobjects;
		} else {
			System.out.println("** NO HAY TEST CASES EN: " + System.getProperty("nombre_informe_app"));
		}
	}

	private static void crearCardApiTrello() {

		Card card = null;
		Checklist checklist = null;

		if(listTrelloObjects != null){
			for (TrelloObject o : listTrelloObjects) {
	
				card = TrelloCardsUtils.createCard(o);
				checklist = TrelloChecklistsUtils.createChecklist(o, card);
				TrelloItemsUtils.createItems(checklist, o);
	
			}
		}
	}

	// TODO no es necesario... 19/03/2018
//	private static void escribirImplementacionesDeDiccionario() {
//
//		// resumen de pasoso por categoria
//
//		Integer categoria1 = getTotalCategory(0);
//		Integer categoria2 = getTotalCategory(1);
//		Integer categoria3 = getTotalCategory(2);
//		Integer categoria4 = getTotalCategory(3);
//		Integer categoria5 = getTotalCategory(4);
//		Integer categoria6 = getTotalCategory(5);
//		Integer categoria7 = getTotalCategory(6);
//
//		salto();
//		informe += "***********************************************************";
//		salto();
//		informe += "***********************************************************";
//		salto();
//		informe += "***********************************************************";
//		salto();
//		salto();
//
//		informe += "Frases no identificadas en el framework por categoria (la categoria estima el grado de ''complejidad'' a la hora de desarrollar el metodo):  ";
//		salto();
//		salto();
//
//		informe += "Categoria 1: " + categoria1;
//		salto();
//		informe += "Categoria 2: " + categoria2;
//		salto();
//		informe += "Categoria 3: " + categoria3;
//		salto();
//		informe += "Categoria 4: " + categoria4;
//		salto();
//		informe += "Categoria 5: " + categoria5;
//		salto();
//		informe += "Categoria 6: " + categoria6;
//		salto();
//		informe += "Categoria 7: " + categoria7;
//		salto();
//		salto();
//
//		informe += "************************* METODOS RESTANTES EN FRAMEWORK";
//
//		salto();
//		salto();
//
//		String tmp_testStep = "";
//
//		for (TestToImplement m : testStepsToImplement) {
//
//			if (!StringUtils.equals(m.getStep(), tmp_testStep)) {
//				tmp_testStep = m.getStep();
//				informe += "***********************************************************";
//				salto();
//				salto();
//				informe += "App: " + m.getApp();
//				salto();
//				informe += "Contexto: " + m.getContexto();
//				salto();
//				informe += m.getStep();
//			}
//
//			salto();
//			fourTab();
//			asterisco();
//			asterisco();
//			informe += "IMPLEMENTAR FRAMEWORK: " + m.getLlamadaMetodo();
//
//			if (m.getParametros() != null) {
//				salto();
//				fourTab();
//				asterisco();
//				asterisco();
//				informe += "PARAMETROS           : " + m.getParametros();
//			}
//
//			salto();
//		}
//
//		salto();
//		informe += "************************* FRASES A RESOLVER EN DICCIONARIO";
//		salto();
//		salto();
//
//		tmp_testStep = "";
//
//		for (TestToImplement m : testStepsToImplementInDiccionario) {
//
//			if (!StringUtils.equals(m.getStep(), tmp_testStep)) {
//				tmp_testStep = m.getStep();
//				informe += "***********************************************************";
//				salto();
//				salto();
//				informe += "App: " + m.getApp();
//				salto();
//				informe += "Contexto: " + m.getContexto();
//				salto();
//				informe += m.getStep();
//			}
//
//		}
//
//	}

//	private static Integer getTotalCategory(Integer category) {
//
//		Integer res = 0;
//
//		for (int a = 0; a < testStepsToImplement.size() - 1; a++)
//			if (testStepsToImplement.get(a).getCategoria() == category)
//				res++;
//
//		return res;
//	}

	private static void escribirContextosNoEncontrado(List<String> contextos) {

		if (contextos != null)
			if (contextos.size() > 0) {
				threeTab();
				informe += "** Los siguientes pasos no encuentran el contexto para definir su diccionario: ";
				salto();

				for (String contexto : contextos) {
					twoTab();
					twoTab();
					informe += "*" + contexto + "\n";
				}
			}
	}


	private static void escribirTestSteps(TestCaseExcel test, String modo) {

		// System.out.println("+++_++" + test.getTestCaseName());

		if (StringUtils.contains(test.getTestCaseStatus(), "Ready for Test")
			 && StringUtils.contains(test.getTestCasePrioridad(),
			 "Critical")
			 ){

			boolean excelMode = (StringUtils.equals(modo, "xls"));
//			boolean esIgualElNumeroDeItems = false;

			// guardo testCaseName en "board"
			TrelloObject to = null;

			Card card = null;
			Checklist checklist = null;
			List<CheckItem> checkItems = null;
			boolean esTarjetaNueva = false;
//			int checkItemsSize = 0;

			List<TestToImplement> tmp_metodo_declarados = new ArrayList<TestToImplement>();
//			List<TrelloItemObject> tmp_itemObject = new ArrayList<TrelloItemObject>();

			ExcelUtils.sumLastRow();

			if (excelMode) {
				ExcelUtils.escribirNuevaCeldaSegunCabcera("TestCase", test.getTestCaseName());
				ExcelUtils.escribirNuevaCeldaSegunCabcera("Aplicacion", test.getTestCaseAplicacion());

				Board board = TrelloCardsUtils.createBoardIfNoExist(System.getProperty("nombre_informe_app"));

				if (TrelloCardsUtils.existCardByNameInBoard(board, test)) {
					card = TrelloCardsUtils.getCard(board, test);
					checklist = TrelloChecklistsUtils.getLastCheckListByCard(card);
					checkItems = TrelloItemsUtils.getItemsByCheckList(checklist);

//					checkItemsSize = checkItems == null ? 0 : checkItems.size();

					esTarjetaNueva = false;

//					esIgualElNumeroDeItems = getCountTestStepsByFrameworkByTest(test) == checkItemsSize ? true : false;

				} else {
					// solventar el tema de los Boards (aplicaciones) a null
					// (revisar en el dise�o)
					if (board != null) {

						// identifico board y card, en la card creo checklist
						// "version 1"...
						to = new TrelloObject(board, test);

						// card = TrelloCardsUtils.createCard(board, test);

						// checklist =
						// TrelloChecklistsUtils.createChecklist(card, "version
						// 1");

						esTarjetaNueva = true;
					}
				}

				ExcelUtils.escribirNuevaCeldaSegunCabcera("Prioridad", test.getTestCasePrioridad());
			}

			if (!StringUtils.equals(test.getTestCaseStatus(), "Draft\n")) {
				ExcelUtils.sumLastRow();
				List<String> testSteps = test.getTestSteps();
				List<String> sampleData = test.getSampleData();

				for (int a = 0; a < testSteps.size(); a++) {

					String td = "";
					String ts = GenericCommon.removeHtmTags(GenericCommon.removeHexaChars(testSteps.get(a)));

					try {
						td = sampleData.get(a);
					} catch (IndexOutOfBoundsException e) {

					}

					threeTab();
					asterisco();
					
					String app;
					String contexto;
					String dric;
					String tipoerror;
					String step;

					if(!StringUtils.contains(ts, "_")){
						app = StringUtils.split(ts, "__")[0];
						contexto = StringUtils.split(ts, "__")[1];
						dric = StringUtils.split(ts, ">")[0];
						tipoerror = StringUtils.split(dric, "__")[2];
						step = StringUtils.split(ts, ">")[1];
					} else {
						ts = StringUtils.replace(ts, "s_c", "s c");
						app = StringUtils.split(ts, "__")[0];
						contexto = StringUtils.split(ts, "__")[1];
						dric = StringUtils.split(ts, ">")[0];
						tipoerror = StringUtils.split(dric, "__")[2];
						step = StringUtils.split(ts, ">")[1];
					}

					informe += "Test Step: " + tipoerror + " > " + step;
					salto();

					String step_simplificado = StringUtils.split(ts, ">")[1];
					String app_contexto = StringUtils.split(ts, ">")[0];
					step_simplificado = StringUtils.substring(step_simplificado, 1, step_simplificado.length());

					if (excelMode) {
						ExcelUtils.escribirNuevaCeldaSegunCabcera("Frontal", app);
						ExcelUtils.escribirNuevaCeldaSegunCabcera("Contexto", contexto);
						ExcelUtils.escribirNuevaCeldaSegunCabcera("Steps", step_simplificado);
						ExcelUtils.escribirNuevaCeldaSegunCabcera("Tipo error", tipoerror);
					}

					if (StringUtils.contains(app_contexto, "DICIONARIO")) {

						if (!existeEnStepsToImplementDiccionario(app, app_contexto, step_simplificado))
							testStepsToImplementInDiccionario
									.add(new TestToImplement(app, contexto, test.getTestCaseName(), step_simplificado));

						if (excelMode)
							ExcelUtils.escribirNuevaCeldaSegunCabcera("Steps", step_simplificado);

						if (excelMode) {
							ExcelUtils.applyStyleToRange(tipoerror);
							ExcelUtils.sumLastRow();
						}

					} else if (StringUtils.contains(app_contexto, "FRAMEWORK")) {

						List<MetodoDeclarado> metodos = getMetodosDeclaradosBySteps(step_simplificado, td);

						for (MetodoDeclarado m : metodos) {
							String item = "";
							fourTab();
							asterisco();
							asterisco();
							informe += "Test Step a construir: " + m.getLlamadaMetodo();

							contexto = (StringUtils.containsIgnoreCase(m.toString(), "common") ? m.toString()
									: contexto);

							if (m.getParametros() != null) {
								salto();
								fourTab();
								asterisco();
								asterisco();
								informe += "Test Step parameters: " + m.getParametros();
								salto();
							} else
								salto();

							boolean existeTestCase = false;

							if (esTarjetaNueva) {

								item += "Metodo a implementar: " + m.getLlamadaMetodo();
								item += (m.getParametros() != null && m.getParametros().size() > 0
										? "-- Parametros: " + m.getParametros() : "");

								if (!m.isImplementado())
									existeTestCase = false;
								else
									existeTestCase = true;

							}

							if (excelMode) {
								if (m.isImplementado()) {
									// ExcelUtils.applyStyleToRange("mimplementado");
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Metodo implementado", "Existente");

								} else {
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Metodo implementado", "Inexistente");
								}

								ExcelUtils.escribirNuevaCeldaSegunCabcera("Metodos a implementar",
										m.getLlamadaMetodo());
								if (m.getParametros() != null && m.getParametros().size() > 0)
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Par�metros",
											m.getParametros().toString());
								else
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Par�metros", "public void");

								ExcelUtils.applyStyleToRange(tipoerror);
								ExcelUtils.sumLastRow();
							}

							tmp_metodo_declarados.add(new TestToImplement(app, contexto, test.getTestCaseName(),
									step_simplificado, m.getLlamadaMetodo(), m.getCategoria(), m.getParametros()));

							if (!existeEnStepsToImplement(m.getLlamadaMetodo(), app, contexto)) {
								testStepsToImplement.add(new TestToImplement(app, contexto, test.getTestCaseName(),
										step_simplificado, m.getLlamadaMetodo(), m.getCategoria(), m.getParametros()));

								if (excelMode) {
//									excelMetodosUnicos.escribirNuevaCeldaSegunCabcera("Frontal", app);
//									excelMetodosUnicos.escribirNuevaCeldaSegunCabcera("Contexto", contexto);
//									excelMetodosUnicos.escribirNuevaCeldaSegunCabcera("Metodo", m.getLlamadaMetodo());
//									excelMetodosUnicos.sumLastRow();
								}

								if (esTarjetaNueva) {
									if (!existeTestCase)
										to.addItemToCheckList(new TrelloItemObject(item, existeTestCase));
								}
							}

							item = "";

						}
						salto();
					}

					else if (StringUtils.contains(app_contexto, "IMPL")) {

						List<MetodoDeclarado> metodos = getMetodosDeclaradosBySteps(step_simplificado, td);

						for (MetodoDeclarado m : metodos) {
							String item = "";

							contexto = (StringUtils.containsIgnoreCase(m.toString(), "common") ? m.toString()
									: contexto);

							if (excelMode) {

								if (m.isImplementado()) {
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Metodo implementado", "Existente");
								} else {
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Metodo implementado", "Inexistente");
								}

								ExcelUtils.escribirNuevaCeldaSegunCabcera("Metodos a implementar",
										m.getLlamadaMetodo());

								if (m.getParametros() != null && m.getParametros().size() > 0)
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Par�metros",
											m.getParametros().toString());
								else
									ExcelUtils.escribirNuevaCeldaSegunCabcera("Par�metros", "public void");

								ExcelUtils.applyStyleToRange(tipoerror);
								ExcelUtils.sumLastRow();
							}

							boolean existeTestCase = false;

							if (esTarjetaNueva) {

								item += "Metodo a implementar: " + m.getLlamadaMetodo();
								item += (m.getParametros() != null && m.getParametros().size() > 0
										? "-- Parametros: " + m.getParametros() : "");

								if (!m.isImplementado())
									existeTestCase = false;
								else
									existeTestCase = true;

							}

							tmp_metodo_declarados.add(new TestToImplement(app, contexto, test.getTestCaseName(),
									step_simplificado, m.getLlamadaMetodo(), m.getCategoria(), m.getParametros()));

							if (!existeEnStepsToImplement(m.getLlamadaMetodo(), app, contexto)) {
								testStepsToImplement.add(new TestToImplement(app, contexto, test.getTestCaseName(),
										step_simplificado, m.getLlamadaMetodo(), m.getCategoria(), m.getParametros()));

								if (excelMode) {
//									excelMetodosUnicos.escribirNuevaCeldaSegunCabcera("Frontal", app);
//									excelMetodosUnicos.escribirNuevaCeldaSegunCabcera("Contexto", contexto);
//									excelMetodosUnicos.escribirNuevaCeldaSegunCabcera("Metodo", m.getLlamadaMetodo());
//									excelMetodosUnicos.sumLastRow();
								}

								if (esTarjetaNueva)
									if (!existeTestCase)
										to.addItemToCheckList(new TrelloItemObject(item, existeTestCase));
							}

							item = "";

						}

						salto();
					}

				}

				// aqui he de comparar los temporales (metodos del reporte) con
				// los de la cheklist
				// y si cambian he de generar otra checklist con los nuevos
				// items
				// ademas si hay cambios, he de quitarla de donde esta y pasarla
				// al backlog de modificados (avisar a su propietario?)

				if (!esTarjetaNueva) {

					if (seHanAnadidoOQuitadoPasos(checkItems, tmp_metodo_declarados)) {

						// si se han a�adido o quitado, he de hacer una nueva
						// checklist
						// antes recorro la actual y guardo los metodos en un
						// Excel (segun app, contexto)

						// agregarPasosRealizadosAHistoricoDePasos(checklist,
						// tmp_metodo_declarados);

					} else {
						// si no se han a�adido pasos o quitado,
						// puede que se hayan modificado, asi que he de mirar
						// uno a uno cuales se han modificado.

						// 1- los pasos que ya no esten en el nuevo listado los
						// cargo en un historico de pasos modificados.
						// 2- ademas, hay que eliminar la check list y crear una
						// nueva.
						// 3- Hay que pasar la tarjeta al backlog de tarjetas
						// con modificaciones.

						// NO MODIFICARLAS DE MOMENTO (20/01/2018)
						// TrelloChecklistsUtils.deleteChecklist(checklist);
						//
						// TrelloChecklistsUtils.addListCheckItemsAChecklist(checklist,
						// tmp_itemObject);

					}

					// miro el array posicion a posicion y comparo si es igual
					// de un lado al otro, si algo cambia en la misma linea es
					// que se ha modificado,
					// si se ha modificado regenero el cheklist...
				}

				// si es una nueva tarjeta hago conexion con la API y meto
				// elementos en checklist.
				// respuesta: no puedo hacerlo porqu� he de ordenar antes el
				// listado.

				else if (esTarjetaNueva)
					listTrelloObjects.add(to);

			}

			else {

				threeTab();
				asterisco();
				asterisco();
				asterisco();

				informe += "El test case esta en Draft.";

				salto();

			}
		}
	}

	private static boolean seHanAnadidoOQuitadoPasos(List<CheckItem> checkItems, List<TestToImplement> tmp_test) {
		if (checkItems == null || tmp_test == null)
			return false;
		else
			return checkItems.size() != tmp_test.size();
	}

	@SuppressWarnings("static-access")
	private static List<MetodoDeclarado> getMetodosDeclaradosBySteps(String step_simplificado, String testData) {
		parserClass.getMetodoDeclarado(step_simplificado, testData);
		int a = 0;
		while (a < parserClass.listadoMetodosTmp.size()) {
			MetodoDeclarado m = parserClass.listadoMetodosTmp.get(a);
			if (parserClass.getMetodoClaseSegunTestStep(m.getLlamadaMetodo()) != null) {
				parserClass.listadoMetodosTmp.get(a).setImplementado(true);

			}
			a++;
		}
		return parserClass.getCurrentListadoMetodosByTestStep();
	}

	@SuppressWarnings("static-access")
	private static List<MetodoDeclarado> getMetodosDeclaradosByStep(String step_simplificado, String testData) {
		List<MetodoDeclarado> existentes = new ArrayList<MetodoDeclarado>();

		parserClass.getMetodoDeclarado(step_simplificado, testData);
		int a = 0;
		while (a < parserClass.listadoMetodosTmp.size()) {
			MetodoDeclarado m = parserClass.listadoMetodosTmp.get(a);
			boolean existeMetodoEnClase = parserClass.getMetodoClaseSegunTestStep(m.getLlamadaMetodo()) != null;
			
			if (existeMetodoEnClase) 
				existentes.add(m);
			
			a++;
		}
		parserClass.listadoMetodosTmp = new ArrayList<MetodoDeclarado>();
		return existentes;
	}

	public static boolean existeEnStepsToImplementDiccionario(String app, String contexto, String step) {

		boolean existe = false;

		for (TestToImplement savedTestToImplement : testStepsToImplementInDiccionario) {
			String s_app = savedTestToImplement.getApp();
			String s_con = savedTestToImplement.getContexto();
			String s_step = savedTestToImplement.getStep();

			if (StringUtils.equalsIgnoreCase(s_app, app) && StringUtils.containsIgnoreCase(contexto, s_con)
					&& StringUtils.equalsIgnoreCase(s_step, step)) {
				existe = true;
				break;
			}
		}

		return existe;
	}

	public static boolean existeEnStepsToImplement(String metodoDeclarado, String app, String contexto) {

		boolean existe = false;

		for (TestToImplement savedTestToImplement : testStepsToImplement) {

			String s_app = savedTestToImplement.getApp();
			String s_con = savedTestToImplement.getContexto();
			String s_met = savedTestToImplement.getLlamadaMetodo();

			if (StringUtils.equalsIgnoreCase(s_app, app) && StringUtils.containsIgnoreCase(s_con, contexto)
					&& StringUtils.equalsIgnoreCase(s_met, metodoDeclarado)) {
				existe = true;
				break;
			}
		}

		return existe;
	}

	public static boolean existeEnStepsToImplement(String metodoDeclarado, String app, String contexto,
			ParserTestCasesFromDiccionario_deepLearning parserClass) {

		boolean existe = false;

		for (TestToImplement savedTestToImplement : testStepsToImplement) {

			String s_app = savedTestToImplement.getApp();
			String s_con = savedTestToImplement.getContexto();
			String s_met = savedTestToImplement.getLlamadaMetodo();

			if (StringUtils.equalsIgnoreCase(s_app, app) && StringUtils.containsIgnoreCase(s_con, contexto)
					&& StringUtils.equalsIgnoreCase(s_met, metodoDeclarado)) {
				existe = true;
				break;
			}
		}

		return existe;
	}

	private static String asterisco() {
		return informe += "*";
	}

	private static String salto() {
		return informe += "\n";
	}

	private static String tab() {
		return informe += "\t";
	}

	private static void twoTab() {
		tab();
		tab();
	}

	private static void threeTab() {
		tab();
		tab();
		tab();
	}

	private static void fourTab() {
		threeTab();
		tab();
	}

	public static class TestToImplement {

		@Getter
		@Setter
		String app;
		@Getter
		@Setter
		String contexto;
		@Getter
		@Setter
		String testCase;
		@Getter
		@Setter
		String step;
		@Getter
		@Setter
		Integer categoria;
		@Getter
		@Setter
		String llamadaMetodo;
		@Getter
		@Setter
		List<String> parametros;

		public TestToImplement(String app, String contexto, String testCase, String step, String llamadaMetodo,
				Integer categoria, List<String> parametros) {
			this.app = app;
			this.contexto = contexto;
			this.testCase = testCase;
			this.step = step;
			this.llamadaMetodo = llamadaMetodo;
			this.parametros = parametros;
			this.categoria = categoria;
		}

		public TestToImplement(String app, String contexto, String testCase, String step) {
			this.app = app;
			this.contexto = contexto;
			this.testCase = testCase;
			this.step = step;
		}

	}

}
