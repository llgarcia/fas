package com.testing_web.sogeti.___global_tools.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.sogeti.pruebaSpira.model.TestCase;
import com.testing_web.sogeti.___global_tools.excel_utils.TestCaseExcel;
import com.testing_web.sogeti.___global_tools.parser.deep_learning.ParserTestCasesFromDiccionario_deepLearning;
import com.testing_web.sogeti.___global_tools.parser.utils_parser.ParametroJavaParser;

import utils_selenium.GenericCommon;

/**
 * @author ll.saptest
 * 
 * Genera los metodos parseados en una nueva clase.
 *
 */

public class GeneradorClassTestCases {
		
	public static void generarClaseSegunTestCases(List<TestCaseExcel> testCases){		
		
		Map<String, List<TestCaseExcel>> testCasesAgrupados = agruparTestCasesPorAplicacion(testCases);
		
		
		// aqui se define el nombre de la clase, con lo cual se han de agrupar los metodos que son de la aplicacion "N", generar la clase y guardarla
		// luego volver a llamar los testcases de la siguiente app y volver a generar clase despues de "javaGenerator.generarClase();"
		
		for (Map.Entry<String, List<TestCaseExcel>> entry : testCasesAgrupados.entrySet()){
			
			ParserTestCasesFromDiccionario_deepLearning javaGenerator = new ParserTestCasesFromDiccionario_deepLearning();
			
			String app = StringUtils.lowerCase(GenericCommon.reemplazarEspaciosYCapitalizarCadena(GenericCommon.replaceAccents(entry.getKey())));
			javaGenerator.declararPackage("com.testing_web.sogeti.integration_local_tests." + app);
			javaGenerator.declararImports("com.testing_web.sogeti.sap.pantallas.sap.main.testing_sap_m.Tests_funcionales.Test_Cases_AC.OApunteContable1");
			javaGenerator.declararImports("testing_common.ScreenshotsCommon");
			javaGenerator.declararImports("java.util.List");
			
			javaGenerator.declararExtendsDeClase("AbstractBaseTestCase");
			
			javaGenerator.definirNombreDeClase(entry.getKey());	
			
			generarMetodosSobreescritos(javaGenerator);
			boolean seGeneranTCs = definirLlamadasMetodosTestCase(javaGenerator, entry.getValue());
			
			if(seGeneranTCs)
				javaGenerator.generarClase(entry.getKey());
			
		}
		
//		javaGenerator.definirNombreDeClase();	
//		
//		
//		generarMetodosSobreescritos(javaGenerator);
//		definirLlamadasMetodosTestCase(javaGenerator, testCases);
//		
//		javaGenerator.generarClase();
	}
	
	private static Map<String, List<TestCaseExcel>> agruparTestCasesPorAplicacion(List<TestCaseExcel> testCases) {
		
		List<TestCaseExcel> tmp_testCases = testCases;
		
		Map<String, List<TestCaseExcel>> testCasesAgrupados = new HashMap<String, List<TestCaseExcel>>();
		List<TestCaseExcel> tcs_tmp = new ArrayList<TestCaseExcel>();
		
		String app = "";
		
		for(int a = 0; a < tmp_testCases.size(); a++){
			
			TestCaseExcel tc = tmp_testCases.get(a);
			
			app = StringUtils.isEmpty(app) ? tc.getTestCaseAplicacion() : app;
			
			if(StringUtils.equals(app, tc.getTestCaseAplicacion())){
				System.out.println(tc.getTestCaseAplicacion() +" ____ " + tc.getTestCaseName());
				tcs_tmp.add(tc);
				tmp_testCases.remove(tc);
				a--;
				
			}
						
			if((a+1) == tmp_testCases.size()){
				a = 0;
				testCasesAgrupados.put(app, tcs_tmp);
				app = "";
				tcs_tmp = new ArrayList<TestCaseExcel>();
			}
		}
		
		
		return testCasesAgrupados;
	}
		
	public static boolean definirLlamadasMetodosTestCase(ParserTestCasesFromDiccionario_deepLearning javaGenerator, List<TestCaseExcel> testCases) {
		
		// por cada TESTCASE se deberia de poner un "setTestCaseName" -- es necesario --> "setTestCaseName(getNameOfThisTestCase());"
		// por cada TESTCASE se deberia de poner un "setUser" dentro de cada LOGIN*.java -- no hace falta, esto se mete en la propia clase login.java
		// por cada TESTCASE se deberia de poner un "setPassword" dentro de cada LOGIN*.java -- no hace falta, esto se mete en la propia clase login.java
		// por cada TESTCASE se deberia de poner un "setTestCaseCanonicalName" o "setTestCasePath" -- no hace falta
			
		boolean seGeneranAlgunos = false;
		
		for(Integer pos = 0; pos <= testCases.size()-1; pos++){
			
			TestCaseExcel test 		= testCases.get(pos);
			System.out.println(test.getTestCaseName());
			if(GeneradorInformeParseo_refactorizado.isTestCaseComplete(test)){
				if(!StringUtils.contains(test.getTestCaseStatus(), "Draft") 
						&& !StringUtils.contains(test.getTestCaseStatus(), "Obsolete")
						&& !StringUtils.contains(test.getTestCaseStatus(), "Obsoleto") 
						&& !StringUtils.contains(test.getTestCaseStatus(), "Ready for Review")){
				
					
					
					String testCaseName = GenericCommon.replaceAccents( 
												StringUtils.replace(
													GenericCommon.removeRareChars(test.getTestCaseName()), " ", ""));
					
					System.out.println("TCNAME " + testCaseName);
					
					javaGenerator.declararNombreMetodo(testCaseName);
					
					javaGenerator.parsearMetodos(testCaseName, test.getTestSteps(), test.getSampleData(), test.getExpectedResult());
					
					javaGenerator.generarMetodoTestCase();
					
					seGeneranAlgunos = true;
				}
			}
		}
		
		return seGeneranAlgunos;
	}
	
//	public static void generarMetodoBefore(ParserTestCasesFromDiccionario_deepLearning javaGenerator) {
//		
//		javaGenerator.declararLlamadaMetodo("ini", "public", "void", "Before", new Exception());
//		
//		javaGenerator.definirLlamadaDeMetodo("setBaseUrl");
//		javaGenerator.definirArgumentoDeMetodo("\"http://acrmmig.arquia.com:8062/sap(bD1lcyZjPTUwMCZkPW1pbg==)/uif_logon/default.htm\"");
//		javaGenerator.escribirMetodo();
//		
//		
//		javaGenerator.definirLlamadaDeMetodo("setTestNameClass");
//		javaGenerator.definirArgumentoDeMetodo("this.getClass().getName()");
//		javaGenerator.escribirMetodo();
//		
//		javaGenerator.generarMetodo();		
//				
//	}
	
	private static void generarMetodosSobreescritos(ParserTestCasesFromDiccionario_deepLearning javaGenerator) {
		definirSetBaseUrl(javaGenerator);
		definirSetUser(javaGenerator);
		definirSetPassword(javaGenerator);
		definirSetNameClass(javaGenerator);
		definirSetTestCaseName(javaGenerator);	
		definirGetApp(javaGenerator);
	}
	
	private static void definirSetBaseUrl(ParserTestCasesFromDiccionario_deepLearning javaGenerator) {
		javaGenerator.declararNombreMetodo("setBaseUrl");
		javaGenerator.declararReturnMetodo("void");
		javaGenerator.declararAnotacion("Override");
		ParametroJavaParser parametro = new ParametroJavaParser("baseUrll", "string");
		javaGenerator.definirArgumentosMetodo(parametro);
		javaGenerator.definirAsignacionEnMetodo("baseUrl", "baseUrll");
		javaGenerator.generarMetodosSobreescritos();
	}
	
	private static void definirSetUser(ParserTestCasesFromDiccionario_deepLearning javaGenerator){ 
		javaGenerator.declararNombreMetodo("setUser");
		javaGenerator.declararReturnMetodo("void");
		javaGenerator.declararAnotacion("Override");
		ParametroJavaParser parametro = new ParametroJavaParser("userr", "string");
		javaGenerator.definirArgumentosMetodo(parametro);
		javaGenerator.definirAsignacionEnMetodo("user", "userr");
		javaGenerator.generarMetodosSobreescritos();
	}
	
	private static void definirSetPassword(ParserTestCasesFromDiccionario_deepLearning javaGenerator){ 
		javaGenerator.declararNombreMetodo("setPassword");
		javaGenerator.declararReturnMetodo("void");
		javaGenerator.declararAnotacion("Override");
		ParametroJavaParser parametro = new ParametroJavaParser("passwordd", "string");
		javaGenerator.definirArgumentosMetodo(parametro);
		javaGenerator.definirAsignacionEnMetodo("password", "passwordd");
		javaGenerator.generarMetodosSobreescritos();
	}
	
	private static void definirSetNameClass(ParserTestCasesFromDiccionario_deepLearning javaGenerator){ 
		javaGenerator.declararNombreMetodo("setTestNameClass");
		javaGenerator.declararReturnMetodo("void");
		javaGenerator.declararAnotacion("Override");
		ParametroJavaParser parametro = new ParametroJavaParser("testNameClass", "string");
		javaGenerator.definirArgumentosMetodo(parametro);
		javaGenerator.definirAsignacionEnMetodo("testClassName", "testNameClass");
		javaGenerator.generarMetodosSobreescritos();
	}
	
	private static void definirSetTestCaseName(ParserTestCasesFromDiccionario_deepLearning javaGenerator){ 
		javaGenerator.declararNombreMetodo("setTestCaseName");
		javaGenerator.declararReturnMetodo("void");
		javaGenerator.declararAnotacion("Override");
		ParametroJavaParser parametro = new ParametroJavaParser("testCaseNamee", "string");
		javaGenerator.definirArgumentosMetodo(parametro);
		javaGenerator.definirAsignacionEnMetodo("testCaseName", "testCaseNamee");
		javaGenerator.generarMetodosSobreescritos();
	}
	
	private static void definirGetApp(ParserTestCasesFromDiccionario_deepLearning javaGenerator){ 
		javaGenerator.declararNombreMetodo("getApp");
		javaGenerator.declararReturnMetodo("string");
		javaGenerator.declararAnotacion("Override");
		javaGenerator.definirReturnEnMetodo("null");
		javaGenerator.generarMetodosSobreescritos();
	}

}
