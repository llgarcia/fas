package com.testing_web.sogeti.___global_tools.parser;

import java.util.List;

import org.junit.Test;

import com.testing_web.sogeti.___global_tools.excel_utils.ExcelUtils;
import com.testing_web.sogeti.___global_tools.excel_utils.TestCaseExcel;
import com.testing_web.sogeti.___global_tools.excel_utils.TrataTestCasesByExcel;
import com.testing_web.sogeti.___global_tools.propiedades.CargaArchivoPropiedades;

public class __EjecutarGeneracionTestCases {
	
	
	@Test public void generar() {		
		
		CargaArchivoPropiedades.load("crm", "oferta", "depositos", "crm.oferta.properties");
				
		/** BCA */

//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		List<TestCaseExcel> testCaseParsed = TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Dep�sitos a plazo", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		GeneradorClassTestCases.generarClaseSegunTestCases(testCaseParsed);
//	
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		List<TestCaseExcel> testCaseParsed1 = TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Cuentas corrientes", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		GeneradorClassTestCases.generarClaseSegunTestCases(testCaseParsed1);
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("P�lizas de Cr�dito", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Cheques", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Transferencias", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		List<TestCaseExcel> tests = TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Traspasos", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		GeneradorClassTestCases.generarClaseSegunTestCases(tests);
		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Operatoria Banco Santander", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Abono Pensiones", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Embargos", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Inem", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Blanqueo de Capitales", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		List<TestCaseExcel> testCaseParsed2 = TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Recaudaci�n de Tributos", "BCA");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		GeneradorClassTestCases.generarClaseSegunTestCases(testCaseParsed2);
		
		/** CRM */
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Planes de Pensiones", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Dep�sitos a plazo", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Cuentas corrientes", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("P�lizas de Cr�dito", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		ExcelUtils.descargar();
		
//
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Avales", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		ExcelUtils.descargar();
		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Leasings", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		ExcelUtils.descargar();
		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Pr�stamos", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
		

//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Seguros Generales", "CRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();

		
		/** TRM **/
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Valores", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();		
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Avales", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Fondos de Inversi�n", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Fondos de Inversi�n Inversis", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Planes de Pensiones", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Seguros Generales", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//
//
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Titulos Arquia", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Seguros de Vida", "TRM");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////		
////		
////		/** CML */
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Leasings", "CML");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
//		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Pr�stamos", "CML");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////		
////		
////		/** FICO **/
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Arqueo de Caja", "FICO");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////
////		/** MEPA **/
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Medios de pago", "MePa");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
////		
	
		
		/** REPORTING */
		
//		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
//		TrataTestCasesByExcel.parsearTestCasesSegunAplicacionYWorkgroup("Reportes Organismo Supervisores", "Reporting");
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
//		GeneradorInformeParseo_refactorizado.generar();
		
		
		
		
		
		ExcelUtils.cargarFicheroDeTestCasesRefactoringFromNewestReport("20180323_135834ReportFromSpira_total", "Test Cases");
		
		List<TestCaseExcel> testCaseParsed = TrataTestCasesByExcel.parsearTestCases();
//				
//		GeneradorInformeParseo_refactorizado.generarExcel();
//		GeneradorInformeParseo_refactorizado.generarTrello();
		GeneradorInformeParseo_refactorizado.generar();
//		
//
//		GeneradorClassTestCases.generarClaseSegunTestCases(testCaseParsed);
		
		
	}

}
