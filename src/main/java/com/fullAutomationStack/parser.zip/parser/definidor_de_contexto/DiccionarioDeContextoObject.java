package com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto;

import org.apache.commons.lang3.StringUtils;

/**
 * @author ll.saptest
 * 
 * La clase almacena la aplicacion y contexto que conlleva un "test step".
 *
 */
public class DiccionarioDeContextoObject {
	
	public String testStep;
	public String aplicacion;
	public String contexto;
	
	public DiccionarioDeContextoObject(String testStep, String aplicacion, String contexto) {
		super();
		this.testStep = testStep;
		this.aplicacion = aplicacion;
		this.contexto = contexto;
	}
	
	public boolean tieneContextoDefinido(){
		return StringUtils.isNotEmpty(this.contexto);
	}
	
	
}
