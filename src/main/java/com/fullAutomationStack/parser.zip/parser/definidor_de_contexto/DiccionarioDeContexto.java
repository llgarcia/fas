package com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
/**
 * @author ll.saptest
 *
 * Esta clase esta dise�ada para identificar los TEST STEPS que hacen referencia a un cambio de contexto. 
 * 
 * Se considera un cambio de contexto: un cambio de app y dentro de la misma app menus diferentes.
 * Por lo tanto todos los setups van a estar identificados aqui, igual que el acceso a todos los menus y sub menus de las aplicaciones que sepan de antemano el contexto al que pertenecen. 
 * 
 * Los casos donde no se sepa el contexto concreto al que pertenece un TEST STEP se trata directamente en la clase "ContextJavaParser".
 * 
 */

public class DiccionarioDeContexto {

	protected static List<DiccionarioDeContextoObject> diccionario;
	
	public static void iniDiccionario() {
		diccionario = new ArrayList<DiccionarioDeContextoObject>();
		
		// TF 
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"lanzar el terminal financiero y navegar a funcionalidad\" con ${Funcionalidad}${Usuario}${Contrasena}${Oficina}", "tf", ""));
		diccionario.add(new DiccionarioDeContextoObject("582", "Llamar el setup \"lanzar el terminal financiero y navegar a funcionalidad\" con ${Funcionalidad}${Usuario}${Contrasena}${Oficina}", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar al setup \"lanzar el terminal financiero y navegar a funcionalidad\"", "tf", ""));
//		diccionario.add(new DiccionarioDeContextoObject("582", "Llamar el setup \"lanzar el terminal financiero y navegar a funcionalidad\" con:\n${funcionalidad}", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar al setup \"Lanzar el Terminal Financiero en la pantalla Home\"", "tf", "home"));
		diccionario.add(new DiccionarioDeContextoObject("2403", "Llamar al setup \"Lanzar el Terminal Financiero en la pantalla Home\"", "")); 
				
		diccionario.add(new DiccionarioDeContextoObject("Llamar al setup \"Lanzar el Terminal Financiero y navegar a Cuadre de Caja\"", "tf", "caja")); 
		diccionario.add(new DiccionarioDeContextoObject("2405", "Llamar al setup \"Lanzar el Terminal Financiero y navegar a Cuadre de Caja\"", "tf"));

		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"Lanzar el Terminal Financiero y navegar a Caja\"", "tf", "caja")); 
		diccionario.add(new DiccionarioDeContextoObject("3969", "Llamar el setup \"Lanzar el Terminal Financiero y navegar a Caja\"", "tf"));
		
		diccionario.add(new DiccionarioDeContextoObject("CRM_B�squeda_Interlocutor", "tf", "home")); 
		diccionario.add(new DiccionarioDeContextoObject("583", "CRM_B�squeda_Interlocutor", "")); 
		
		diccionario.add(new DiccionarioDeContextoObject("CRM_B�squeda_Empleado", "tf", "home")); 
		diccionario.add(new DiccionarioDeContextoObject("584", "CRM_B�squeda_Empleado", "")); 
		
		diccionario.add(new DiccionarioDeContextoObject("B�squeda Interlocutor Intervinientes", "tf", "home")); 
		diccionario.add(new DiccionarioDeContextoObject("725", "B�squeda Interlocutor Intervinientes", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("BCA_Inem_R_Consulta_ficheros_Oficina_buscar", "tf", "home")); 
		diccionario.add(new DiccionarioDeContextoObject("691", "BCA_Inem_R_Consulta_ficheros_Oficina_buscar", "")); 
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"Seleccionar una opci�n especifica de la tabla\" ${Valor_Producto}${Tabla_Producto}${Enlace_Proceso}", "tf", ""));
		diccionario.add(new DiccionarioDeContextoObject("3716", "Llamar el setup \"Seleccionar una opci�n especifica de la tabla\" ${Valor_Producto}${Tabla_Producto}${Enlace_Proceso}", ""));
		
		
		// todo a revisar
//		diccionario.add(new DiccionarioDeContextoObject("CRM_Firmar_Ofertas", "tf", "home")); 
//		diccionario.add(new DiccionarioDeContextoObject("3424", "CRM_Firmar_Ofertas", "")); 
				
		diccionario.add(new DiccionarioDeContextoObject("CRM_B�squeda_Pr�stamos", "tf", "home")); 
		diccionario.add(new DiccionarioDeContextoObject("588", "CRM_B�squeda_Pr�stamos", "")); 
		
		diccionario.add(new DiccionarioDeContextoObject("Test Data Valores para Tesorer�a", "tf", "home")); 
		diccionario.add(new DiccionarioDeContextoObject("2769", "Test Data Valores para Tesorer�a", "")); 
		
		diccionario.add(new DiccionarioDeContextoObject("Acceder a transacci�n SAP", "SAP", ""));
		diccionario.add(new DiccionarioDeContextoObject("3973", "Acceder a transacci�n SAP", "sap"));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar al setup \"Navegar dentro de las aplicaciones\" con:${Funcionalidad}${Tabla_producto}${Valor_producto}", "tf", ""));
		diccionario.add(new DiccionarioDeContextoObject("3726", "Llamar al setup \"Navegar dentro de las aplicaciones\" con:${Funcionalidad}${Tabla_producto}${Valor_producto}", ""));

		diccionario.add(new DiccionarioDeContextoObject("Firmar Ofertas", "tf", ""));
		diccionario.add(new DiccionarioDeContextoObject("3424", "Firmar Ofertas", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"Anotar_Valores_para_Validacion_Contable\" con:${concepto}${Funcionalidad}${Import}${Tabla_producto}${Valor_producto}", "", ""));
		diccionario.add(new DiccionarioDeContextoObject("4516", "Llamar el setup \"Anotar_Valores_para_Validacion_Contable\" con:${concepto}${Funcionalidad}${Import}${Tabla_producto}${Valor_producto}", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"BCA_Apunte_Contable_Libro_Mayor_1_Posici�n\"", "", ""));
		diccionario.add(new DiccionarioDeContextoObject("3742", "Llamar el setup \"BCA_Apunte_Contable_Libro_Mayor_1_Posici�n\"", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"Anotar_Valores_para_Validacion_Contable_TO\" con:${Funcionalidad}${Import}${Tabla_product}${Valor_product}", "", ""));
		diccionario.add(new DiccionarioDeContextoObject("7390", "Llamar el setup \"Anotar_Valores_para_Validacion_Contable_TO\" con:${Funcionalidad}${Import}${Tabla_product}${Valor_product}", ""));
		
		
		
		// solamente se ha de entender
//		diccionario.add(new DiccionarioDeContextoObject("Seleccionar una opci�n especifica de la tabla${Valor_Producto} ${Tabla_producto}${Valor_producto}", "tf", ""));
//		diccionario.add(new DiccionarioDeContextoObject("3726", "Seleccionar una opci�n especifica de la tabla${Funcionalidad} ${Tabla_producto}${Valor_producto}", ""));
//		
		
		
		// CRM 
		
		diccionario.add(new DiccionarioDeContextoObject("Logear en CRM y navegar a una oferta", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("684", "Logear en CRM y navegar a una oferta", ""));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"CRM_R_Rellenar_Datos_Oferta_Depositos\"", "crm", "oferta"));
		diccionario.add(new DiccionarioDeContextoObject("721", "Llamar el setup \"CRM_R_Rellenar_Datos_Oferta_Depositos\"", "oferta"));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"CRM_R_Rellenar_Datos_Oferta_Ctas_Corrientes\"", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("2388", "Llamar el setup \"CRM_R_Rellenar_Datos_Oferta_Ctas_Corrientes\"", "oferta")); 

//		diccionario.add(new DiccionarioDeContextoObject("CRM_R_Buscar_Oferta", "crm", "oferta")); 
//		diccionario.add(new DiccionarioDeContextoObject("723", "CRM_R_Buscar_Oferta", ""));

		// esto es lo que habia antes.... creo que estaba "con: ${Estado}" por la PoC que se hizo en Noviembre.
		
//		diccionario.add(new DiccionarioDeContextoObject("llamar el setup \"CRM_R_B�scar_Oferta\" con:${Estado}", "crm", "oferta"));
//		diccionario.add(new DiccionarioDeContextoObject("723", "llamar el setup \"CRM_R_B�scar_Oferta\" con:${Estado}", "oferta"));
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"CRM_R_B�scar_Oferta\" con: ${Usuario}${Contrasena}${Rol_y_Oficina}${ID_de_Oferta}", "crm", "oferta"));
		diccionario.add(new DiccionarioDeContextoObject("723", "Llamar el setup \"CRM_R_B�scar_Oferta\" con: ${Usuario}${Contrasena}${Rol_y_Oficina}${ID_de_Oferta}", "oferta"));
		
		
		diccionario.add(new DiccionarioDeContextoObject("CRM_R_Rellenar_Datos_Oferta_Tarjeta", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("3419", "CRM_R_Rellenar_Datos_Oferta_Tarjeta", ""));

		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"Logear a Internet Banking y navegar desde sub men�\"", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("2723", "Llamar el setup \"Logear a Internet Banking y navegar desde sub men�\"", ""));

		diccionario.add(new DiccionarioDeContextoObject("Logear a Internet Banking y navegar desde men�", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("2724", "Logear a Internet Banking y navegar desde men�", ""));

		diccionario.add(new DiccionarioDeContextoObject("Logear a Internet Banking y navegar desde cabecera", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("2725", "Logear a Internet Banking y navegar desde cabecera", ""));

		diccionario.add(new DiccionarioDeContextoObject("Logear a Internet Banking y navegar a pagin Home", "crm", "oferta")); 
		diccionario.add(new DiccionarioDeContextoObject("2726", "Logear a Internet Banking y navegar a pagin Home", ""));
		
		
		
		
		// IB
		
		diccionario.add(new DiccionarioDeContextoObject("Llamar el setup \"Lograr a Internet Banking y navegar desde sub men�\"", "ib", ""));
		
		
		/** SAP */
		diccionario.add(new DiccionarioDeContextoObject("Llamar al setup \"BCA_Apunte_Contable_Libro_Mayor_1_Posici�n\"", "sap", "sap"));
		diccionario.add(new DiccionarioDeContextoObject("3742", "Llamar al setup \"BCA_Apunte_Contable_Libro_Mayor_1_Posici�n\"", "sap"));
		
		
	}
	
	public static DiccionarioDeContextoObject getContextObjectByTestStep(String testStep) {
	
		testStep = StringUtils.replace(testStep, "\n", "");
		
		if(diccionario == null) iniDiccionario();
	
		DiccionarioDeContextoObject obj = null;
				
		for(DiccionarioDeContextoObject c : diccionario){
//			System.out.println("DIC: " + c.testStep + " EXPEC: "+ testStep);
			if(!comprovarSiEsInteger(testStep) && ((StringUtils.equalsIgnoreCase(testStep, c.testStep) || StringUtils.containsIgnoreCase(testStep, c.testStep)))){
				obj = c;
				break;
			} else {
				if(StringUtils.equalsIgnoreCase(testStep, c.testStep)){
					obj = c;
					break;
				}
					
			}
		}
			
		return obj;
	}
	
	private static boolean comprovarSiEsInteger(String i) {
		try {
			Integer res = Integer.parseInt(i);
			return true;
		} catch(NumberFormatException e) {
			return false;
		}
	}
	
}
