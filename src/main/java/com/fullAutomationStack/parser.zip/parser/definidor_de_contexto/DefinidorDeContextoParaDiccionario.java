package com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.testing_web.sogeti.___global_tools.parser.ParserTestCasesFromDiccionario;

import utils_selenium.GenericCommon;

/**
 * @author ll.saptest
 *
 * Define el diccionario, los pasos, los procesos y validaciones a utilizar cuando se parsean los test steps.
 * 
 */
public class DefinidorDeContextoParaDiccionario {
	
	public static ContextoObject devolverControlador(String testStep, String sample_data, String expectedResult) {
					
		ContextoObject co = null;
		String contexto_explicito = null;
		DiccionarioDeContextoObject context = null;
		
		if(StringUtils.contains(testStep, "Call")){
			context = DiccionarioDeContexto.getContextObjectByTestStep(expectedResult);
		} else {
			context = DiccionarioDeContexto.getContextObjectByTestStep(testStep);
		}
		
		if(StringUtils.containsIgnoreCase(testStep, "Seleccionar una opci�n especifica de la tabla"))
			co = new ContextoObject(null, null, null, null, null, "Seleccionar una opci�n especifica de la tabla", "tf");
		else if (StringUtils.containsIgnoreCase(testStep, "Firmar Ofertas")){
			co = new ContextoObject(null, null, null, null, null, "Firmar Ofertas", "tf");
		} else 
			
			if(context != null){
						
				if(context.tieneContextoDefinido()){
				
					co = identificarControllerByAplicacionYContexto(context.aplicacion, context.contexto);
								
				} else {
					
	//				String contextoBySampleData = StringUtils.replace(ParserTestCasesFromDiccionario.devolverParametrosSiTieneSampleData(sample_data).get(0), "\"", "");
					
					contexto_explicito = identificarPrametrosDeContexto(ParserTestCasesFromDiccionario.devolverParametrosSiTieneSampleDataConClave(sample_data));
					
					if(StringUtils.isEmpty(contexto_explicito))
						co = identificarControllerByAplicacionYContexto(context.aplicacion, ParserTestCasesFromDiccionario.devolverParametrosSiTieneSampleData(sample_data));
					else
						co = identificarControllerByAplicacionYContexto(context.aplicacion, contexto_explicito);
							
				}
			}
	
				
		return co;
	}
	
	private static String identificarPrametrosDeContexto(List<String> parametros){
		
		String res = null;
		
		for(String parametro : parametros){
			
			parametro = GenericCommon.replaceAccents(parametro);
			
			if(StringUtils.containsIgnoreCase(parametro, "funcionalidad") || StringUtils.containsIgnoreCase(parametro, "objecto_menu")){
				res = ParserTestCasesFromDiccionario.devolverParametrosSiTieneSampleData(parametro).get(0);
				break;
			}
			
		}
		
		return StringUtils.replace(res, "\"", "");
	}
	
	private static ContextoObject identificarControllerByAplicacionYContexto(String aplicacion, List<String> contexto){
		
		ContextoObject co = null;
		
		switch (aplicacion) {
		
			case "tf":				co = identificarControllerByContextoEnTf(null, contexto);					break;
	
			case "crm":				co = identificarControllerByContextoEnCrm(null, contexto);				break;
			
			case "ib":				co = identificarControllerByContextoEnIb(null, contexto); 				break;
			
			case "SAP": 			co = identificarControllerByContextoEnSap(null, contexto); 				break;
		}
		
		return co;
	}
	
	
	private static ContextoObject identificarControllerByAplicacionYContexto(String aplicacion, String contexto){
		
		ContextoObject co = null;
		
		switch (aplicacion) {
		
			case "tf":				co = identificarControllerByContextoEnTf(contexto, null);					break;
	
			case "crm":				co = identificarControllerByContextoEnCrm(contexto, null);				break;
			
			case "ib":				co = identificarControllerByContextoEnIb(contexto, null); 				break;
			
		}
		
		return co;
	}
		
	private static ContextoObject identificarControllerByContextoEnTf(String contexto, List<String> contextol){
		return identificarClasesByApp("tf", contexto, contextol);
	}
	
	private static ContextoObject identificarControllerByContextoEnCrm(String contexto, List<String> contextol){
		return identificarClasesByApp("crm.bp", contexto, contextol);
	}
	
	private static ContextoObject identificarControllerByContextoEnIb(String contexto, List<String> contextol){
		return identificarClasesByApp("ib", contexto, contextol);
	}
	
	private static ContextoObject identificarControllerByContextoEnSap(String contexto, List<String> contextol){
		return identificarClasesByApp("sap", contexto, contextol);
	}
	
	@SuppressWarnings("unchecked")
	private static ContextoObject identificarClasesByApp(String app, String contexto, List<String> contextol){

		String contx = (StringUtils.isEmpty(contexto) ? contextol.get(0) : contexto);
		String package_name = "";
		String prefijo = "";
		
		if(StringUtils.contains(contx, " de "))
			contx = StringUtils.replace(contx, " de ", "_");
		
		
		contx 		  = GenericCommon.removeRareChars(contx);
		contx 		  = transformarContexto(contx);
		package_name  = transformarContextoPackage(contx);
		package_name  = StringUtils.lowerCase(package_name);
		contx 		  = StringUtils.replace(contx, " ", "");
		
		Class<? extends Object> clas = null;
		Class<? extends Object> steps = null;
		Class<? extends Object> validar = null;
		Class<? extends Object> proceso = null;
		
		ContextoObject ob = null;
		Map<String, String> ae = null;

		try {
//			System.out.println("CONTEXTO: " + contexto);
			
			// revisar el tema de los parametros segun la test data (es decir, para saber un contexto o ya viene implicito del diccionario de contextos o lo he de indentificar en la testdata, 
			// por lo tanto deberia de hacer un diccionario solamente de palabras de contexto y comparar.
			
			contx = GenericCommon.replaceAccents(contx);
			contx = StringUtils.replaceIgnoreCase(contx, "\"", "");
			
			prefijo = StringUtils.capitalize(contx) + StringUtils.capitalize(StringUtils.replace(app, ".bp", ""));
			 
			clas 			= Class.forName("com.testing_web.sogeti."+app+".pantallas."+StringUtils.lowerCase(package_name)+".main."+ prefijo + "Controller");
			steps 			= Class.forName("com.testing_web.sogeti."+app+".pantallas."+StringUtils.lowerCase(package_name)+".main.steps."+ StringUtils.capitalize(contx) + "Steps");
			proceso 		= Class.forName("com.testing_web.sogeti."+app+".pantallas."+StringUtils.lowerCase(package_name)+".main.steps."+ StringUtils.capitalize(contx) + "Procesos");
			validar 		= Class.forName("com.testing_web.sogeti."+app+".pantallas."+StringUtils.lowerCase(package_name)+".main.validaciones."+ StringUtils.capitalize(contx) + "Validaciones");
			package_name 	= StringUtils.lowerCase(StringUtils.isNotEmpty(package_name) ? package_name : StringUtils.substringBetween(validar.getCanonicalName(), "pantallas.", ".main"));
			
			ob = new ContextoObject(clas, steps, validar, proceso, ae, package_name, app);
			
		} catch (ClassNotFoundException | NoClassDefFoundError e) {
//			e.printStackTrace();
			ob = new ContextoObject(null, null, null, null, null, prefijo, app, false);
			System.out.println("Clases no encontradas. APP: '"+ app + "' --- Prefijo: '"+ prefijo + "'");
		}
					
		return ob;
	}
	
	private static String transformarContextoPackage(String contexto) {
		String[] contextsplit = StringUtils.split(contexto, " ");
		String res = "";
		if(StringUtils.contains(contexto, " ")){
			if(contextsplit.length == 3)
				res = contextsplit[0] + "_" + StringUtils.capitalize(contextsplit[2]);
			else if(contextsplit.length == 2)
				res = contextsplit[0] + "_" + StringUtils.capitalize(contextsplit[1]);
		} else 
			res = contexto;
		
		
		return res;
	}
	
	private static String transformarContexto(String contexto) {
		
		String res = "";
		
		if(StringUtils.contains(contexto, " ")){
			String[] contextsplit = StringUtils.split(contexto, " ");
			
			if(contextsplit.length == 3)
				res = contextsplit[0] + StringUtils.capitalize(contextsplit[2]);
			else 
				res = contexto;
			
		} else 
			res = contexto;
		
		
		
		return res;
	}

	
}
