package com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class ContextoObject {

	public Class<? extends Object> controller;
	public Class<? extends Object> proceso;
	public Class<? extends Object> steps;
	public Class<? extends Object> validaciones;
	public String controllerStr;
	
	public String contexto;
	public String app;
	public Map<String, String> diccionario;
	
	public boolean definido; 
		
	public ContextoObject(Class<? extends Object> controller, Class<? extends Object> steps, Class<? extends Object> validaciones, Class<? extends Object> proceso, Map<String, String> diccionario, String contexto, String app) {
		super();
		this.controller = controller;
		this.steps = steps;
		this.validaciones = validaciones;
		this.proceso = proceso;
		this.diccionario = diccionario;
		this.contexto = StringUtils.lowerCase(contexto);
		this.controllerStr = (this.controller != null ? this.controller.getSimpleName() : "");
		this.app = app;
		this.definido = true;
	}
	
	public ContextoObject(Class<? extends Object> controller, Class<? extends Object> steps, Class<? extends Object> validaciones, Class<? extends Object> proceso, Map<String, String> diccionario, String contexto, String app, boolean definido) {
		super();
		this.controller = controller;
		this.steps = steps;
		this.validaciones = validaciones;
		this.proceso = proceso;
		this.diccionario = diccionario;
		this.contexto = StringUtils.lowerCase(contexto);
		this.controllerStr = (this.controller != null ? this.controller.getSimpleName() : "");
		this.app = app;
		this.definido = definido;
	}
	
	
}
