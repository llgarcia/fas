package com.testing_web.sogeti.___global_tools.parser;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.testing_web.sogeti.___global_tools.DiccionarioDeLiterales;
import com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto.ContextoObject;
import com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto.DefinidorDeContextoParaDiccionario;
import com.testing_web.sogeti.___global_tools.propiedades.Propiedades;

import utils_selenium.GenericCommon;

@Deprecated
public class ParserTestCasesFromDiccionario extends GeneradorClass{

	protected ContextoObject contextObject;
	protected Map<String, String> diccionario;
	
	protected boolean existe_parseado;
	
	private String construirClassName(String testCaseName){
		return "TEST_CASE_" + testCaseName;
	}
	
	public void definirNombreDeClase() {
		declararNombreDeClase(construirClassName(Propiedades.CONTEXTO));
	}

	private String getMetodoDeClaseSegunTestStep(String excelTestStep) {
		String stepMethodInClass = new String();

		Object metodo = null;
				
		stepMethodInClass = getParsedValue(excelTestStep);				
		
		if(StringUtils.isNotEmpty(stepMethodInClass))
			
			if (esStepDeVerificacion(excelTestStep))
				metodo = getMethodVerificacion(stepMethodInClass);
			
			else if(esStepDeStep(excelTestStep))
				metodo = getMethodStep(stepMethodInClass);
			
			else if(esStepDeProceso(excelTestStep) || esStepDeProceso(stepMethodInClass))
				metodo = getMethodProcess(stepMethodInClass);

		return (metodo != null ? stepMethodInClass : null);

	}
	
	private Method getMethodProcess(String nombreMetodo){
		Method method = null;
		
		if (method == null) {
			try {
				
				method = contextObject.proceso.getMethod(nombreMetodo);
				
			} catch (NoSuchMethodException | SecurityException e) {
				
				for (Method m : contextObject.proceso.getMethods()){
					System.out.println(m.getName());
					if (StringUtils.equals(m.getName(), nombreMetodo))
						method = m;
				}
			
			}
		}
		
		return method;
	}
	
	private Method getMethodStep(String nombreMetodo) {
		Method method = null;

		if (method == null) {
			try {
				method = contextObject.steps.getMethod(nombreMetodo);
			} catch (NoSuchMethodException | SecurityException e) {
				
				for (Method m : contextObject.steps.getMethods())
					if (StringUtils.equals(m.getName(), nombreMetodo))
						method = m;
			}
		}
		
		return method;
	}

	private Method getMethodVerificacion(String nombreMetodo) {
		Method validacionMethodo = null;
		
		if (validacionMethodo == null) {
			try {
				validacionMethodo = contextObject.validaciones.getDeclaredMethod(nombreMetodo);
			} catch (NoSuchMethodException | SecurityException e) {
				
				for (Method m : contextObject.validaciones.getMethods())
					if (StringUtils.equals(m.getName(), nombreMetodo))
						validacionMethodo = m;
			}
		}

		return validacionMethodo;
	}
	
	private boolean esStepDeVerificacion(String testStep) {
		return StringUtils.equals(identificarTipoDeStep(testStep), "validar");
	}
	
	private boolean esStepDeStep(String testStep){
		return StringUtils.equals(identificarTipoDeStep(testStep), "steps");
	}
	
	private boolean esStepDeProceso(String testStep) {
		return StringUtils.equals(identificarTipoDeStep(testStep), "proceso");
	}

	private String identificarTipoDeStep(String step) {

		String res = "";

		if (!StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.verificar) && (!StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.xlsx)) && (!StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.llamar) && !StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.setup)))
			res = "steps";

		else if (StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.verificar))
			res = "validar";
		
		else if(StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.llamar) 
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.setup) 
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.xlsx)
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.proceso))
			
			res = "proceso";

		return res;
	}
	
	public boolean existeStepParseadoEnClaseController(String testStep) {
		return getMetodoDeClaseSegunTestStep(testStep) == null ? false : true;
	}
	
	public boolean excelTestStepActualTieneVariosSteps(String excel_step) {
		return devolverListadoDeAccionesClaveEnExcelStep(excel_step).size() > 1 ? true : false;
	}

	private List<String> devolverListadoDeAccionesClaveEnExcelStep(String excel_step) {

		List<String> steps = new ArrayList<String>();

		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.enLaPestana) && !StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicarEnLaPestana) )
			steps.add(DiccionarioDeLiterales.enLaPestana);
		
//		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clic))
//			steps.add(DiccionarioDeLiterales.clic);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicar))
			steps.add(DiccionarioDeLiterales.clicar);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.escribir))
			steps.add(DiccionarioDeLiterales.escribir);

		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.seleccionar))
			steps.add(DiccionarioDeLiterales.seleccionar);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.verificar))
			steps.add(DiccionarioDeLiterales.verificar);
		
		if	(StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.llamar))
			steps.add(DiccionarioDeLiterales.llamar);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.pega))
			steps.add(DiccionarioDeLiterales.pega);

		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicIntro) || StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicarIntro) ) {
			for(int cnt = 0; cnt <= steps.size() - 1; cnt++)
				if(StringUtils.equalsIgnoreCase(steps.get(cnt), DiccionarioDeLiterales.clic) || StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicar) )
					steps.remove(cnt);					
		}
				
		
		if(steps.size() > 1){
			Integer index_step_1 = StringUtils.indexOf(excel_step, steps.get(0));
			Integer index_step_2 = StringUtils.indexOf(excel_step, steps.get(1));
		
			if(index_step_2 < index_step_1){
				String i1 = steps.get(0);
				String i2 = steps.get(1);
				
				steps.set(0, i2);
				steps.set(1, i1);
			}
						
		}		
		
		return steps;
	}

	private String quitarLetraY(String step) {
		return StringUtils.replace(step, " y ", "");
	}

	public List<String> extrarPasoDeExcelStep(String excel_step) {

		List<String> steps = devolverListadoDeAccionesClaveEnExcelStep(excel_step);

		List<String> res = new ArrayList<String>();

		for (Integer count = 0; count <= steps.size() - 1; count++) {

			String step_inicialq = steps.get(count + 1);

			excel_step = StringUtils.lowerCase(excel_step);
			step_inicialq = StringUtils.lowerCase(step_inicialq);
			
			if (steps.size() == 2) {
				res.add(quitarLetraY(StringUtils.substringBefore(excel_step, step_inicialq)));
				res.add(quitarLetraY(step_inicialq + StringUtils.substringAfter(excel_step, step_inicialq)));
				break;
			}
		}

		return res;
	}
	
	public static List<String> devolverParametrosSiTieneSampleData(String sample_data) {

		List<String> res = new ArrayList<String>();
		String[] parametros = null;

		if(StringUtils.contains(sample_data, ","))
			parametros = StringUtils.split(sample_data, ",");
		
		else if(StringUtils.contains(sample_data, "\n"))
			parametros = StringUtils.split(sample_data, "\n");

		else 
			parametros = StringUtils.split(sample_data, ",");

		for (String param : parametros)
			res.add("\"" + StringUtils.substringBetween(param, "\"", "\"") + "\"");
		

		return res;
	}
	
	public static List<String> devolverParametrosSiTieneSampleDataConClave(String sample_data) {
		List<String> res = new ArrayList<String>();
		String[] parametros = null;

		if(StringUtils.contains(sample_data, ","))
			parametros = StringUtils.split(sample_data, ",");
		
		else if(StringUtils.contains(sample_data, "\n"))
			parametros = StringUtils.split(sample_data, "\n");

		else 
			parametros = StringUtils.split(sample_data, ",");

		for (String param : parametros)
			res.add(param);
		

		return res;
	}

	public static boolean tieneParametrosSampleData(String sampleData) {
		return StringUtils.contains(sampleData, "{") && StringUtils.contains(sampleData, "}")
				&& StringUtils.contains(sampleData, "$");
	}
	
	
	// TODO revisar el tema de tratar los valores claves 
	private boolean tieneValidacionesTestStep(String excel_step) {
		return esValidacionDeVariosValores(excel_step)|| esValidacionSoloUnValor(excel_step) || esValorPegado(excel_step);
	}
	
	private boolean esValorPegado(String excel_step) {
		return StringUtils.containsIgnoreCase(excel_step, "pega el n�mero de");
	}
	
	private boolean esValorCopiado(String excel_step) {
		return StringUtils.containsIgnoreCase(excel_step, "copiado");
	}
	
	private boolean esValorABuscarEnTabla(String excel_step){
		return StringUtils.containsIgnoreCase(excel_step, "para el");
	}
	
	private boolean esValidacionDeVariosValores(String excel_step) {
		return StringUtils.containsIgnoreCase(excel_step, "aparecen los siguientes campos") 
			|| StringUtils.containsIgnoreCase(excel_step, "tiene los siguientes valores en la cabecera")
			|| StringUtils.containsIgnoreCase(excel_step, "los campos siguientes son editables")
			|| StringUtils.containsIgnoreCase(excel_step, "los campos siguientes no editables")
			|| StringUtils.containsIgnoreCase(excel_step, "las siguientes opciones estan en el desplegable del campo");
	}
	
	private boolean esValidacionSoloUnValor(String excel_step) {
		return StringUtils.containsIgnoreCase(excel_step, "tiene el valor") || StringUtils.containsIgnoreCase(excel_step, "no tiene el valor");
	}

	private List<String> devolverValidacionesSiTieneSegunExcelStep(String excel_step) {
	
		List<String> parametros = new ArrayList<String>();
		
 		
		String[] varios_parametros = null;
	
		String valor;
		
		if(esValidacionDeVariosValores(excel_step)){
			varios_parametros = StringUtils.split(excel_step, ":");
			varios_parametros = StringUtils.split(varios_parametros[1], "\n");
		} 
			
		if (esValidacionSoloUnValor(excel_step) && !esValorCopiado(excel_step)){
			valor = StringUtils.substringAfter(excel_step, devolverSubstringDeValidaciones(excel_step));
			valor = StringUtils.replace(valor, ".", "");
			parametros.add(valor);
		} 
		
		if(esValorPegado(excel_step)){
			valor = StringUtils.substringBefore(excel_step, devolverSubstringDePegar(excel_step));	
			valor = StringUtils.substringBeforeLast(valor, "\"");
			valor = StringUtils.substringAfter(valor, "\"");
			parametros.add(valor);
		} 
		
		if(esValorCopiado(excel_step)){
			valor = StringUtils.substringBetween(excel_step, devolverSubstringSegunVerificacion(excel_step), " copiado");
			valor = StringUtils.replace(valor, "\"", "");
			parametros.add(valor);
		} 
		
		if(esValorABuscarEnTabla(excel_step)){
			String devuleto = devolverSubstringEspecificacion(excel_step);
			valor = StringUtils.substringBetween(excel_step, devuleto, " buscado");
			valor = StringUtils.substringBetween(valor, "\"", "\"");
			parametros.add(valor);
		}
					
		if(parametros.size() > 1){
			Integer index_step_1 = StringUtils.indexOf(excel_step, parametros.get(0));
			Integer index_step_2 = StringUtils.indexOf(excel_step, parametros.get(1));
		
			if(index_step_2 < index_step_1){
				String i1 = parametros.get(0);
				String i2 = parametros.get(1);
				
				parametros.set(0, i2);
				parametros.set(1, i1);
			}
						
		}		
										
		return varios_parametros != null ? GenericCommon.convertirArrayStringsInListStrings(varios_parametros) : parametros;
	}
	
	private String devolverSubstringDeValidaciones(String excel_step) {
		String a = new String();
		
		if(StringUtils.containsIgnoreCase(excel_step, "aparecen los siguientes campos"))
			a = " aparecen los siguientes campos ";
		
		if(StringUtils.containsIgnoreCase(excel_step, "tiene los siguientes valores en la cabecera"))
			a = " tiene los siguientes valores en la cabecera ";
		
		if( StringUtils.containsIgnoreCase(excel_step, "los campos siguientes son editables"))
			a = " los campos siguientes son editables ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "los campos siguientes no editables"))
			a = " los campos siguientes no editables ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "las siguientes opciones estan en el desplegable del campo"))
			a = " las siguientes opciones estan en el desplegable del campo ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "tiene el valor"))
			a = " tiene el valor ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "no tiene el valor"))
			a = " no tiene el valor ";
		
		return a;
	}
	
	private String devolverSubstringDePegar(String excel_step) {
		String a = new String();
		
		if (StringUtils.contains(excel_step, "pega el n�mero de"))
			a = " pega el n�mero de ";
		
		return a;
	}
	
	private String devolverSubstringEspecificacion(String excel_step) {
		String a = new String();
		
		if (StringUtils.containsIgnoreCase(excel_step, "para el"))
			a = " para el ";
		
		return a;
	}
	
	// se puede dar la opcion que devuelva 2 opciones
	private String devolverSubstringSegunVerificacion(String excel_step) {
		
		String a = new String();
		
		if(StringUtils.containsIgnoreCase(excel_step, "aparecen los siguientes campos"))
			a = " aparecen los siguientes campos ";
		
		if(StringUtils.containsIgnoreCase(excel_step, "tiene los siguientes valores en la cabecera"))
			a = " tiene los siguientes valores en la cabecera ";
		
		if( StringUtils.containsIgnoreCase(excel_step, "los campos siguientes son editables"))
			a = " los campos siguientes son editables ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "los campos siguientes no editables"))
			a = " los campos siguientes no editables ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "las siguientes opciones estan en el desplegable del campo"))
			a = " las siguientes opciones estan en el desplegable del campo ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "tiene el valor"))
			a = " tiene el valor ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "no tiene el valor"))
			a = " no tiene el valor ";
		
		
		return a;
		
	}
	
	public ContextoObject definirContextObject(String testStep, String sampleData, String expectedResult) {
		
		ContextoObject currentContextObject = DefinidorDeContextoParaDiccionario.devolverControlador(testStep, sampleData, expectedResult);
		
		if(currentContextObject != null && !currentContextObject.getClass().equals(contextObject))
			contextObject = currentContextObject;
		
		return currentContextObject;
		
	}
	
	public boolean existeTestStepEnDiccionario(String testStep) {
		return (StringUtils.isNotEmpty(getParsedValue(testStep)) ? true : false);  
	}
	
	public boolean existeContexto() {
		return contextObject != null;
	}
	
	public boolean existeDiccionarioByContext() {
		return contextObject.diccionario != null;
	}
		
	private String getParsedValue(String expected) {
		
		String res = "";		

		if(existeDiccionarioByContext())
			for (Entry<String, String> e : contextObject.diccionario.entrySet()){
				String compare = StringUtils.lowerCase(e.getKey());
//				System.out.println("DICC: " + compare + "' ---- '"+ expected +"'");
				if ((StringUtils.equalsIgnoreCase(expected, compare) || StringUtils.containsIgnoreCase(expected, compare)))
					res = e.getValue();
			}
		
		return res;
	}
		
	private void guardarMetodoEnCuerpoTestCase(String excel_step, List<String> parametros) {
				
//		if(!esMetodoAsignableAVariable(excel_step))
//			
//			generarLlamada_Objeto_Acceso_Action(contextObject.contexto, identificarTipoDeStep(excel_step), getParsedValue(excel_step), parametros);
//		
//		else if(esMetodoAsignableAVariable(excel_step))
//			
//			generarLlamadaMetodoAsignacionAVariable_Objeto_Acceso_Action(devolverVariableAssignacionSegunTestStep(excel_step), contextObject.contexto, identificarTipoDeStep(excel_step), getParsedValue(excel_step), parametros);
		
	}	
	
	private String devolverVariableAssignacionSegunTestStep(String excel_step) {
		return StringUtils.substringBetween(excel_step, "\"", "\"");
	}
	
	private boolean esMetodoAsignableAVariable(String excel_step) {
		
		if(StringUtils.containsIgnoreCase(excel_step, "copiar") && (!StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.xlsx)))
			return true;
		else
			return false;
		
	}

	public void parsearMetodos(List<String> testSteps, List<String> sampleData, List<String> expectedResult) {

		cuerpoMetodoDeclarado = new BlockStmt();

		existe_parseado = true;
		
		for (Integer pos = 0; pos <= testSteps.size() - 1; pos++) {

			String excel_step = StringUtils.lowerCase(testSteps.get(pos));
			String data_step  = sampleData.get(pos);
			String expected = expectedResult.get(pos);
			
 			instanciaObjetoSiNoExiste(excel_step, data_step, expected);
			
 			if(existeContexto()){
	 			if(existeDiccionarioByContext()){
	 			
					if (excelTestStepActualTieneVariosSteps(excel_step)) {
		
						for (String excel_step_extracted : extrarPasoDeExcelStep(excel_step)) {					
							
							if (existeStepParseadoEnClaseController(excel_step_extracted))
								escribirMetodoEnCuerpoDelTestCase(excel_step_extracted, sampleData.get(pos));
							else {
								System.out.println("No existe paso en la clase del contexto ['" + excel_step_extracted + "']");
								existe_parseado = false;
							}
						}
						
					} else {
		
						if (existeStepParseadoEnClaseController(excel_step))
							escribirMetodoEnCuerpoDelTestCase(excel_step, sampleData.get(pos));
						else {
							System.out.println("No existe paso en la clase del contexto ['" + excel_step + "']");
							existe_parseado = false;
						}
					}
					
					if(!existe_parseado)
						break;
					
	 			} else {
	 				existe_parseado = false;
	 				break;
	 			}
 			}
		}
	}
	
	private void instanciaObjetoSiNoExiste(String excel_step, String data_step, String expected) {

		ContextoObject currentContextObject = definirContextObject(excel_step, data_step, expected);
		
		if(currentContextObject != null && !currentContextObject.getClass().equals(contextObject)){
			instanciaContextObjectParaTestCase(contextObject);
			instanciaImportsPackageParaTestCase(contextObject);
		}
	
		
	}
	
	@Override
	protected void instanciaImportsPackageParaTestCase(ContextoObject co) {
		
		if(!this.class_importsDeclarados.contains("org.junit.Test"))
			this.class_importsDeclarados.add("org.junit.Test");
		
		if(!this.class_importsDeclarados.contains("org.junit.Before"))
			this.class_importsDeclarados.add("org.junit.Before");			
		
		if(!this.class_importsDeclarados.contains("com.testing_web.sogeti.___abstraccion_generica.AbstractBaseTestCase"))
			this.class_importsDeclarados.add("com.testing_web.sogeti.___abstraccion_generica.AbstractBaseTestCase");
		
		super.instanciaImportsPackageParaTestCase(co);
		
	}
		
	private void escribirMetodoEnCuerpoDelTestCase(String excel_step, String sample_data) {
		
		if (tieneValidacionesTestStep(excel_step))
			guardarMetodoEnCuerpoTestCase(excel_step, devolverValidacionesSiTieneSegunExcelStep(excel_step));
		
		else if (tieneParametrosSampleData(sample_data))
			guardarMetodoEnCuerpoTestCase(excel_step, devolverParametrosSiTieneSampleData(sample_data));
		
		else
			guardarMetodoEnCuerpoTestCase(excel_step, null);
		
	}
	
	public void generarMetodoTestCase() {
		
		if(existe_parseado){
		
			MethodDeclaration metodo = getMethodDeclaration("public", "void", tc_nombre_metodo, "Test", new Exception());
			metodo.setBody(cuerpoMetodoDeclarado);
			tc_metodosDeclarados.add(metodo);
			
			resetMetodoAnotacion();
			resetMetodoArgumento();
			resetMetodoLlamada();
		} 
	}
	
	public void generarMetodosSobreescritos() {
		MethodDeclaration method = getMethodDeclaration("public", tc_tipoReturn, tc_nombre_metodo, this.tc_anotaciones, this.tc_exception);
		
		for(Parameter param : this.tc_parametrosMetodo)
			method.addParameter(param);
		
		method.setBody(this.cuerpoMetodoDeclarado);
		this.tc_metodosDeclarados.add(method);
		
		this.tc_anotaciones = new ArrayList<String>();
		this.tc_parametrosMetodo  = new ArrayList<Parameter>();
		this.cuerpoMetodoDeclarado = new BlockStmt();
		
	}
	
	
	
	
}
