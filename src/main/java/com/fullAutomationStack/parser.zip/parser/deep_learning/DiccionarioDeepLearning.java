package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.experimental.categories.Categories;

import lombok.Getter;
import utils_selenium.GenericCommon;

public class DiccionarioDeepLearning {

	@Getter
	protected List<StepCategorizado> list;
	
	public DiccionarioDeepLearning() {
		list = new ArrayList<StepCategorizado>();
		
		list.add(new StepCategorizado("Llamar el setup \"\" con:\"\"",	 	"setup__", 1));
		list.add(new StepCategorizado("Llamar el setup \"\"",	 			"setup__", 1));
		list.add(new StepCategorizado("Llamar el setup \"\" \"\"",	 		"setup__", 1));
		list.add(new StepCategorizado("Llamar al setup \"\"",	 			"setup__", 1));
		list.add(new StepCategorizado("CRM_R_Rellenar_Datos_Oferta_Depositos", "setup__", 20));
		
		list.add(new StepCategorizado("Clicar en bot�n \"\"",			"clickEnElBoton__", 0));
		list.add(new StepCategorizado("Clicar en el bot�n \"\"",			"clickEnElBoton__", 0));
		list.add(new StepCategorizado("Clicar en el enlace \"\"",			"clickEnElEnlace__", 0));
		list.add(new StepCategorizado("Clicar en la pesta�a \"\"",			"clickEnLaPestana__", 0));
		list.add(new StepCategorizado("Clicar en el icono \"\"",			"clickEnElIcono__", 0));
		list.add(new StepCategorizado("Clicar en el campo \"\"",			"clickEnElCampo__", 0));
		list.add(new StepCategorizado("Clicar en el checkbox \"\"",	 		"clickEnElCheckbox__", 0));
		list.add(new StepCategorizado("Clicar en el radiobutton \"\"", 		"clickEnElRadiobutton__", 0));
		
		list.add(new StepCategorizado("Clicar  en el bot�n \"\"",			"clickEnElBoton__", 0));
		list.add(new StepCategorizado("Clicar  en el enlace \"\"",			"clickEnElEnlace__", 0));
		list.add(new StepCategorizado("Clicar  en la pesta�a \"\"",			"clickEnLaPestana__", 0));
		list.add(new StepCategorizado("Clicar  en el icono \"\"",			"clickEnElIcono__", 0));
		list.add(new StepCategorizado("Clicar  en el campo \"\"",			"clickEnElCampo__", 0));
		list.add(new StepCategorizado("Clicar  en el checkbox \"\"",	 		"clickEnElCheckbox__", 0));
		list.add(new StepCategorizado("Clicar  en el radiobutton \"\"", 		"clickEnElRadiobutton__", 0));
		
		list.add(new StepCategorizado("Clicaren el bot�n \"\"",			"clickEnElBoton__", 0));
		list.add(new StepCategorizado("Clicaren el enlace \"\"",			"clickEnElEnlace__", 0));
		list.add(new StepCategorizado("Clicaren la pesta�a \"\"",			"clickEnLaPestana__", 0));
		list.add(new StepCategorizado("Clicaren el icono \"\"",			"clickEnElIcono__", 0));
		list.add(new StepCategorizado("Clicaren el campo \"\"",			"clickEnElCampo__", 0));
		list.add(new StepCategorizado("Clicaren el checkbox \"\"",	 		"clickEnElCheckbox__", 0));
		list.add(new StepCategorizado("Clicaren el radiobutton \"\"", 		"clickEnElRadiobutton__", 0));
		
		
		list.add(new StepCategorizado("Clicar en el icono \"\" (Gafas) del campo \"\"",			"clickEnElIcono__", 13));
		list.add(new StepCategorizado("Clicar en el icono \"\" (Gafas) en \"\"",				"clickEnElIcono__", 13));
		list.add(new StepCategorizado("Clicar en el icono \"\" (+) de \"\"",					"clickEnElIcono__", 13));
		list.add(new StepCategorizado("clicar en el icono \"\" (icono hoja) en campo \"\"",		"clickEnElIcono__", 13));
		list.add(new StepCategorizado("clicar en el icono \"\" (icono hoja) en campo \"\"",		"clickEnElIcono__", 13));



		


		
		list.add(new StepCategorizado("Clicar en el radiobutton "			// aqui hay que revisar como coger esto sin parametros. lo deberia de tratar mediante letras
				+ "\"\" del campo \"\"", 									"clickEnElCampo__ElRadiobutton", 1));
		
		list.add(new StepCategorizado("Clicar en el desplegable \"\"", 		"clickEnElDesplegable__", 0));
		list.add(new StepCategorizado("Clicar en \"\"",				 		"clickEn__", 0));
				
		list.add(new StepCategorizado("Clicar en una opci�n aleatoria de la tabla \"\"",	"clickEnOpcionDeTabla__", 1));
		list.add(new StepCategorizado("Clicar en la opci�n mostrada de la tabla \"\"",		"clickEnLineaMostradaDeTabla__", 0));

//		list.add(new StepCategorizado("Clicar en el icono \"\" de la tabla \"\" en la columna \"\"",							"clickEn__EnLaColumna__DeLaTabla__", 3));
			
		list.add(new StepCategorizado("Anotar el valor del campo \"\"", 				"copiarElValorDelCampo__", 0));
		list.add(new StepCategorizado("Copiar el valor del campo \"\"", 				"copiarElValorDelCampo__", 0));
		list.add(new StepCategorizado("Copiar los valores de los campos: \"\"", 		"copiarElValorDelCampo__", 4));
		list.add(new StepCategorizado("Copiar los valores de la tabla \"\" de los campos: \"\" como \"\"", 		"copiarDeLaTabla__LosValoresDeLaColumna", 4));
		
		// pendiente de definir
		list.add(new StepCategorizado("Pegar el valor de \"\" en el campo \"\"",		"escribirEn__", 1));
		list.add(new StepCategorizado("Pegar el valor de \"\" en el buscador",			"escribirEnBuscador", 12));
	
		//	#Bloque Escribir#
//		list.add(new StepCategorizado("Escribir \"\" en el campo \"\"", "escribirEn__", 1));		// se trata en otra categoria porque se coje el parametro antes que el identificador.
		list.add(new StepCategorizado("Escribir \"\" en el campo \"\"", "escribirEn__", 1));
		list.add(new StepCategorizado("Escribir en los siguientes campos: \"\" los valores: \"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos:\"\" los valores:\"\"", "escribirEn__", 5));
//		list.add(new StepCategorizado("Escribir en los siguientes campos: \"\"los valores: \"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos: \"\" los valores:\"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos: \"\"los valores:\"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos: \"\"los valores: \"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos:\"\" los valores: \"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos:\"\" los valores:\"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos:\"\"los valores:\"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos:\"\" los valores:\"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos::\"\" os valores:\"\"", "escribirEn__", 5));
		list.add(new StepCategorizado("Escribir en los siguientes campos::\"\"los valores:\"\"", "escribirEn__", 5));


		list.add(new StepCategorizado("Escribir \"\" en el campo \"\" de \"\"", "escribirEn__", 5));
		

		
//		Escribir en los siguientes campos: \n"Importe"\n"Concepto"\nlos valores:\n"${importe}"\n"${concepto}"
		//	#Bloque Seleccionar);
		list.add(new StepCategorizado("Seleccionar la opci�n \"\" del desplegable \"\"", 		"seleccionarEn__", 1));
		list.add(new StepCategorizado("Seleccionar una opci�n \"\" del desplegable \"\"", 		"seleccionarEn__", 1));
		list.add(new StepCategorizado("Seleccionar del desplegable: \"\" la opcion: \"\"", 		"seleccionarEn__", 3));

		list.add(new StepCategorizado("Seleccionar la fecha \"\" de \"\" ", "seleccionarEn__", 1));
		list.add(new StepCategorizado("Seleccionar la fecha \"\" de \"\"", "seleccionarEn__", 1));
		
		// revisar
		list.add(new StepCategorizado("Seleccionar una opci�n aleatoria del desplegable \"\"", 	"seleccionarEn__", 1));		
		list.add(new StepCategorizado("Seleccionar una opci�n aleatoria de la tabla \"\" en la columna \"\"", "seleccionarDeLaTabla__EnLaColumna__LaOpcion", 3));
		list.add(new StepCategorizado("Seleccionar una opci�n aleatoria de la tabla \"\"", 		"seleccionarOpcionAleatoriaDeTabla__", 1));
		list.add(new StepCategorizado("Seleccionar una linea aleatoria de la tabla \"\"", 		"seleccionarOpcionAleatoriaDeTabla__", 1));
		list.add(new StepCategorizado(" Seleccionar una linea aleatoria de la tabla \"\"", 		"seleccionarOpcionAleatoriaDeTabla__", 1));
		list.add(new StepCategorizado("Seleccionar una l�nea aleatoria de la tabla \"\"", 		"seleccionarOpcionAleatoriaDeTabla__", 1));

		
// 		-- no esta en el diccionario		
//		list.add(new StepCategorizado("Seleccionar una l�nea aleatoria de la tabla \"\"", "seleccionarDeLaTabla__LaLineaAleatoria", 0));
		
		list.add(new StepCategorizado("Seleccionar de la tabla \"\" en la columna \"\" la opci�n \"\"", 		"seleccionarDeLaTabla__EnLaColumna__LaOpcion", 3));
		list.add(new StepCategorizado("Seleccionar de la tabla \"\" en la columna \"\" la opci�n:\"\"", 		"seleccionarDeLaTabla__EnLaColumna__LaOpcion", 3));
		

		list.add(new StepCategorizado("Seleccionar el radiobutton aleatorio de la tabla \"\"", 					"seleccionarRadiobuttonDeTabla__", 1));

//		en este caso busca dentro de la tabla "" la columna que se pasa por valor (para "") y selecciona el radiobutton existente"
		list.add(new StepCategorizado("Seleccionar el radiobutton para \"\" de la tabla \"\"", 		"seleccionarRadiobuttonDeTabla__", 1)); 
		list.add(new StepCategorizado("Seleccionar de la tabla \"\" de la columna "
				+ "\"\" el valor \"\" la opci�n \"\" del desplegable \"\"", 						"seleccionarDeLaTabla__DeLaColumna__LaOpcionDelDesplegable__", 9));
		
		list.add(new StepCategorizado("Seleccionar la fecha \"\" del calendario \"\"", 				"seleccionarEn__", 1));
		list.add(new StepCategorizado("Seleccionar de los desplegables: \"\" las opciones: \"\"", 	"seleccionarEn__", 5));
		list.add(new StepCategorizado("Seleccionar de los desplegables: \"\"las opciones: \"\"", 	"seleccionarEn__", 5));
		list.add(new StepCategorizado("Seleccionar de los desplegables: \"\"las opciones:\"\"", 	"seleccionarEn__", 5));
		list.add(new StepCategorizado("Seleccionar de los desplegables:\"\"las opciones:\"\"", 	"seleccionarEn__", 5));
		//	#Bloque Verificar Campo#
		list.add(new StepCategorizado("Verificar que el campo \"\" existe en la pantalla \"\"", 	"verificarCampo__Existente", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no existe en la pantalla \"\"", 	"verificarCampo__NoExistente", 0));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" no existe", 						"verificarCampo__NoExistente", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" existe", 						"verificarCampo__Existente", 0));
		
		list.add(new StepCategorizado("Verificar que el bot�n \"\" existe", 						"verificarBoton__Existente", 0));
		list.add(new StepCategorizado("Verificar que el bot�n \"\" no existe", 						"verificarBoton__NoExistente", 0));
		
		list.add(new StepCategorizado("Verificar que existen los siguientes enlaces en \"\"", 			"verificarEnlace__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes enlaces en  \"\"", 			"verificarEnlace__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes enlaces en \"\":\"\"", 		"verificarEnlace__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes enlaces en  \"\":\"\"", 	"verificarEnlace__Existente", 4));

		list.add(new StepCategorizado("Verificar que en \"\" aparecen los siguientes campos:\"\"", 	"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos:\"\"", 			"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos: \"\"", 			"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que aparecen los siguientes campos:\"\"", 			"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que aparecen los siguientes campos: \"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que no aparecen los siguientes campos:\"\"", 		"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no aparecen los siguientes campos: \"\"", 		"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos:\"\"", 		"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos: \"\"", 		"verificarCampo__NoExistente", 4));


		list.add(new StepCategorizado("Verificar que existen los siguientes campos en  \"\":\"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en \"\": \"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en \"\":\"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en \"\" :\"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en \"\": \"\"", 		"verificarCampo__Existente", 4));		
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en la pesta�a \"\": \"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en la pesta�a \"\" : \"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en la pesta�a \"\" :\"\"", 		"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en la pesta�a \"\":\"\"", 		"verificarCampo__Existente", 4));
		
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\": \"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\" : \"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\" :\"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\":\"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos: \"\"", 			"verificarCampo__NoExistente", 4));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" contiene un valor", 				"verificarCampo__TieneValor", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no contiene un valor", 			"verificarCampo__NoTieneValor", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no contiene valor", 			"verificarCampo__NoTieneValor", 0));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene un valor", 				"verificarCampo__TieneValor", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no tiene un valor", 				"verificarCampo__NoTieneValor", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no tiene valor", 				"verificarCampo__NoTieneValor", 0));
				
		list.add(new StepCategorizado("Verificar que el campo \"\" contiene el valor", 				"verificarCampo__TieneElValor", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no contiene el valor", 			"verificarCampo__NoTieneValor", 0));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor \"\" m�s \"\"",	"verificarCampoTieneElValor", 2));
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor \"\" menos \"\"",	"verificarCampoTieneElValor", 2));
		
		
		list.add(new StepCategorizado("Verificar que el valor del campo \"\" es igual al valor \"\" anotado",		"verificarCampoTieneElValor", 2));
		list.add(new StepCategorizado("Verificar que el valor del campo \"\" es igual al valor \"\" mas el \"\"",	"verificarCampoTieneElValor", 2));

		
		list.add(new StepCategorizado("Verificar que el campo \"\" contiene el valor \"\" mas el \"\"",	"verificarCampoTieneElValor", 2));
		list.add(new StepCategorizado("Verificar que el campo \"\" contiene el valor \"\" mas \"\"",	"verificarCampoTieneElValor", 2));
		list.add(new StepCategorizado("Verificar que el campo \"\" contiene el valor \"\" m�s \"\"",	"verificarCampoTieneElValor", 2));
		list.add(new StepCategorizado("Verificar que el campo \"\" contiene el valor \"\" menos \"\"",	"verificarCampoTieneElValor", 2));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor \"\"", 			"verificarCampo__TieneElValor", 1));
		list.add(new StepCategorizado("Verificar que el campo \"\" no tiene el valor \"\"", 		"verificarCampo__NoTieneElValor", 1));
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor \"\" en \"\"", 	"verificarCampo__TieneElValor", 4));

		list.add(new StepCategorizado("Verificar que el campo \"\" contiene  el valor \"\"", 			"verificarCampo__TieneElValor", 1));
		list.add(new StepCategorizado("Verificar que el campo \"\" no contiene el valor \"\"", 		"verificarCampo__NoTieneElValor", 1));
				
		list.add(new StepCategorizado("Verificar que el campo \"\" es editable", 					"verificarCampo__EsEditable", 0));
		list.add(new StepCategorizado("Verificar que el campo \"\" no es editable",					"verificarCampo__NoEsEditable", 0));
		
		list.add(new StepCategorizado("Verificar que los campos siguientes son editables:", 		"verificarCampo__EsEditable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes no son editables:", 		"verificarCampo__NoEsEditable", 4));

		list.add(new StepCategorizado("Verificar que los campos siguientes son editables en \"\": \"\"", 		"verificarCampo__Editable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes son editables en \"\":\"\"", 		"verificarCampo__Editable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes son editables en \"\" :\"\"", 		"verificarCampo__Editable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes son editables en \"\":\"\"", 		"verificarCampo__Editable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes son editables en \"\" de \"\":\"\"",	"verificarCampo__Editable", 14));

		list.add(new StepCategorizado("Verificar que los campos siguientes no son editables en \"\": \"\"", 			"verificarCampo__NoEditable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes no son editables en \"\":\"\"", 				"verificarCampo__NoEditable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes no son editables en \"\" :\"\"", 			"verificarCampo__NoEditable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes no son editables en \"\":\"\"", 				"verificarCampo__NoEditable", 4));
		list.add(new StepCategorizado("Verificar que los campos siguientes no son editables en \"\" de \"\":\"\"", 		"verificarCampo__NoEditable", 14));
		
		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" todos los campos son editables", 	"verificarTodosLosCamposTabla__Columna__Editables", 13));
		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" todos los campos no son editables", 	"verificarTodosLosCamposTabla__Columna__NoEditables", 13));

		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" todos los campos contienen un valor", 	"verificarTodosLosCamposTabla__Columna__TienenValor", 13));

		list.add(new StepCategorizado("Verificar que la tabla \"\" no tiene datos", 	"verificarQueTabla__NoTieneDatos", 0));
		list.add(new StepCategorizado("Verificar que la tabla \"\" no tiene datos y contiene el mensaje \"\"", 	"verificarQueTabla__NoTieneDatosYTieneElMensaje", 1));
		
		list.add(new StepCategorizado("Verificar que existen los siguientes campos en la pantalla \"\":\"\"", 	"verificarCampo__Existente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\": \"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\" : \"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\" :\"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos en \"\":\"\"", 	"verificarCampo__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes campos: \"\"", 			"verificarCampo__NoExistente", 4));
		
//		list.add(new StepCategorizado("Verificar que los campos siguientes son editables:", 		"verificarCampo__EsEditable", 4));
//		list.add(new StepCategorizado("verificar que los campos siguientes no son editables en \:", 		"verificarCampo__NoEsEditable", 4));
		
		
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor copiado", 		"verificarCampo__TieneElValor", 1));
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor anotado", 		"verificarCampo__NoTieneElValor",1));
		
		list.add(new StepCategorizado("Verificar que las siguientes opciones est�n en el desplegable del campo \"\":\"\"", "verificarSiguientesOpcionesEstanEnDesplegable__", 2));
		list.add(new StepCategorizado("Verificar que las siguientes opciones est�n en el desplegable del campo \"\": \"\"", "verificarSiguientesOpcionesEstanEnDesplegable__", 2));
		
		list.add(new StepCategorizado("Verificar que los campos: \"\" tienen los valores: \"\"", 			"verificarCampo__TieneElValor", 5));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor copiado", 		"verificarCampo__TieneElValor", 1));
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor anotado", 		"verificarCampo__TieneElValor", 1));
		
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor diferente del valor copiado", 		"verificarCampo__NoTieneElValor", 1));
		list.add(new StepCategorizado("Verificar que el campo \"\" tiene el valor diferente del valor anotado", 		"verificarCampo__NoTieneElValor", 1));
		
		list.add(new StepCategorizado("Verificar que los campos: \"\" tienen los valores copiados", 					"verificarCampo__TieneElValor", 1));
		list.add(new StepCategorizado("Verificar que los campos: \"\" tienen los valores anotados", 					"verificarCampo__TieneElValor", 1));
				
		list.add(new StepCategorizado("Verificar que los campos: \"\" tienen los valores diferentes de los valores copiados", 		"verificarCampo__NoTieneElValor", 1));
		list.add(new StepCategorizado("Verificar que los campos: \"\" tienen los valores diferentes de los valores anotados", 		"verificarCampo__NoTieneElValor", 1));			
		//
		
		//	#Bloque Verificar icono#
		list.add(new StepCategorizado("Verificar que el icono \"\" existe en la pantalla \"\"", 	"verificarIcono__Existente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" existe", 						"verificarIcono__Existente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" existe (+)", 					"verificarIcono__Existente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" existe (-)", 					"verificarIcono__Existente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" contiene el color \"\"", 			"verificarIcono__TieneElColor", 1));		


		
		list.add(new StepCategorizado("Verificar que el icono \"\" no existe en la pantalla \"\"", 	"verificarIcono__NoExistente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" no existe", 						"verificarIcono__NoExistente", 0));
		list.add(new StepCategorizado("Verificar que e icono \"\" no existe (+)", 			"verificarIcono__NoExistente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" no existe (+)", 			"verificarIcono__NoExistente", 0));
		list.add(new StepCategorizado("Verificar que e icono \"\" no existe (-)", 			"verificarIcono__NoExistente", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" no existe (-)", 			"verificarIcono__NoExistente", 0));
		

		
		list.add(new StepCategorizado("Verificar que el icono \"\" est� activo", 					"verificarIcono__EstaActivo", 0));
		list.add(new StepCategorizado("Verificar que el icono \"\" est� inactivo", 					"verificarIcono__EstaInactivo", 0));
		
		/**
			#########################
			#Bloque Verificar Tablas#
			#########################
		*/
		list.add(new StepCategorizado("Verificar que la tabla \"\" existe", 						"verificarTabla__Existente", 0));
		list.add(new StepCategorizado("Verificar que la tabla \"\" no existe", 						"verificarTabla__NoExistente", 0));
		
		list.add(new StepCategorizado("Verificar que la tabla en el excel \"\" contiene los siguientes valores en la cabecera:\"\"", 	"verificarCabeceraTablaExcel__", 2));
		list.add(new StepCategorizado("Verificar que la tabla en el excel \"\" contiene los siguientes valores en la cabecera: \"\"", 	"verificarCabeceraTablaExcel__", 2));
		// en este caso busca la tabla "" , la columna "" y valida los valores, estos valores son copiados en un Array() y se pasan en Array() por parametro.
		list.add(new StepCategorizado("Verificar que la tabla en el excel \"\" contiene los valores copiados en los columnas correspondientes: \"\"", 	"verificarEnTablaExcel__LosValoresDeColumna__", 2));	



		
		list.add(new StepCategorizado("Verificar que la tabla \"\" contiene los siguientes valores en la cabecera en \"\": \"\"", 				"verificarTabla__ContieneLaCabecera", 22));
		list.add(new StepCategorizado("Verificar que la tabla \"\" contiene los siguientes valores en la cabecera en \"\":\"\"", 				"verificarTabla__ContieneLaCabecera", 22));		
		list.add(new StepCategorizado("Verificar que la tabla \"\" contiene los siguientes valores en la cabecera: \"\"", 				"verificarTabla__ContieneLaCabecera", 2));
		list.add(new StepCategorizado("Verificar que la tabla \"\" contiene los siguientes valores en la cabecera:\"\"", 				"verificarTabla__ContieneLaCabecera", 2));
		list.add(new StepCategorizado("Verificar que la tabla \"\" tiene los siguientes valores en la cabecera: \"\"", 				"verificarTabla__ContieneLaCabecera", 2));
		list.add(new StepCategorizado("Verificar que la tabla \"\" tiene los siguientes valores en la cabecera:\"\"", 				"verificarTabla__ContieneLaCabecera", 2));
		
		
//		list.add(new StepCategorizado("Verificar que la tabla en el excel "Interveners" contiene los siguientes valores en la cabecera", 				"verificarTabla__ContieneLaCabecera", 2));
		

		list.add(new StepCategorizado("En la pesta�a \"\" , verificar que la tabla \"\" contiene los siguientes valores en la cabecera:\"\"", 	"verificarTabla__ContieneLaCabecera", 2));
		list.add(new StepCategorizado("En la pesta�a \"\" , verificar que la tabla \"\" tiene los siguientes valores en la cabecera:\"\"", 		"verificarTabla__ContieneLaCabecera", 2));
				
//		list.add(new StepCategorizado("Verificar que la tabla \"\" contiene una nueva fila", 				"verificarEnTabla__ContieneNuevaLinea", 1));
//		list.add(new StepCategorizado("Verificar que se ha borrado la fila de la tabla \"\"", 				"verificarEnTabla__ContieneUnaLineaMenos", 1));

//		-- deprecated, para valirar que hay una fila mas u otra menos he de saberla con anterioridad por lo tanto ...
//		-- ... se ha de pasar por parametro la cantidad de lineas que habia antes de hacer la accion a�adir o borrar
//		-- ( por lo tanto utilizar la de arriba )
//		list.add(new StepCategorizado("Verificar que la tabla \"\" contiene una nueva fila", 	"verificarTabla__ContieneNuevaLinea", 0));
//		list.add(new StepCategorizado("Verificar que se ha borrado la fila de la tabla \"\"", 	"verificarLineaEliminadaDeTabla__", 0));
		
		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" tiene el valor \"\"", 			"verificarTabla__EnLaColumna__TieneElValor", 3));
		

//		list.add(new StepCategorizado("Verificar que en la tabla \"\" la columna: \"\" tiene los valores: \"\"", 			"verificarTabla__EnLaColumna__TieneElValor", 3));
		
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas:\"\"tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\"tienen los valores:\"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\"las columnas: \"\" tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\"las columnas:\"\" tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\"las columnas:\"\"tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\"las columnas:\"\"tienen los valores:\"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		
		list.add(new StepCategorizado("Verificar que en la tabla\"\"las columnas:\"\"tienen los valores:\"\"", 			"verificarTabla__EnLaColumna__TieneLosValores", 22));
		
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas:\"\"tienen los valores:\"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		
		list.add(new StepCategorizado("Verificar que en la tabla\"\" las columnas: \"\" tienen los valores: \"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\"las columnas: \"\" tienen los valores: \"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas:\"\" tienen los valores: \"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\"tienen los valores: \"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" tienen los valores:\"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		
		
		list.add(new StepCategorizado("Verificar que en la tabla \"\"las columnas: \"\"tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla\"\" las columnas:\"\" tienen los valores: \"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla\"\" las columnas:\"\" tienen los valores:\"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\"tienen los valores:\"\"", 	"verificarTabla__EnLaColumna__TieneLosValores", 22));
		
		
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" contienen los valores: \"\"", 	"verificarTabla__EnLaColumna__ContieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" contienen los valores:\"\"", 	"verificarTabla__EnLaColumna__ContieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que en la tabla \"\" la columna \"\" tiene los valores: \"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" contiene los valores: \"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" contiene los valores:\"\"", 		"verificarTabla__EnLaColumna__TieneLosValores", 22));
		list.add(new StepCategorizado("Verificar que la tabla \"\" en la columna \"\" contiene los iconos: \"\"", 		"verificarEnTabla__LosValoresDeColumna__", 22));	

		
		
		list.add(new StepCategorizado("verificar que aparece pantalla \"\"", "verificarAparecePantalla__", 1));
		
		/**
		 	##################
			#Frases a Ordenar#
			##################
		 */
		
		list.add(new StepCategorizado("Verificar que los siguientes botones est�n inactivos:\"\"", 	"verificarBoton__Inactivo", 4));
		list.add(new StepCategorizado("Verificar que los siguientes botones est�n activos:\"\"", 	"verificarBoton__Activo", 4));

		list.add(new StepCategorizado("Verificar que existen los siguientes botones: \"\"", 			"verificarBoton__Existente", 4));
		list.add(new StepCategorizado("Verificar que existen los siguientes botones:\"\"", 			"verificarBoton__Existente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes botones:\"\"", 		"verificarBoton__NoExistente", 4));
		list.add(new StepCategorizado("Verificar que no existen los siguientes botones: \"\"", 		"verificarBoton__NoExistente", 4));
		
		list.add(new StepCategorizado("Verificar que el bot�n \"\" est� inactivo", 					"verificarBoton__Inactivo", 0));
		list.add(new StepCategorizado("Verificar que el bot�n \"\" est� activo", 					"verificarBoton__Activo", 0));
		list.add(new StepCategorizado("Verificar que el siguiente�bot�n�est� activo:\"\"", 			"verificarBoton__Activo", 0));
		list.add(new StepCategorizado("Verificar que el siguiente�bot�n�est� inactivo:\"\"", 		"verificarBoton__Inactivo", 0));

//		-- no esta en el diccionario
//		list.add(new StepCategorizado("Verificar la lista de resultados en la tabla \"\"", 			"verificarListaResultadosEnTabla__", 0));
		
		/**
		 	#################################
			#Verificaciones Popups y paginas#
			#################################
		 */
		
		list.add(new StepCategorizado("Verificar que se abre el pop-up \"\"", 						"verificarSeAbrePopup__", 0));

		list.add(new StepCategorizado("Verificar que se abre el pop-up \"\" con mensaje: \"\"", 	"verificarSeAbrePopup__ConMensaje", 1));
		list.add(new StepCategorizado("Verificar que se abre el pop-up \"\" con el mensaje: \"\"", 	"verificarSeAbrePopup__ConMensaje", 1));
		list.add(new StepCategorizado("Verificar que se abre el pop-up \"\" con el : \"\"", 	"verificarSeAbrePopup__ConMensaje", 1));
		
		list.add(new StepCategorizado("Verificar que se abre la p�gina \"\"", 					"verificarSeAbrePagina__", 0));
		list.add(new StepCategorizado("Verificar que se abre la pantalla \"\"", 				"verificarSeAbrePantalla__", 0));
		
		list.add(new StepCategorizado("Verificar que se cierra el pop-up \"\"", 				"verificarSeCierraPopup__", 0));
		list.add(new StepCategorizado("Verificar que se cierra la p�gina \"\"", 				"verificarSeCierraPagina", 0));
		list.add(new StepCategorizado("Verificar que se cierra la pantalla \"\"", 				"verificarSeCierraPantalla__", 0));
		
		list.add(new StepCategorizado("Verificar que en el men� \"\" en el grupo \"\": existe el campo \"\"", 		"verificarMenu__EnGrupo__ExisteElCampo", 3));
		list.add(new StepCategorizado("Verificar que en el men� \"\" en el grupo \"\": existen los campos: \"\"", 	"verificarMenu__EnGrupo__ExisteElCampo", 6));
		list.add(new StepCategorizado("Verificar que en el men� \"\" en el grupo \"\": no existe el campo \"\"", 	"verificarMenu__EnGrupo__NoExisteElCampo", 3));
		
		list.add(new StepCategorizado("Verificar que en el men� \"\" existe el grupo \"\"", 			"verificarQueMenu__ExisteGrupo__", 0));
		list.add(new StepCategorizado("Verificar que en el men� \"\" no existe el grupo \"\"", 			"verificarQueMenu__NoExisteGrupo__", 0));
		
		list.add(new StepCategorizado("Verificar que en la tabla \"\" las columnas: \"\" tienen los valores: \"\"", "verificaQueTabla__EnLaColumna__TieneLosValores", 6));	// ver en trello el porque del nombre del metodo

		list.add(new StepCategorizado("Copiar el valor del campo \"\" como <>", 								"copiarValorDelCampo__", 0));
		list.add(new StepCategorizado("Copiar los valores de los campos: \"\" como <>", 						"copiarValorDelCampo__", 4));
		list.add(new StepCategorizado("Copiar los valores de la tabla \"\" de las columnas: \"\" como \"\"", 	"copiarValorDelCampo__", 4));
		list.add(new StepCategorizado("Copiar los valores de la tabla \"\" de los campos:\"\"como\"\"", 		"copiarValorDelCampo__", 4));

		list.add(new StepCategorizado("Copiar los valores de los campos:\"\"como \"\"", 						"copiarValoresDeTabla__DeColumna__", 11));
		list.add(new StepCategorizado("Copiar los valores de los campos:\"\" como \"\"", 						"copiarValoresDeTabla__DeColumna__", 11));
		list.add(new StepCategorizado("Copiar los valores de los campos: \"\" como \"\"", 						"copiarValoresDeTabla__DeColumna__", 11));
		
		list.add(new StepCategorizado("Anotar el valor del campo \"\" como <>", 								"copiarValorDelCampo__", 0));
		list.add(new StepCategorizado("Anotar los valores de los campos: \"\" como \"\"", 						"copiarValorDelCampo__", 4));
		list.add(new StepCategorizado("Anotar los valores de los campos:\"\"como\"\"", 							"copiarValorDelCampo__", 4));

		list.add(new StepCategorizado("Anotar los valores de la tabla \"\" de la columna \"\" como :\"\"", 		"copiarValoresDeTabla__DeColumna__", 21));
		list.add(new StepCategorizado("Anotar los valores de la tabla \"\" de la columna \"\" como:\"\"", 		"copiarValoresDeTabla__DeColumna__", 21));
		list.add(new StepCategorizado("Anotar los valores de la tabla \"\" de la columna \"\" como: \"\"", 		"copiarValoresDeTabla__DeColumna__", 21));
		list.add(new StepCategorizado("Anotar los valores de la tabla \"\" de las columnas: \"\" como \"\"",	"copiarValoresDeTabla__DeColumna__", 21));	
		
		
	}
	
	public StepCategorizado getMachineLearningParse(String clave) {
		
		String clave_tmp = clave;
		
		clave_tmp = StringUtils.normalizeSpace(clave_tmp);
		
//		Charset
		
//		clave_tmp = clave_tmp.replaceAll("\\P{Print}","");
//		byte[] a = clave_tmp.getBytes();
		
//		clave_tmp = StringUtils.replace(clave_tmp, ".", "");

//		clave_tmp = GenericCommon.replaceAccents(clave_tmp);
//		if(!StringUtils.contains(clave_tmp, "\"\":\"\"")){
//			clave_tmp = StringUtils.replace(clave_tmp, ".", "");
//			clave_tmp = StringUtils.replace(clave_tmp, "   ", "");
//			clave_tmp = StringUtils.replace(clave_tmp, "  ", "");
//		}
		
		StepCategorizado res = null;
		
		if(StringUtils.containsIgnoreCase(clave_tmp, " y ")){
			String[] split = StringUtils.split(clave_tmp, "y");
			if(split != null)
				clave_tmp = StringUtils.substring(split[0], 0, split[0].length()-1);
		}
		
 		for(StepCategorizado ddl : list){
			
			String compare = ddl.getStepDiccionario();

//			compare = compare.replaceAll("\\p{C}", "?");
			
//			if(!StringUtils.contains(compare , "\"\":\"\"")){
//				compare = StringUtils.replace(compare, "   ", "");
//				compare = StringUtils.replace(compare, "  ", "");
//				compare = StringUtils.replace(compare, " ", "");
//			}
			
			if ((StringUtils.equalsIgnoreCase(clave_tmp, compare) || StringUtils.containsIgnoreCase(clave_tmp, compare))){
				res = ddl;
				
				StepCategorizado tmp_res = devolverSiCoincideConOtrasFrases(clave_tmp); 

				res = tmp_res != null ? tmp_res : res;
				
				if(res!=null)
					break;
				
			}		
		}
				
		return res;
	}
	
	private String cleanTextContent(String text)
	{
	   // strips off all non-ASCII characters
	   text = text.replaceAll("[^\\x00-\\x7F]", "");

	   // erases all the ASCII control characters
	   text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
	   
	   // removes non-printable characters from Unicode
	   text = text.replaceAll("\\p{C}", "");

	   return text.trim();
	}
	
	private StepCategorizado devolverSiCoincideConOtrasFrases(String clave) {
		
		StepCategorizado tmp_clave = null;
				
		for(StepCategorizado sc : list){
			
			String diccionario = sc.getStepDiccionario();
			
			if (StringUtils.equalsIgnoreCase(diccionario, clave)){
				tmp_clave = sc;
			}
		}
		
		return tmp_clave;
	}
		
}
