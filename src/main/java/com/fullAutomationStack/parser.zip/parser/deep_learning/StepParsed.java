package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class StepParsed {

	
	@Getter @Setter	private String stepFromExcel;
	@Getter @Setter	private String step;
	@Getter @Setter	private String typeStep;
	@Getter @Setter	private List<String> entrecomillado_step;
	@Getter @Setter	private List<String> parametros;
	@Getter @Setter private List<String> variablesAsignar;
	
	public StepParsed() {
		
	}
	
	public StepParsed(String excel_step, String step, List<String> entrecomillado_step, List<String> parametros){
		this.stepFromExcel = excel_step;
		this.step	= step;
		this.entrecomillado_step = entrecomillado_step;
		this.parametros = parametros;
	}
	
	public void addParametros(List<String> parametros) {
		for(String p : parametros)
			this.parametros.add(p);			
	}
	
	public void addVariablesAsignadas(List<String> variablesAsignadas) {
		this.variablesAsignar = (this.variablesAsignar == null ? new ArrayList<String>() : this.variablesAsignar);
		for(String p : variablesAsignadas)
			this.variablesAsignar.add(p);			
	}
	
}
