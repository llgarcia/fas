package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import lombok.Setter;

public class MetodoDeclarado {

	@Getter @Setter	private String contexto;	
	@Getter @Setter	private String tipoMetodo;	
	@Getter @Setter	private String llamadaMetodo;
	@Getter @Setter	private Integer categoria;
	@Getter @Setter	private List<String> parametros;
	@Getter @Setter	private boolean tieneParametroDeclarado;
	
	@Getter @Setter private boolean esMetodoDeclaradoAsignable;
	@Getter @Setter private List<String> variablesAsignadas;
	@Getter @Setter private String tipoVariable;
	
	@Getter @Setter private boolean implementado = false;

	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, Integer categoria, List<String> variablesAsignadas) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		this.parametros = null;
		this.categoria = categoria;
		this.variablesAsignadas = variablesAsignadas;
	}
	
	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, List<String> parametros, Integer categoria) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		this.parametros = parametros;
		this.categoria = categoria;
	}
	
	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, String parametro, Integer categoria) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		
		if(parametro != null){
			this.parametros = new ArrayList<String>();
			this.parametros.add(parametro);			
		} else
			this.parametros = null;
		
		this.categoria = categoria;
	}
	
	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, String parametro, String tipoAsignacion, Integer categoria) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		
		if(parametro != null){
			this.parametros = new ArrayList<String>();
			this.parametros.add(parametro);			
		} else
			this.parametros = null;
		
		this.categoria = categoria;
	}
	
	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, String parametro, boolean tieneParametroDeclarado, Integer categoria) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		
		if(parametro != null){
			this.parametros = new ArrayList<String>();
			this.parametros.add(parametro);			
		} else
			this.parametros = null;
		
		this.tieneParametroDeclarado = tieneParametroDeclarado;
		this.categoria = categoria;
		
	}
	
	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, String parametro, String tipoVariableAsignacion, boolean tieneParametroDeclarado, Integer categoria, List<String> variablesAsignadas) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		this.tipoVariable = tipoVariableAsignacion;
		this.variablesAsignadas = variablesAsignadas;
		
		if(parametro != null && StringUtils.isNotEmpty(parametro)){
			this.parametros = new ArrayList<String>();
			this.parametros.add(parametro);			
		} else
			this.parametros = null;
		
		this.tieneParametroDeclarado = tieneParametroDeclarado;
		this.categoria = categoria;
			
	}
	
	public MetodoDeclarado(String contexto, String tipoMetodo, String llamadaMetodo, List<String> parametros, String tipoVariableAsignacion, boolean tieneParametroDeclarado, Integer categoria, List<String> variablesAsignadas) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		this.tipoVariable = tipoVariableAsignacion;
		this.variablesAsignadas = variablesAsignadas;
		
		this.parametros = parametros;
		
		this.tieneParametroDeclarado = tieneParametroDeclarado;
		this.categoria = categoria;
			
	}
	
	
	
	
	
}
