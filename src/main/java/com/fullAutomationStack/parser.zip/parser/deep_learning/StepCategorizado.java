package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import lombok.Getter;
import lombok.Setter;

public class StepCategorizado {

	@Getter @Setter
	private String stepDiccionario;

	@Getter @Setter
	private String prefijoStepFramework;

	@Getter @Setter
	private int categoria;
	
	public StepCategorizado (String stepDiccionario, String prefijoStepFramework, int categoria) {
		this.stepDiccionario = stepDiccionario;
		this.prefijoStepFramework = prefijoStepFramework;
		this.categoria = categoria;
	}
	
}
