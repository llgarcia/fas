package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto.ContextoObject;

import lombok.Getter;
import utils_selenium.GenericCommon;

public class UtilsParserDeepLearning {

	@Getter
	private static StepParsed dlo;
			
	public static StepParsed parseExcelToDiccionarioDeepLearning(ContextoObject co, String excel_step) {
		
		String excelStep_tmp = excel_step;
		
		dlo = new StepParsed();
		
		dlo.setStepFromExcel(excelStep_tmp);
				
		excelStep_tmp = quitStepEntrecomillado(excelStep_tmp);
		excelStep_tmp = quitStepParametros(excelStep_tmp, excel_step);
		excelStep_tmp = GenericCommon.removeHexaChars(excelStep_tmp);
		if(StringUtils.containsIgnoreCase(excelStep_tmp, "�"))
			excelStep_tmp = quitStepVariablesAsignadas(excelStep_tmp);
		
		dlo.setStep(excelStep_tmp);
		
		return dlo;
	}
	
	private static String quitStepEntrecomillado(String step) {
		
		String step_res = step;
		
		List<Integer> listado_posiciones = GenericCommon.listOccurrencesByString(step_res, "\"");
		
		List<String> entrecomillado = new ArrayList<String>();
		List<String> entrecomillado_con_comillas = new ArrayList<String>();
		
		if(listado_posiciones.size() != 0){
			if(((listado_posiciones.size() % 2) == 0)) {
				for(int pos = 0; pos < listado_posiciones.size(); pos++){
										
					if(listado_posiciones.get(pos+1) != null){
						Integer ini = listado_posiciones.get(pos);
						Integer fin = listado_posiciones.get(pos+1) + 1;
						
						entrecomillado.add(StringUtils.substring(step_res, ini, fin));
										
						pos++;
					}
					
				}
				
				for(int a = 0; a < entrecomillado.size(); a++){
					String param = entrecomillado.get(a);
								
		//			String paramtmp = CommonGenericUtils.removeHexaChars(param);
					entrecomillado_con_comillas.add(param);
					
					param = StringUtils.replace(param, "\"", "");
					entrecomillado.set(a, param);
				}
						
				for(String r : entrecomillado_con_comillas)
					step_res = StringUtils.replace(step_res, r, "\"\"");
									
				step_res = GenericCommon.quitarDoblesEspacios(step_res);
				step_res = GenericCommon.removeHtmTags(step_res);
				step_res = GenericCommon.removeHexaChars(step_res);
				step_res = GenericCommon.replaceComillasVariasPorDobles(step_res);
				step_res = GenericCommon.replaceComillasVariasConEspaciosPorDobles(step_res);
				
				dlo.setEntrecomillado_step(GenericCommon.reempleaarEspaciosYCapitalizar(entrecomillado));
			}
		}
			
		return step_res;
	}
	
	private static String quitStepParametros(String step, String step_complete) {
		
		String step_res = step;
		
		step_res = GenericCommon.removeHtmTags(step_res);
		
		List<Integer> listado_posiciones = null;
		listado_posiciones = GenericCommon.listDoubleOccurrencesByString(step_res, "{", "}");
		listado_posiciones = listado_posiciones.size() == 0 ? GenericCommon.listDoubleOccurrencesByString(step_res, "<", ">") : listado_posiciones;
		
		List<String> parametros = new ArrayList<String>();
		
		if(listado_posiciones.size() != 0){
			if(((listado_posiciones.size() % 2) == 0)) {
				for(int pos = 0; pos < listado_posiciones.size(); pos++){
					
					if(listado_posiciones.get(pos+1) != null){
						Integer ini = listado_posiciones.get(pos);
						Integer fin = listado_posiciones.get(pos+1) + 1;
										
						parametros.add(StringUtils.substring(step_res, ini, fin));
		
						pos++;
					}
				}
				
				for(int a = 0; a < parametros.size(); a++){
					String param = parametros.get(a);
					param = StringUtils.replace(param, "{", "");
//					param = StringUtils.replace(param, "[", "\"");
//					param = StringUtils.replace(param, "]", "\"");
					param = StringUtils.replace(param, "<", "");
					param = StringUtils.replace(param, "}", "");
					param = StringUtils.replace(param, ">", "");
					
					parametros.set(a, param);
				}
				
				for(String r : parametros)
					step_res = StringUtils.replace(step_res, r, "");
					
				step_res = StringUtils.replace(step_res, "$", "");
				step_res = StringUtils.replace(step_res, "{", "\"");
				step_res = StringUtils.replace(step_res, "}", "\"");

				step_res = GenericCommon.quitarDoblesEspacios(step_res);
				step_res = GenericCommon.replaceComillasVariasPorDobles(step_res);
				step_res = GenericCommon.replaceComillasVariasConEspaciosPorDobles(step_res);
				
				dlo.setParametros(parametros);
			}
		}
		
		
		return step_res;
	}
	

	private static String quitStepVariablesAsignadas(String step) {
				
		String step_res = step;
		
		if(StringUtils.contains(step, "�")){
		
			step_res = GenericCommon.removeHtmTags(step_res);
			
			List<Integer> listado_posiciones = null;
			listado_posiciones = GenericCommon.listOccurrencesByString(step_res, "�");
			
			List<String> parametros = new ArrayList<String>();
			
			if(listado_posiciones.size() != 0){
				if(((listado_posiciones.size() % 2) == 0)) {
					for(int pos = 0; pos < listado_posiciones.size(); pos++){
						
						if(listado_posiciones.get(pos+1) != null){
							Integer ini = listado_posiciones.get(pos);
							Integer fin = listado_posiciones.get(pos+1) + 1;
											
							parametros.add(StringUtils.substring(step_res, ini, fin));
			
							pos++;
						}
					}
					
					for(int a = 0; a < parametros.size(); a++){
						String param = parametros.get(a);
						param = StringUtils.replace(param, "�", "");
						
						parametros.set(a, param);
					}
					
					for(String r : parametros)
						step_res = StringUtils.replace(step_res, r, "");
						
					step_res = StringUtils.replace(step_res, "�", "\"");
					step_res = GenericCommon.quitarDoblesEspacios(step_res);
					step_res = GenericCommon.replaceComillasVariasPorDobles(step_res);
					step_res = GenericCommon.replaceComillasVariasConEspaciosPorDobles(step_res);
					
					dlo.addVariablesAsignadas(parametros);
				}
			}
			
		}
		
		return step_res;
	}
		
}
