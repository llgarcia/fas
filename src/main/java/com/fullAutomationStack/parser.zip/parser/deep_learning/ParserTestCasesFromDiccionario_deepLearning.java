package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;

import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.testing_web.sogeti.___global_tools.DiccionarioDeLiterales;
import com.testing_web.sogeti.___global_tools.parser.GeneradorClass;
import com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto.ContextoObject;
import com.testing_web.sogeti.___global_tools.parser.definidor_de_contexto.DefinidorDeContextoParaDiccionario;
import com.testing_web.sogeti.___global_tools.propiedades.Propiedades;

import testing_common.ScreenshotsCommon;
import utils_selenium.GenericCommon;

public class ParserTestCasesFromDiccionario_deepLearning extends GeneradorClass{

	public ContextoObject contextObject;
	protected Map<String, String> diccionario;
	
	private static List<MetodoDeclarado> listadoMetodos = null;
	public static List<MetodoDeclarado> listadoMetodosTmp = null;
	
	public static String className = "";
	
	protected boolean existe_parseado;
	
	private String construirClassName(String testCaseName){
		className = "TEST_CASE_" + testCaseName;
		return className;
	}
	
	public void definirNombreDeClase() {
		declararNombreDeClase(construirClassName(Propiedades.CONTEXTO));
	}
	
	public void definirNombreDeClase(String nombreClase) {
		declararNombreDeClase(construirClassName(GenericCommon.reemplazarEspaciosYCapitalizarCadena(GenericCommon.replaceAccents(nombreClase))));
	}

	private String getMetodoDeClaseSegunTestStep(String excelTestStep) {
		String stepMethodInClass = new String();

		Object metodo = null;
				
		stepMethodInClass = getParsedValue(excelTestStep);				
		
		if(StringUtils.isNotEmpty(stepMethodInClass))
			
			if (esStepDeVerificacion(excelTestStep))
				metodo = getMethodVerificacion(stepMethodInClass);
			
			else if(esStepDeStep(excelTestStep))
				metodo = getMethodStep(stepMethodInClass);
			
			else if(esStepDeProceso(excelTestStep) || esStepDeProceso(stepMethodInClass))
				metodo = getMethodProcess(stepMethodInClass);

		return (metodo != null ? stepMethodInClass : null);

	}
	
	public Object getMetodoClaseSegunTestStep(String stepMethodInClass){

		Object metodo = null;
		
		if(StringUtils.isNotEmpty(stepMethodInClass))
			
			if (esStepDeVerificacion(stepMethodInClass))
				metodo = getMethodVerificacion(stepMethodInClass);
			
			else if(esStepDeStep(stepMethodInClass))
				metodo = getMethodStep(stepMethodInClass);
			
			else if(esStepDeProceso(stepMethodInClass))
				metodo = getMethodProcess(stepMethodInClass);
		
		return metodo;
	}
	
	private Method getMethodProcess(String nombreMetodo){
		Method method = null;
		
		if (method == null) {
			try {
				
				method = contextObject.proceso.getMethod(nombreMetodo);
				
			} catch (NoSuchMethodException | SecurityException e) {
				
				for (Method m : contextObject.proceso.getMethods())
					if (StringUtils.equals(m.getName(), nombreMetodo))
						method = m;
						
			}
		}
		
		return method;
	}
	
	private Method getMethodStep(String nombreMetodo) {
		Method method = null;

		if (method == null) {
			try {
				method = contextObject.steps.getMethod(nombreMetodo);
			} catch (NoSuchMethodException | SecurityException e) {
				
				for (Method m : contextObject.steps.getMethods())
					if (StringUtils.equals(m.getName(), nombreMetodo)){
						method = m;
						break;
					}
			}
		}
		
		return method;
	}

	private Method getMethodVerificacion(String nombreMetodo) {
		Method validacionMethodo = null;
		
		if (validacionMethodo == null) {
			try {
				validacionMethodo = contextObject.validaciones.getDeclaredMethod(nombreMetodo);
			} catch (NoSuchMethodException | SecurityException e) {
				
				for (Method m : contextObject.validaciones.getMethods()){
//					System.out.println(m.getName());
					if (StringUtils.equals(m.getName(), nombreMetodo))
						validacionMethodo = m;
				}
				
			}
		}

		return validacionMethodo;
	}
	
	private boolean esStepDeVerificacion(String testStep) {
		return StringUtils.equals(identificarTipoDeStep(testStep), "validar");
	}
	
	private boolean esStepDeStep(String testStep){
		return StringUtils.equals(identificarTipoDeStep(testStep), "steps");
	}
	
	private boolean esStepDeProceso(String testStep) {
		return StringUtils.equals(identificarTipoDeStep(testStep), "proceso");
	}

	private String identificarTipoDeStep(String step) {

		String res = "";

		if (!StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.verificar) 
				&& !StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.xlsx)
				&& !StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.llamar)
				&& !StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.setup))
			
			res = "steps";

		else if (StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.verificar))
			res = "validar";
		
		else if(StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.llamar) 
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.setup) 
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.xlsx)
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.proceso)
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.losSiguientesCampos)
				|| StringUtils.containsIgnoreCase(step, DiccionarioDeLiterales.lasSiguientesCampos))
			
			res = "proceso";

		return res;
	}
	
	public boolean existeStepParseadoEnClaseController(String testStep) {
		return getMetodoDeClaseSegunTestStep(testStep) == null ? false : true;
	}
	
	public boolean excelTestStepActualTieneVariosSteps(String excel_step) {
		
		if(!StringUtils.contains(excel_step, "Llamar el setup")){
			List<String> steps = devolverListadoDeAccionesClaveEnExcelStep(excel_step);
			
	//		Integer count = 0;
			
			// creo que esto hay que hacerlo cuando son "palabras" iguales?
	//		if(steps.size() != 0)
	//			count = GenericCommon.listOccurrencesByWord(excel_step, steps.get(0));
					
			return steps.size() > 1;
		} else
			return false;
		
	}

	private List<String> devolverListadoDeAccionesClaveEnExcelStep(String excel_step) {

		List<String> steps = new ArrayList<String>();

// 		01/10/2017 -- quitamos esto ya que no es un paso, solamente especifica el contexto, con lo cual no produce ninguna accion...
//		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.enLaPestana) && !StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicarEnLaPestana) )
//			steps.add(DiccionarioDeLiterales.enLaPestana);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicar))
			steps.add(DiccionarioDeLiterales.clicar);		
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.escribir) && !StringUtils.containsIgnoreCase(excel_step, "setup"))
			steps.add(DiccionarioDeLiterales.escribir);

		if ((StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.seleccionar) 
				&& !StringUtils.containsIgnoreCase(excel_step, "\"Deseleccionar")
				&& !StringUtils.containsIgnoreCase(excel_step, "\"Seleccionar"))
				&& !StringUtils.containsIgnoreCase(excel_step, "setup"))
			steps.add(DiccionarioDeLiterales.seleccionar);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.verificar))
			steps.add(DiccionarioDeLiterales.verificar);
		
		if	(StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.llamar))
			steps.add(DiccionarioDeLiterales.llamar);

		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.pega))
			steps.add(DiccionarioDeLiterales.pega);

		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.anotar))
			steps.add(DiccionarioDeLiterales.anotar);
		
		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.copiar) )
			steps.add(DiccionarioDeLiterales.copiar);
		
		

		if (StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicIntro) || StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.clicarIntro)) {
			for(int cnt = 0; cnt <= steps.size() - 1; cnt++)
				if(StringUtils.equalsIgnoreCase(steps.get(cnt), DiccionarioDeLiterales.clic) || StringUtils.equalsIgnoreCase(steps.get(cnt), DiccionarioDeLiterales.clicar))
					steps.remove(cnt);					
		}
				
		
		if(steps.size() > 1){
			Integer index_step_1 = StringUtils.indexOfIgnoreCase(excel_step, steps.get(0));
			Integer index_step_2 = StringUtils.indexOfIgnoreCase(excel_step, steps.get(1));
		
			if(index_step_2 < index_step_1){
				String i1 = steps.get(0);
				String i2 = steps.get(1);
				
				steps.set(0, i2);
				steps.set(1, i1);
			}
						
		}	
			
		return steps;
	}

	private String quitarLetraY(String step) {
		String res = StringUtils.replace(step, " y ", "");
		if(StringUtils.contains(res, " y"))
			res = StringUtils.replace(step, " y", "");
			
		if(StringUtils.contains(res, "y "))	
			res = StringUtils.replace(step, "y ", "");
			
		return res;
	}

	public List<String> extrarPasoDeExcelStep(String excel_step) {

		List<String> steps = devolverListadoDeAccionesClaveEnExcelStep(excel_step);

		List<String> res = new ArrayList<String>();

		for (Integer count = 0; count <= steps.size() - 1; count++) {
			
			try {
				// coje el siguiente step para partirlo a partir de ahi
				String step_inicialq = steps.get(count + 1);
				
				excel_step = StringUtils.lowerCase(excel_step);
				step_inicialq = StringUtils.lowerCase(step_inicialq);
				
				String antes1step = StringUtils.substringBefore(excel_step, steps.get(count));
				
				if (steps.size() == 2) {
					res.add(quitarLetraY(StringUtils.substringBetween(excel_step, antes1step, step_inicialq)));
					res.add(quitarLetraY(step_inicialq + StringUtils.substringAfter(excel_step, step_inicialq)));
					break;
				}
			} catch (IndexOutOfBoundsException e){
				res.add("Hay mas de 2 pasos en una celda o se repiten 2 pasos iguales. Esta casuistica no se puede tratar.");
			}
		}

		return res;
	}
	
	private static List<String> devolverParametrosSiTieneSampleData(String sample_data) {

		List<String> res = new ArrayList<String>();
		String[] parametros = null;

		if(StringUtils.contains(sample_data, ","))
			parametros = StringUtils.split(sample_data, ",");
		
		else if(StringUtils.contains(sample_data, "\n"))
			parametros = StringUtils.split(sample_data, "\n");

		else 
			parametros = StringUtils.split(sample_data, ",");

		for (String param : parametros)
			res.add("\"" + StringUtils.substringBetween(param, "\"", "\"") + "\"");
		

		return res;
	}
	
	public static List<String> devolverParametrosSiTieneSampleDataConClave(String sample_data) {
		List<String> res = new ArrayList<String>();
		String[] parametros = null;
		
		sample_data = GenericCommon.removeHtmTags(sample_data);

//		if(StringUtils.contains(sample_data, ","))
//			parametros = StringUtils.split(sample_data, ",");
		
		if(StringUtils.contains(sample_data, "\n"))
			parametros = StringUtils.split(sample_data, "\n");

		else 
			parametros = StringUtils.split(sample_data, ",");

		for (String param : parametros)
			res.add(param);
		

		return res;
	}
	
	private static List<String> devolverParametrosMapeadosInArray(String sample_data) {
		List<String> res = new ArrayList<String>();
		
		for(String param : devolverParametrosSiTieneSampleDataConClave(sample_data)) 
			if(StringUtils.contains(param, "$"))
				res.add(devolverParametroData(param));
		
		return res;		
	}
	
	private static Map<String, String> devolverParametrosMapeados(String sample_data) {
		Map<String, String> map = new HashedMap<String, String>();
		
		List<String> parametros_sample_data = devolverParametrosSiTieneSampleDataConClave(sample_data);
		
		for(String param : parametros_sample_data)
			if(StringUtils.contains(param, "$"))
				map.put(devolverParametroClave(param), devolverParametroData(param));
		
		return map;		
	}
	
	private static String devolverParametroData(String data) {
		
//		System.out.println("DATA: " + data);
		String entrecomillado = "";
		
		List<Integer> listado_posiciones = GenericCommon.listOccurrencesByString(data, "\"");
									
		if(listado_posiciones.size() > 1)
			for(int pos = 0; pos < listado_posiciones.size(); pos++){
				
				if(listado_posiciones.get(pos+1) != null){
					Integer ini = listado_posiciones.get(pos);
					Integer fin = listado_posiciones.get(pos+1) + 1;
					
					entrecomillado = (StringUtils.substring(data, ini, fin));
//					entrecomillado = StringUtils.lowerCase(entrecomillado);
					pos++;
				}
			}
		
		else {
			if(StringUtils.contains(data, "=")){
				
				data = StringUtils.replace(data, " =", "=");
				data = StringUtils.replace(data, "= ", "=");
			try{
				entrecomillado = StringUtils.split(data, "=")[1];
				
			} catch(IndexOutOfBoundsException e) {
//				System.err.println("NO ENCUENTRA VALOR PARAMETRO: " + data);
			}
				
			} else if (StringUtils.contains(data, ":")) {
				
				data = StringUtils.replace(data, " :", ":");
				data = StringUtils.replace(data, ": ", ":");
				
				try{
					entrecomillado = StringUtils.split(data, ":")[1];
				} catch(IndexOutOfBoundsException e) {
//					System.err.println("NO ENCUENTRA VALOR PARAMETRO: " + data);
				}
			}
		}
		
		entrecomillado = StringUtils.replace(entrecomillado, "\"", "");
				
		if(!StringUtils.contains(entrecomillado, "\"")){
			entrecomillado = "\"" + entrecomillado + "\"";
		}
		
		return entrecomillado;
			
	}
	
	private static String devolverParametroClave(String data) {
		
		String step_res = data;
		
		List<Integer> listado_posiciones = GenericCommon.listDoubleOccurrencesByString(step_res, "{", "}");
		
		String parametro = "";
		
		for(int pos = 0; pos < listado_posiciones.size(); pos++){
			
			if(listado_posiciones.get(pos+1) != null){
				Integer ini = listado_posiciones.get(pos);
				Integer fin = listado_posiciones.get(pos+1) + 1;
								
				parametro = StringUtils.substring(step_res, ini, fin);
//				parametro = StringUtils.lowerCase(parametro);
				pos++;
			}
			
		}
	
		parametro = StringUtils.replace(parametro, "{", "");
		parametro = StringUtils.replace(parametro, "}", "");

		return parametro;
		
	}

	public static boolean tieneParametrosSampleData(String sampleData) {
		return StringUtils.contains(sampleData, "{") && StringUtils.contains(sampleData, "}")
				&& StringUtils.contains(sampleData, "$");
	}
	
	
	// TODO revisar el tema de tratar los valores claves 
//	private boolean tieneValidacionesTestStep(String excel_step) {
//		return esValidacionDeVariosValores(excel_step)|| esValidacionSoloUnValor(excel_step) || esValorPegado(excel_step);
//	}
	
//	private boolean esValorPegado(String excel_step) {
//		return StringUtils.containsIgnoreCase(excel_step, "pega el n�mero de");
//	}
	
//	private boolean esValorCopiado(String excel_step) {
//		return StringUtils.containsIgnoreCase(excel_step, "copiado");
//	}
//	
//	private boolean esValorABuscarEnTabla(String excel_step){
//		return StringUtils.containsIgnoreCase(excel_step, "para el");
//	}
	
//	private boolean esValidacionDeVariosValores(String excel_step) {
//		return StringUtils.containsIgnoreCase(excel_step, "aparecen los siguientes campos") 
//			|| StringUtils.containsIgnoreCase(excel_step, "tiene los siguientes valores en la cabecera")
//			|| StringUtils.containsIgnoreCase(excel_step, "los campos siguientes son editables")
//			|| StringUtils.containsIgnoreCase(excel_step, "los campos siguientes no editables")
//			|| StringUtils.containsIgnoreCase(excel_step, "las siguientes opciones estan en el desplegable del campo");
//	}
	
//	private boolean esValidacionSoloUnValor(String excel_step) {
//		return StringUtils.containsIgnoreCase(excel_step, "tiene el valor") || StringUtils.containsIgnoreCase(excel_step, "no tiene el valor");
//	}

//	private List<String> devolverValidacionesSiTieneSegunExcelStep(String excel_step) {
//	
//		List<String> parametros = new ArrayList<String>();
//		
// 		
//		String[] varios_parametros = null;
//	
//		String valor;
//		
//		if(esValidacionDeVariosValores(excel_step)){
//			varios_parametros = StringUtils.split(excel_step, ":");
//			varios_parametros = StringUtils.split(varios_parametros[1], "\n");
//		} 
//			
//		if (esValidacionSoloUnValor(excel_step) && !esValorCopiado(excel_step)){
//			valor = StringUtils.substringAfter(excel_step, devolverSubstringDeValidaciones(excel_step));
//			valor = StringUtils.replace(valor, ".", "");
//			parametros.add(valor);
//		} 
//		
//		if(esValorPegado(excel_step)){
//			valor = StringUtils.substringBefore(excel_step, devolverSubstringDePegar(excel_step));	
//			valor = StringUtils.substringBeforeLast(valor, "\"");
//			valor = StringUtils.substringAfter(valor, "\"");
//			parametros.add(valor);
//		} 
//		
//		if(esValorCopiado(excel_step)){
//			valor = StringUtils.substringBetween(excel_step, devolverSubstringSegunVerificacion(excel_step), " copiado");
//			valor = StringUtils.replace(valor, "\"", "");
//			parametros.add(valor);
//		} 
//		
//		if(esValorABuscarEnTabla(excel_step)){
//			String devuleto = devolverSubstringEspecificacion(excel_step);
//			valor = StringUtils.substringBetween(excel_step, devuleto, " buscado");
//			valor = StringUtils.substringBetween(valor, "\"", "\"");
//			parametros.add(valor);
//		}
//					
//		if(parametros.size() > 1){
//			Integer index_step_1 = StringUtils.indexOf(excel_step, parametros.get(0));
//			Integer index_step_2 = StringUtils.indexOf(excel_step, parametros.get(1));
//		
//			if(index_step_2 < index_step_1){
//				String i1 = parametros.get(0);
//				String i2 = parametros.get(1);
//				
//				parametros.set(0, i2);
//				parametros.set(1, i1);
//			}
//						
//		}		
//										
//		return varios_parametros != null ? CommonGenericUtils.convertirArrayStringsInListStrings(varios_parametros) : parametros;
//	}
	
	private String devolverSubstringDeValidaciones(String excel_step) {
		String a = new String();
		
		if(StringUtils.containsIgnoreCase(excel_step, "aparecen los siguientes campos"))
			a = " aparecen los siguientes campos ";
		
		if(StringUtils.containsIgnoreCase(excel_step, "tiene los siguientes valores en la cabecera"))
			a = " tiene los siguientes valores en la cabecera ";
		
		if( StringUtils.containsIgnoreCase(excel_step, "los campos siguientes son editables"))
			a = " los campos siguientes son editables ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "los campos siguientes no editables"))
			a = " los campos siguientes no editables ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "las siguientes opciones estan en el desplegable del campo"))
			a = " las siguientes opciones estan en el desplegable del campo ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "tiene el valor"))
			a = " tiene el valor ";
		
		if (StringUtils.containsIgnoreCase(excel_step, "no tiene el valor"))
			a = " no tiene el valor ";
		
		return a;
	}
	
//	private String devolverSubstringDePegar(String excel_step) {
//		String a = new String();
//		
//		if (StringUtils.contains(excel_step, "pega el n�mero de"))
//			a = " pega el n�mero de ";
//		
//		return a;
//	}
	
//	private String devolverSubstringEspecificacion(String excel_step) {
//		String a = new String();
//		
//		if (StringUtils.containsIgnoreCase(excel_step, "para el"))
//			a = " para el ";
//		
//		return a;
//	}
	
	// se puede dar la opcion que devuelva 2 opciones
//	private String devolverSubstringSegunVerificacion(String excel_step) {
//		
//		String a = new String();
//		
//		if(StringUtils.containsIgnoreCase(excel_step, "aparecen los siguientes campos"))
//			a = " aparecen los siguientes campos ";
//		
//		if(StringUtils.containsIgnoreCase(excel_step, "tiene los siguientes valores en la cabecera"))
//			a = " tiene los siguientes valores en la cabecera ";
//		
//		if( StringUtils.containsIgnoreCase(excel_step, "los campos siguientes son editables"))
//			a = " los campos siguientes son editables ";
//		
//		if (StringUtils.containsIgnoreCase(excel_step, "los campos siguientes no editables"))
//			a = " los campos siguientes no editables ";
//		
//		if (StringUtils.containsIgnoreCase(excel_step, "las siguientes opciones estan en el desplegable del campo"))
//			a = " las siguientes opciones estan en el desplegable del campo ";
//		
//		if (StringUtils.containsIgnoreCase(excel_step, "tiene el valor"))
//			a = " tiene el valor ";
//		
//		if (StringUtils.containsIgnoreCase(excel_step, "no tiene el valor"))
//			a = " no tiene el valor ";
//		
//		
//		return a;
//		
//	}
	
	public ContextoObject definirContextObject(String testStep, String sampleData, String expectedResult) {
		
		ContextoObject currentContextObject = DefinidorDeContextoParaDiccionario.devolverControlador(testStep, sampleData, expectedResult);
		
		if(currentContextObject != null)
			if(!StringUtils.containsIgnoreCase(currentContextObject.contexto, "seleccionar una opci�n especifica de la tabla")
					&& !StringUtils.containsIgnoreCase(currentContextObject.contexto, "Firmar Ofertas"))
				if(!currentContextObject.getClass().equals(contextObject))
					contextObject = currentContextObject;

		return contextObject;
		
	}
	
	public boolean existeTestStepEnClases(String testStep, String sampleData){

		Object o = getMetodoDeclarado(testStep, sampleData);
		MetodoDeclarado md = null;
		MetodoDeclaradoIncorrecto me = null;
		
		if(o instanceof MetodoDeclarado)
			md = (MetodoDeclarado) o;
		
		if(o instanceof MetodoDeclaradoIncorrecto)
			me = (MetodoDeclaradoIncorrecto) o;
		
		if(md != null)
			return getMetodoClaseSegunTestStep(md.getLlamadaMetodo()) != null;
		else if(me != null)
			return false;
		else 
			return false;
		
	}
		
	
	
	public boolean existeContexto() {
		return contextObject != null && existeStepsClass() && existeProcesosClass() && existeValidacionesClass();
	}
	
	public boolean existeDiccionarioByContext() {
		return contextObject.diccionario != null;
	}
	
	public boolean existeStepsClass() {
		return contextObject.steps != null;
	}
	
	public boolean existeProcesosClass() {
		return contextObject.proceso != null;
	}

	public boolean existeValidacionesClass() {
		return contextObject.validaciones != null;
	}
		
	// OUT
	private String getParsedValue(String expected) {
		
		String res = "";		

		if(existeDiccionarioByContext())
			for (Entry<String, String> e : contextObject.diccionario.entrySet()){
				String compare = StringUtils.lowerCase(e.getKey());
//				System.out.println("DICC: " + compare + "' ---- '"+ expected +"'");
				if ((StringUtils.equalsIgnoreCase(expected, compare) || StringUtils.containsIgnoreCase(expected, compare)))
					res = e.getValue();
			}
		
		return res;
	}
		
//	private void guardarMetodoEnCuerpoTestCase(String excel_step, List<String> parametros) {
//				
//		if(!esMetodoAsignableAVariable(excel_step))
//			
//			generarLlamada_Objeto_Acceso_Action(contextObject.contexto, identificarTipoDeStep(excel_step), getParsedValue(excel_step), parametros);
//		
//		else if(esMetodoAsignableAVariable(excel_step))
//			
//			generarLlamadaMetodoAsignacionAVariable_Objeto_Acceso_Action(devolverVariableAssignacionSegunTestStep(excel_step), contextObject.contexto, identificarTipoDeStep(excel_step), getParsedValue(excel_step), parametros);
//		
//	}	
	
//	private void guardarMetodoEnCuerpoTestCase_deepLearning(String step_deepLearning, String methodDpl, List<String> entrecomillado,  List<String> parametros) {
//		
//		if(!esMetodoAsignableAVariable(step_deepLearning))
//			
//			generarLlamada_Objeto_Acceso_Action(contextObject.contexto, identificarTipoDeStep(step_deepLearning), methodDpl, parametros);
//		
//		else if(esMetodoAsignableAVariable(step_deepLearning))
//			
//			generarLlamadaMetodoAsignacionAVariable_Objeto_Acceso_Action(devolverVariableAssignacionSegunTestStep(step_deepLearning), contextObject.contexto, identificarTipoDeStep(step_deepLearning), methodDpl, parametros);
//		
//	}	
	
	private String devolverVariableAssignacionSegunTestStep(String excel_step) {
		return StringUtils.substringBetween(excel_step, "\"", "\"");
	}
	
	private boolean esMetodoAsignableAVariable(String excel_step) {
		
		if((StringUtils.containsIgnoreCase(excel_step, "copiar") || StringUtils.containsIgnoreCase(excel_step, "anotar") 
				&& (!StringUtils.containsIgnoreCase(excel_step, DiccionarioDeLiterales.xlsx))))
			return true;
		else
			return false;
		
	}

//	private boolean existeStepsClass(ContextoObject co){
//		return contextObject.steps != null;
//	}
//	
//	private boolean existeProcesoClass(ContextoObject co){
//		return contextObject.proceso != null;
//	}
	
//	private boolean existeValidacionClass(ContextoObject co){
//		return contextObject.validaciones != null;
//	}
	
	public void instanciarMetodosNecesarios(String testCaseName) {
		List<String> listParameters = new ArrayList<String>();
		listParameters.add("\"test\"");
		listParameters.add("\""+ className +"#" + GenericCommon.removeHexaChars(testCaseName) + "\"");
		generarLlamada_Objeto_Acceso_Action("System", "setProperty", listParameters);
		generarLlamada_Objeto_Acceso_Action("ScreenshotsCommon", "crearCarpetaEjecucionFrontales", null);
	}
	
	public void parsearMetodos(String testCaseName, List<String> testSteps, List<String> sampleData, List<String> expectedResult) {

		cuerpoMetodoDeclarado = new BlockStmt();

		existe_parseado = false;
		
		listadoMetodos = new ArrayList<MetodoDeclarado>();
		
		contextObject = null;
		
		instanciarMetodosNecesarios(testCaseName);
		
		for (Integer pos = 0; pos <= testSteps.size() - 1; pos++) {

			String excel_step = testSteps.get(pos);
			String data_step  = sampleData.get(pos);
			String expected_result = expectedResult.get(pos); 

 			instanciaObjetoSiNoExiste(excel_step, data_step, expected_result);
			
// 			System.out.println("------------------------" + excel_step);
 			
 			if(contextObject != null){
	 			if(existeStepsClass() && existeProcesosClass() && existeValidacionesClass()){
	 				 				
	 				DiccionarioDeepLearning deep = new DiccionarioDeepLearning();
	 				
	 				if (excelTestStepActualTieneVariosSteps(excel_step)) {
	 				
	 					for (String excel_step_extracted : extrarPasoDeExcelStep(excel_step)) {					
	 					
	 	 					StepParsed sp = UtilsParserDeepLearning.parseExcelToDiccionarioDeepLearning(contextObject, excel_step_extracted);
	 	 					
	 						StepCategorizado mlp = deep.getMachineLearningParse(sp.getStep());						
	 						
	 						if(mlp != null){
	 							if(existeTestStepEnClases(excel_step_extracted, data_step))
	 								existe_parseado = true;
	 							else
	 								existe_parseado = false;
	 						}
	 						
	 					}
	 					
	 				} else {
	 				 					
	 					StepParsed sp = UtilsParserDeepLearning.parseExcelToDiccionarioDeepLearning(contextObject, excel_step);					
	 					
						StepCategorizado mlp = deep.getMachineLearningParse(sp.getStep());						
	
						if(mlp != null){
							if(existeTestStepEnClases(excel_step, data_step))
								existe_parseado = true;
							else
								existe_parseado = false;
						}
	 				}
	 				
	 				// si ya encuentra un metodo que no existe ya no va a seguir con la definicion de otros metodos
	 				if(!existe_parseado)
						break;
	 			} else
	 				
	 				if(!existe_parseado)
						break;
 			} else 
 				if(!existe_parseado)
					break;
 			
		}
		
		if(existe_parseado)
		
			for(MetodoDeclarado md : listadoMetodos)
				
				if(!esMetodoAsignableAVariable(md.getLlamadaMetodo()))
					generarLlamada_Objeto_Acceso_Action(md.getVariablesAsignadas(), md.getContexto(), md.getTipoMetodo(), md.getLlamadaMetodo(), md.getParametros());
		
				else if(esMetodoAsignableAVariable(md.getLlamadaMetodo()))
					// necesito un String de "variable donde asigno", actualmente esta vacia esto tiene que venir de "definirMetodo()"
					if(md.getVariablesAsignadas() != null && md.getVariablesAsignadas().size() != 0)
						generarLlamadaMetodoAsignacionAVariable_Objeto_Acceso_Action(md.getVariablesAsignadas().get(0), md.getContexto(), md.getTipoMetodo(), md.getTipoVariable(), md.getLlamadaMetodo(), md.getParametros());
					else
						generarLlamadaMetodoAsignacionAVariable_Objeto_Acceso_Action("", md.getContexto(), md.getTipoMetodo(), md.getTipoVariable(), md.getLlamadaMetodo(), md.getParametros());
		
	}
	
	public boolean existeEstructuraDePasoEnDiccionario(String excel_step) {
		
		StepParsed sp = UtilsParserDeepLearning.parseExcelToDiccionarioDeepLearning(contextObject, excel_step);					
			
 		StepCategorizado mlp = new DiccionarioDeepLearning().getMachineLearningParse(sp.getStep());	
		
		return mlp != null ? true : false;
	}
	
	private String replaceFirstIdentificadorInPrefijo(String prefijo, String identificador) {
		String res = prefijo;
		
		if(StringUtils.contains(prefijo, "__"))
			res = StringUtils.replaceFirst(prefijo, "__", GenericCommon.removeRareChars(identificador));
								
		return res;
	}
		
	private String replaceIdentificadorInPrefijo(String prefijo, String identificador) {
		String res = prefijo;
		
		if(StringUtils.contains(prefijo, "__"))
			res = StringUtils.replace(prefijo, "__", GenericCommon.removeRareChars(identificador));
		
		res = replaceMasYMenos(res);
		res = GenericCommon.quitarEspacios(res);
		
		return res;
	}
	
	private String replaceMasYMenos(String cadena) {
		String res = cadena;
		if(StringUtils.contains(res, "+"))
			res = StringUtils.replace(res, "+", "Mas");
		else if(StringUtils.contains(res, "-"))
			res = StringUtils.replace(res, "-", "Menos");
		
		return res;
	}
	
	private List<String> replaceIdentificadorInPrefijoCompuesto(String prefijo, List<String> identificadores) { 
		
		List<String> tmp_identificadores = new ArrayList<String>();
		
		String tmp_prefijo = prefijo;
		String tmp_prefijo_fijo = "";
		
		if(StringUtils.contains(prefijo, "__")){
			
			List<Integer> ocurrencias = GenericCommon.listOccurrencesByString(prefijo, "__");
			
			String tmp_identificador_a_reemplazar= StringUtils.substring(prefijo, ocurrencias.get(0)-5, ocurrencias.get(0+1)+5);			
			String tmp_identificador_reemplazado = StringUtils.replace(tmp_identificador_a_reemplazar, "__", identificadores.get(0));
			
			tmp_prefijo_fijo = StringUtils.replace(tmp_prefijo, tmp_identificador_a_reemplazar, tmp_identificador_reemplazado);
			
			int ocurrences_pos = 2;
			
			for(int pos = 1;  pos < identificadores.size(); pos++){
								
				String i = GenericCommon.removeRareChars(GenericCommon.removeHexaChars(identificadores.get(pos)));
				
				tmp_identificador_a_reemplazar= StringUtils.substring(prefijo, ocurrencias.get(ocurrences_pos)-5, ocurrencias.get(ocurrences_pos+1)+5);			
				tmp_identificador_reemplazado = StringUtils.replace(tmp_identificador_a_reemplazar, "__", i);
				
				tmp_prefijo = StringUtils.replace(tmp_prefijo_fijo, tmp_identificador_a_reemplazar, tmp_identificador_reemplazado);
				tmp_identificadores.add(tmp_prefijo);
				
//				ocurrences_pos++;
//				pos_id++;
			}

		}

		return tmp_identificadores;
	}
		
	private String replaceIdentificadorInPrefijoX2(String prefijo, List<String> identificador) {
		
		String tmp_prefijo = prefijo;
		
		if(StringUtils.contains(prefijo, "__")){
			
			List<Integer> ocurrencias = GenericCommon.listOccurrencesByString(prefijo, "__");
			
			int pos_id = 0;
			
			for(int pos = 0;  pos <= identificador.size(); pos++){
								
				String i = GenericCommon.removeRareCharsNoSpace(GenericCommon.removeHexaChars(identificador.get(pos_id)));
				
				String tmp_identificador_a_reemplazar= StringUtils.substring(prefijo, ocurrencias.get(pos)-5, ocurrencias.get(pos+1)+5);			
				String tmp_identificador_reemplazado = StringUtils.replace(tmp_identificador_a_reemplazar, "__", i);
				
				tmp_prefijo = StringUtils.replace(tmp_prefijo, tmp_identificador_a_reemplazar, tmp_identificador_reemplazado);
				
				pos++;
				pos_id++;
			}

		}

		return tmp_prefijo;
	}
	
	private String replaceIdentificadorInPrefijoX3(String prefijo, List<String> identificadores){
	
		String tmp_prefijo = prefijo;
		
		if(StringUtils.contains(prefijo, "__")){
			
			int pos_id = 0;
			int pos_ocurrence = 0; 
			
			List<Integer> ocurrencias = GenericCommon.listOccurrencesByString(prefijo, "__");
			
			for(int pos = 0;  pos < identificadores.size(); pos++){
				
				String i = identificadores.get(pos_id);
				i = GenericCommon.removeRareChars(i);
				i = GenericCommon.removeHexaChars(i);
				
				String tmp_identificador_a_reemplazar= StringUtils.substring(prefijo, ocurrencias.get(pos_ocurrence)-5, ocurrencias.get(pos_ocurrence+1)+5);			
				String tmp_identificador_reemplazado = StringUtils.replace(tmp_identificador_a_reemplazar, "__", i);
				
				tmp_prefijo = StringUtils.replace(tmp_prefijo, tmp_identificador_a_reemplazar, tmp_identificador_reemplazado);
							
				pos_ocurrence = pos_ocurrence + 2;
				pos_id++;
			}
		}
		
		return tmp_prefijo;
	}
	
	public Object getMetodoDeclarado(String step, String data){
			
		StepParsed sp = UtilsParserDeepLearning.parseExcelToDiccionarioDeepLearning(contextObject, step);					
			
		StepCategorizado sc = new DiccionarioDeepLearning().getMachineLearningParse(sp.getStep());						

		Object o = null;
		MetodoDeclarado md = null;
		MetodoDeclaradoIncorrecto me = null;
		
		if(sc != null)
			o = definirMetodo(sp, sc, data);							
		else
			listadoMetodosTmp = new ArrayList<MetodoDeclarado>();
		
		return o;			
	}
	
	public StepParsed getStepCategorized(String step, String data){
		return UtilsParserDeepLearning.parseExcelToDiccionarioDeepLearning(contextObject, step);
	}
	
	public Object definirMetodo(StepParsed sp, StepCategorizado mlp, String sampleData) {
		
		int categoria = mlp.getCategoria();
		
		definirContextObject(sp.getStepFromExcel(), sampleData, null);
		String contexto 	 = contextObject.contexto;
		String tipoPaso 	 = identificarTipoDeStep(sp.getStepFromExcel());
		String prefijo		 = mlp.getPrefijoStepFramework();
		String step 		 = sp.getStep();
		String identificador = "";
		String parametro     = "";
		List<String> parametros = new ArrayList<String>();
		List<String> variablesAAsignar = new ArrayList<String>();
		
		boolean tieneParametro 			= sp.getParametros() != null && sp.getParametros().size() != 0;
		boolean tieneVariablesAAsignar	= sp.getVariablesAsignar() != null && sp.getVariablesAsignar().size() != 0;
		boolean tieneMasDeUnParametro 	= tieneParametro && sp.getParametros().size() > 1;
		
		Object o = null;
		listadoMetodos = (listadoMetodos == null ? new ArrayList<MetodoDeclarado>() : listadoMetodos);
		listadoMetodosTmp = new ArrayList<MetodoDeclarado>();
		
		if(categoria == 20){		// no tiene nada, el step tal cual es el metodo
			
			identificador = step;
			prefijo = GenericCommon.replaceAccents(identificador);
			
			List<String> params = devolverParametrosSiTieneSampleData(sampleData);
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijo, params, 0);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
			
		} else if(categoria == 0){	
						
			Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);
			boolean setRarePrefix = false;
			
			try{
				
				if(!StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "Lanzar el Terminal Financiero en la pantalla Home")){
					identificador 	= sp.getEntrecomillado_step().get(0);
					
					if(sp.getEntrecomillado_step().size() > 1){
						prefijo = replaceIdentificadorInPrefijo(prefijo,
								(identificador != null ? identificador +"_" : "") 
								+ GenericCommon.removeRareChars(GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(1))));
						setRarePrefix = true;
					}
				} else
					identificador = sp.getStepFromExcel();
				
			} catch(NullPointerException e) {
				if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiar") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotar")){
					identificador 	= sp.getVariablesAsignar().get(0);
				} else {
					identificador 	= parametros_clave.get(StringUtils.capitalize(sp.getParametros().get(0)));
				}
			}
			
			if(sp.getVariablesAsignar() != null && sp.getVariablesAsignar().size() != 0){
				for(String v : sp.getVariablesAsignar()){
					variablesAAsignar.add(v);
				}
			}
			
//			identificador = GenericCommon.reemplazarEspaciosYCapitalizar(identificador);
			identificador = GenericCommon.replaceAccents(identificador);
			identificador = GenericCommon.removeRareChars(identificador);
			identificador = StringUtils.capitalize(identificador);
			identificador = GenericCommon.reemplazarEspaciosYCapitalizar(identificador);
			
			if(!setRarePrefix)
				prefijo = replaceIdentificadorInPrefijo(prefijo, identificador);
				
			o = new MetodoDeclarado(contexto, tipoPaso, prefijo, "", "String", false, 0, variablesAAsignar);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);

						
		} else if(categoria == 1){		// 1 - Simple con 1 identificador y 1 parametro (1 metodo)
			
			Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);
			
			String tipoVariableAsignacion = "";
			boolean tieneVariableAsignacion = false;
			
			if(tieneParametro){
				if(sp.getEntrecomillado_step() != null)
					identificador 	= GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(0));
				else{
					// esto se hace para los casos: Escribir ${Valor_Billete} en el campo ${Billete}

					System.out.println("El step " + GenericCommon.removeHexaChars(sp.getStepFromExcel()) + " no tiene ningun identificador. ");
					return null;
				}
					
 
				try {
					
					if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatorio") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatoria")){
						parametro = "aleatorio";
					}

					if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "Anotar_Valores_para_Validacion")){
						variablesAAsignar.add("apunteContable");
						tipoVariableAsignacion = "OApunteContable1";
						tieneVariableAsignacion = true;
					} else if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiar") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotar")){
					
						if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "los valores")){
							variablesAAsignar.add(sp.getVariablesAsignar().get(0));
							tipoVariableAsignacion = "List<String>";
							tieneVariableAsignacion = true;
						} else {
							variablesAAsignar.add(sp.getVariablesAsignar().get(0));
							tipoVariableAsignacion = "String";
							tieneVariableAsignacion = true;
						}
					}
					
					if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiado") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotado")){
						
					} else { 
					
						if(!tieneMasDeUnParametro){
							parametro = parametros_clave.get(sp.getParametros().get(0));
							parametros.add(parametro);
							
							if(StringUtils.isNotEmpty(parametro))
								tieneParametro = true;
						}						
						
						else {
							
							for(int a = 0; a < sp.getParametros().size(); a++){
								parametro = parametros_clave.get(sp.getParametros().get(a));
								parametros.add(parametro);
							}
						}
					}
					
				} catch (NullPointerException e) {
					System.out.println("El parametro esta mal y no concuerdan las claves (testStepDescription y sampleData).");
				}
			}
			
			// si no tiene parametro: significa que viene en otro entrecomillado, por lo tanto hay que sacar el entrecomillado que identifica el campo;
			// habran otros casos donde el entrecomillado se haya de separar por otros factores como tabla, columna....
			
			else {
				
				if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatorio") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatoria")){
					identificador 	= GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(0));
					parametro = "aleatorio";
					parametros.add(parametro);
					
				} else if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "Anotar_Valores_para_Validacion")){
					variablesAAsignar.add("apunteContable");
					tipoVariableAsignacion = "OApunteContable1";
					tieneVariableAsignacion = true;
				
				}else if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiar") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotar")){

					if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "los valores")){
						variablesAAsignar.add(sp.getVariablesAsignar().get(0));
						tipoVariableAsignacion = "List<String>";
						tieneVariableAsignacion = true;
					} else {
						variablesAAsignar.add(sp.getVariablesAsignar().get(0));
						tipoVariableAsignacion = "String";
						tieneVariableAsignacion = true;
					}
				
				} else if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiado") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotado")){
					
				} else {
					
					if(sp.getEntrecomillado_step() != null)
						identificador 	= GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(0));
					
					// TODO si o si es necesario hacerlo con parametros, sino complica mucho la recogida de datos desde el test step.
					
					// hacer un metodo identificador de patrones....
					
					// deberia de ver como identificar campos """" despues del campo 
					
//					parametro = StringUtils.substringBefore(stepFromExcel, "campo");
//					parametro = StringUtils.substringBetween(stepFromExcel, "\"");
//					tmp_step = StringUtils.substringAfterLast(stepFromExcel, "campo");
//					tmp_step = StringUtils.contains(tmp_step, "desplegable") ? StringUtils.substringAfterLast(stepFromExcel, "desplegable ") : tmp_step;
//					tmp_step = StringUtils.contains(tmp_step, "calendario") ? StringUtils.substringAfterLast(stepFromExcel, "calendario ") : tmp_step;
//					tmp_step = StringUtils.contains(tmp_step, "el valor") ? StringUtils.substringAfterLast(stepFromExcel, "el valor ") : tmp_step;
//					
//					identificador = GenericCommon.reemplazarEspaciosYCapitalizarCadena(GenericCommon.removeHexaChars(StringUtils.substringBetween(tmp_step, "\"")));
				}
				

				if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "Anotar_Valores_para_Validacion")){
					variablesAAsignar.add("apunteContable");
					tipoVariableAsignacion = "OApunteContable1";
					tieneVariableAsignacion = true;
				}
				
				if(StringUtils.isNotEmpty(parametro))
					tieneParametro = true;
				
			}
				
			for(int a = 0; a < parametros.size(); a++) {
				
				String p = parametros.get(a);
//				p = GenericCommon.separarPorLetrasCapitales(p);	// al separar por letras capitales tambien separa por accentos // hay que mirar regex que descarge accentos
				
				if(p != null && p.length() > 1)
					if(StringUtils.equals(p.charAt(1)+"", " ")){
						p = "\"" + StringUtils.substring(p, 2, p.length());
					}
								
				if(!StringUtils.contains(p, "\"")){
					p = "\"" + p + "\"";
				}
				
				parametros.set(a, p);
			}
			
			prefijo  = replaceIdentificadorInPrefijo(prefijo, identificador);
			
			if(tieneVariableAsignacion)
				o = new MetodoDeclarado(contexto, tipoPaso, prefijo, parametros, tipoVariableAsignacion, false, 1, variablesAAsignar);
			else
				o = new MetodoDeclarado(contexto, tipoPaso, prefijo, parametros, 1);
			
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
			
		} else if(categoria == 7){
			
			// hay casos por ejemplo: ""Verificar que el campo "N�mero de pr�stamo" tiene el valor copiado""
			// donde el valor no va a venir de aqui, as� que hay que tratarlo
									
			Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);
			
			if(!StringUtils.contains(sp.getStepFromExcel(), "$")){
				identificador 	= GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(1));
				parametro 		= GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(0));

			
			} else {
		
				identificador 	= GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(0));
				
				// en este caso se puede dar el caso que no tenga porque venir un valor por parametro, por lo tanto escogemos la segunda opcion del entrecomillado
				if(sp.getParametros() != null && sp.getParametros().size() != 0){
					try {
						if(sp.getParametros().get(0) != null){
							parametro     	= parametros_clave.get(StringUtils.capitalize(sp.getParametros().get(0)));
							if(StringUtils.isNotEmpty(parametro))
								tieneParametro = true;
						}
					} catch (NullPointerException e) {
						parametro = GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(0));
					}
			
					
				} else {
					// esto se podria sacar fuera... revisar!
					if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatorio") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatoria")){
						parametro = "aleatorio";
					} else if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiado") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotado")){
						
					} else {
						parametro 		= sp.getEntrecomillado_step().get(1);
					}
				}
			}
			
			parametro = GenericCommon.separarPorLetrasCapitales(parametro);	// al separar por letras capitales tambien separa por accentos // hay que mirar regex que descarge accentos
			
			if(!StringUtils.contains(parametro, "\"")){
				parametro = "\"" + parametro + "\"";
			}
						
			prefijo  = replaceIdentificadorInPrefijo(prefijo, identificador);
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijo, parametro, tieneParametro, 7);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);

		} else if(categoria == 2){		// 2 - Simple con 1 identificador y N parametro (1 metodo)
					
			String split_lado_izquierdo = "";
			
			int count_posicion_inicial_entrecomilldo = 0;
			int count = 0;
			
			// si tiene ":" y "," puede que especifique en "donde" antes de "," con lo cual ...
			if(StringUtils.contains(sp.getStepFromExcel(), ":") || StringUtils.contains(sp.getStepFromExcel(), ",")){
				
				if(StringUtils.contains(sp.getStepFromExcel(), ":") && StringUtils.contains(sp.getStepFromExcel(), ",")){
					if(StringUtils.contains(StringUtils.split(sp.getStepFromExcel(), ",")[0], "\""))
						count_posicion_inicial_entrecomilldo = 1;
					else
						count_posicion_inicial_entrecomilldo = 0;
					
				}else if (StringUtils.contains(sp.getStepFromExcel(), ":")) {
					split_lado_izquierdo = StringUtils.split(sp.getStepFromExcel(), ":")[0];
				
				}else if(StringUtils.contains(sp.getStepFromExcel(), ",")) {
					split_lado_izquierdo = StringUtils.split(sp.getStepFromExcel(), ",")[0];
				}
				
				
				identificador = (StringUtils.contains(split_lado_izquierdo, "\"") ? sp.getEntrecomillado_step().get(count_posicion_inicial_entrecomilldo) : sp.getEntrecomillado_step().get(0));
				count = identificador != null ? count_posicion_inicial_entrecomilldo+1 : count_posicion_inicial_entrecomilldo;
				
			}
			
			Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);
			
			if(tieneParametro)
				for(int a = count; a < sp.getParametros().size(); a++)
					parametros.add(parametros_clave.get(sp.getParametros().get(a)));
			else 
				for(int a = count; a < sp.getEntrecomillado_step().size(); a++){
					if(!StringUtils.contains(sp.getEntrecomillado_step().get(a), "\""))
						parametros.add("\"" + sp.getEntrecomillado_step().get(a) + "\"");
				}
			
			prefijo  = replaceIdentificadorInPrefijo(prefijo, identificador);
			
//			for(int a = 0; a < parametros.size(); a++)
//				parametros.set(a, GenericCommon.separarPorLetrasCapitales(parametros.get(a)));
			
//			for(String param : parametros)
//				if(StringUtils.contains(param, "\""))
//					parametro += "\"" + param + "\",";
			
			if(tieneVariablesAAsignar)
				if((StringUtils.contains(step, " m�s ") || StringUtils.contains(step, " menos ")) && StringUtils.contains(step, " tiene el valor "))
					parametros.add(sp.getVariablesAsignar().get(0));
					
			
//			parametro = StringUtils.substring(parametro, 0, parametro.length()-2) + "\"";
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijo, parametros, 2);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);

		} else if(categoria == 22){		// 22 - Simple con 2 identificadores y N parametros
			
			String split_lado_izquierdo = "";
			
			int count_posicion_inicial_entrecomilldo = 2;
		
			
			identificador = (StringUtils.contains(split_lado_izquierdo, "\"") ? sp.getEntrecomillado_step().get(count_posicion_inicial_entrecomilldo) : sp.getEntrecomillado_step().get(0));
			
			List<String> parametros_clave = devolverParametrosMapeadosInArray(sampleData);
						
			

//			identificador = sp.getEntrecomillado_step().get(0);			
//			int count = identificador != null ? count_posicion_inicial_entrecomilldo+1 : count_posicion_inicial_entrecomilldo;
		
			// en este caso se puede dar el caso que no tenga porque venir un valor por parametro, por lo tanto escogemos la segunda opcion del entrecomillado
//			
//			if(sp.getParametros() != null && sp.getParametros().size() != 0)
//				for(int a = count; a < sp.getParametros().size(); a++)
//					parametros.add(sp.getParametros().get(a));
//			else 
//				for(int a = count; a < sp.getEntrecomillado_step().size(); a++)
//					parametros.add(sp.getEntrecomillado_step().get(a));
			
			// si es mayor a dos significa que habr� mas de un metodo...
			if(sp.getEntrecomillado_step().size() > 2)		{
				
				for(int a = 1; a < sp.getEntrecomillado_step().size(); a++){
					List<String> ids = new ArrayList<String>();
					ids.add(identificador);
					ids.add(sp.getEntrecomillado_step().get(a));
					prefijo  = replaceIdentificadorInPrefijoX2(prefijo, ids);
					
					if(parametros_clave.size() != 0) {
						if(!StringUtils.contains(parametros_clave.get(a-1), "\""))
							parametros.add("\"" + parametros_clave.get(a-1) + "\"");
						else 
							parametros.add(parametros_clave.get(a-1));
						
						
//						TODO
//						aqui hay que hacer otra validacion de si no tiene variablesDeAsignacion y si no es copiar rollo:
//						if(variablesAAsignar != null && variablesAAsignar.size() > 0 
//								&& (StringUtils.contains(sp.getStepFromExcel(), "copiar") || StringUtils.contains(sp.getStepFromExcel(), "anotar")){}
						
					} else {
						// no hace falta que tenga parametros.
						System.err.println("El paso '" + sp.getStepFromExcel() + "' no encuentra parametros.");
					}
						
					for(int ae = 0; a < parametros.size(); ae++)
						if(!StringUtils.contains(parametros.get(ae), "\""))
							parametros.set(ae, "\"" + parametros.get(ae) + "\"");

					o = new MetodoDeclarado(contexto, tipoPaso, prefijo, parametros, 2);
					listadoMetodos.add((MetodoDeclarado) o);
					listadoMetodosTmp.add((MetodoDeclarado) o);
					parametro = "";
					prefijo = mlp.getPrefijoStepFramework();
				}
				
			} else {
				
				List<String> ids = new ArrayList<String>();
				ids.add(sp.getEntrecomillado_step().get(0));
				ids.add(sp.getEntrecomillado_step().get(1));
		
				prefijo  = replaceIdentificadorInPrefijoX2(prefijo, ids);
				
				for(count_posicion_inicial_entrecomilldo = 2; count_posicion_inicial_entrecomilldo <sp.getEntrecomillado_step().size(); count_posicion_inicial_entrecomilldo++)
					parametros.add(sp.getEntrecomillado_step().get(count_posicion_inicial_entrecomilldo));
				
				for(String param : parametros)
					parametro += "\"" + param + "\",";
				
				parametro = StringUtils.substring(parametro, 0, parametro.length()-2) + "\"";

				o = new MetodoDeclarado(contexto, tipoPaso, prefijo, parametro, 2);
				listadoMetodos.add((MetodoDeclarado) o);
				listadoMetodosTmp.add((MetodoDeclarado) o);
				
			}
			

			
			
		} else if(categoria == 3){		// 3 - Simple con 2 identificadores y 1 parametro (1 metodo)
						
//			tieneParametro = sp.getParametros() != null && sp.getParametros().size() != 0;
//			
//			if(!tieneParametro){
//				
//			} else {
//				
//			}			
			
			Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);
				
			List<String> prefijos = new ArrayList<>();
			
			if(sp.getEntrecomillado_step().size()  == 1)
				prefijos.add(replaceIdentificadorInPrefijo(prefijo, sp.getEntrecomillado_step().get(0)));
			else if(sp.getEntrecomillado_step().size() > 1){
				prefijos = replaceIdentificadorInPrefijoCompuesto(prefijo, sp.getEntrecomillado_step());
			}
			
			// hacer for para los prefijos
			
			if(sp.getParametros() != null && sp.getParametros().size() != 0){
				
				try{
					if(sp.getParametros().get(0) != null){
						parametro     	= parametros_clave.get(StringUtils.capitalize(sp.getParametros().get(0)));
						if(StringUtils.isNotEmpty(parametro))
							tieneParametro = true;
					}
				} catch(NullPointerException e) {
					
				}
					
			} else {
				
				// esto se podria sacar fuera... revisar!
				if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatorio") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "aleatoria")){
					parametro = "aleatorio";
				}
//				else{
//					parametro 		= sp.getEntrecomillado_step().get(2);
//				}
			}
			
			parametro = GenericCommon.separarPorLetrasCapitales(parametro);	// al separar por letras capitales tambien separa por accentos // hay que mirar regex que descarge accentos
			
			if(!StringUtils.contains(parametro, "\""))
				parametro = "\"" + parametro + "\"";
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijos.get(0), parametro, 3);
			
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
						
			
		} else if(categoria == 4){      // 4 - Compuesto con 1 identificador (> 1 metodo)
			
			String split_lado_izquierdo = StringUtils.split(sp.getStepFromExcel(), ":")[0];
			identificador = (StringUtils.contains(split_lado_izquierdo, "\"") ? sp.getEntrecomillado_step().get(0) : null);
			
			String tipoVariableAsignacion = "";
			boolean tieneVariableAsignacion = false;
			
			if(sp.getEntrecomillado_step() != null) {
				
				int count = identificador != null ? 1 : 0;
				boolean haveId = count == 1;
				
				while(count < sp.getEntrecomillado_step().size()){
									
					String prefijotmp = replaceIdentificadorInPrefijo(prefijo,
							(identificador != null ? identificador +"_" : "") 
							+ GenericCommon.removeRareChars(GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(count))));
	
					if(tieneVariablesAAsignar)
					
						if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "copiar") || StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "anotar")){
							
							
							// List<String> NIF = depositos.steps.copiarDeLaTablaMantenimientoDeIntervinientes_NifLosValoresDeLaColumna();
							
							if(StringUtils.containsIgnoreCase(sp.getStepFromExcel(), "los valores de la tabla")){
								variablesAAsignar.add(GenericCommon.reemplazarEspaciosYCapitalizar(sp.getVariablesAsignar().get((!haveId ? count : count-1))));
								tipoVariableAsignacion = "List<String>";
								tieneVariableAsignacion = true;
							} else {
								variablesAAsignar.add(GenericCommon.reemplazarEspaciosYCapitalizar(sp.getVariablesAsignar().get((!haveId ? count : count-1))));
								tipoVariableAsignacion = "String";
								tieneVariableAsignacion = true;
							}
						}
					
					parametro = null;
					o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametro, tipoVariableAsignacion, false, 4, variablesAAsignar);
					listadoMetodos.add((MetodoDeclarado) o);
					listadoMetodosTmp.add((MetodoDeclarado) o);
					count++;
					variablesAAsignar = new ArrayList<String>();
				} 
				
			} else {
				
				o = new MetodoDeclaradoIncorrecto(contexto, tipoPaso, "", "Falta entrecomillado", 4);
				// error, se esperaban entrecomillados y no hay...
			}
			
		} else if(categoria == 14) {
								
			String split_lado_izquierdo = StringUtils.split(sp.getStepFromExcel(), ":")[0];
			identificador = (StringUtils.contains(split_lado_izquierdo, "\"") ? sp.getEntrecomillado_step().get(0) : null);
						
			if(sp.getEntrecomillado_step() != null) {
				
				int count = identificador != null ? 2 : 0;
				
				String id1= sp.getEntrecomillado_step().get(0);
				String id2= sp.getEntrecomillado_step().get(1);
				
				while(count < sp.getEntrecomillado_step().size()){
													
					String prefijotmp = replaceIdentificadorInPrefijo(prefijo,
								id1 + "_" + id2 + "__" + GenericCommon.removeRareChars(GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(count))));
	
					parametro = null;
					o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametro, 4);
					
					listadoMetodos.add((MetodoDeclarado) o);
					listadoMetodosTmp.add((MetodoDeclarado) o);
					count++;
				} 
			} else {
				
				o = new MetodoDeclaradoIncorrecto(contexto, tipoPaso, "", "Falta entrecomillado", 4);
				// error, se esperaban entrecomillados y no hay...
			}
				
		} else if(categoria == 5){		// 5 - Compuesto con 1 identificador y 1 parametro (> 1 metodo)
			
//			if(!tieneParametro){
//						
//				List<String> comillas = GenericCommon.listEntrecomillados(stepFromExcel);
//				
//				identificador = StringUtils.substringBefore(stepFromExcel, "los valores");
//				sp.setEntrecomillado_step(comillas);
//								
//				for(int a = 0; a < sp.getEntrecomillado_step().size(); a++){
//					comillas.remove(sp.getEntrecomillado_step().get(a));
//				}
//				
//				sp.setParametros(comillas);
//				
//				tieneParametro = true;
//
//			}
			
			
			for(int a = 0; a < sp.getEntrecomillado_step().size(); a++){
					
				if(!tieneVariablesAAsignar){
					Map<String, String> parametros_clave = tieneParametro ? devolverParametrosMapeados(sampleData) : null;
					
					if(parametros_clave != null){
						String parametro_clave = sp.getParametros().get(a);
						parametro  	  = parametros_clave.get(StringUtils.capitalize(parametro_clave));
					}
									
				} else if(tieneVariablesAAsignar){
					
					if(sp.getVariablesAsignar() != null)
						parametro = sp.getVariablesAsignar().get(a);
					
				}
					
				identificador = sp.getEntrecomillado_step().get(a);
				
				String prefijotmp = replaceIdentificadorInPrefijo(prefijo, identificador);

				o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametro, 5);
				listadoMetodos.add((MetodoDeclarado) o);
				listadoMetodosTmp.add((MetodoDeclarado) o);
										
			}
			
		} else if(categoria == 6){		// 6 - Compuesto con 2 identificadores y N parametro (> 1 metodo)
			
			
			
			
			
			
			
			
			
			
			
		} else if(categoria == 9) {		// 9 - Simple con 3 identificadores y 2 parametro (1 metodo)

			String prefijotmp = replaceIdentificadorInPrefijoX3(prefijo, sp.getEntrecomillado_step());
						
			if(tieneParametro){
				
				Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);	
									
				if(!sp.getStepFromExcel().contains("<<")){
					
					for(int a = 0; a < sp.getParametros().size(); a++){
						String parametro_clave = sp.getParametros().get(a);
						parametros.add(parametros_clave.get(StringUtils.capitalize(parametro_clave)));
					}
						
				} else if(sp.getStepFromExcel().contains("<<")){
					
				}
				
			}
			
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametros, 5);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
			
			
			
		} else if(categoria == 13) {	// 13 - Simple con 2 identificadores (1 metodo)
	
			String prefijotmp = replaceIdentificadorInPrefijo(prefijo,
					sp.getEntrecomillado_step().get(0) +"_" + GenericCommon.removeRareChars(GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(1))));
						
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametros, 5);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
			
		} else if(categoria == 10){		// 10 - Simple con 2 identificador y N parametro (1 metodo)
						
			Map<String, String> parametros_clave = devolverParametrosMapeados(sampleData);	
			
			System.out.println("++" + sp.getStepFromExcel());
			for(int a = 0; a < sp.getParametros().size(); a++){
				String parametro_clave = StringUtils.capitalize(sp.getParametros().get(a));
				parametros.add(parametros_clave.get(parametro_clave));
			}
			
			String prefijotmp = replaceIdentificadorInPrefijoX2(prefijo, sp.getEntrecomillado_step());
			
			o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametros, 5);
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
			
		} else if(categoria == 11){		// 11 - Compuesto con 2 identificador y parametros por variables (> 1 metodo)
				
			String split_lado_izquierdo = StringUtils.split(sp.getStepFromExcel(), ":")[0];
			identificador = (StringUtils.contains(split_lado_izquierdo, "\"") ? sp.getEntrecomillado_step().get(0) : null);
						
			
			if(sp.getEntrecomillado_step() != null) {
				
				int count = identificador != null ? 1 : 0;
				boolean haveId = count == 1;
				
				while(count < sp.getEntrecomillado_step().size()){
						
					List<String> ids = new ArrayList<String>();
					ids.add(identificador);
					ids.add(sp.getEntrecomillado_step().get(count));
					
					String prefijotmp = replaceIdentificadorInPrefijoX2(prefijo, ids);

					if(tieneVariablesAAsignar){
						variablesAAsignar.add(GenericCommon.reemplazarEspaciosYCapitalizar(sp.getVariablesAsignar().get((haveId ? count-1 : count))));
					}

					parametro = null;
					o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametro, "String", true, 4, variablesAAsignar);
					
					listadoMetodos.add((MetodoDeclarado) o);
					listadoMetodosTmp.add((MetodoDeclarado) o);
					count++;
				} 
			} else {
				
				o = new MetodoDeclaradoIncorrecto(contexto, tipoPaso, "", "Falta entrecomillado", 4);
				// error, se esperaban entrecomillados y no hay...
			}
			
			// otro caso
			
//			if(sp.getEntrecomillado_step() != null) {
//				
//				int count = identificador != null ? 1 : 0;
//				
//				while(count < sp.getEntrecomillado_step().size()){
//									
//					String prefijotmp = replaceIdentificadorInPrefijo(prefijo,
//							(identificador != null ? identificador +"_" : "") 
//							+ GenericCommon.removeRareChars(GenericCommon.removeHexaChars(sp.getEntrecomillado_step().get(count))));
//	
//					parametro = null;
//					o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametro, 4);
//					
//					listadoMetodos.add((MetodoDeclarado) o);
//					listadoMetodosTmp.add((MetodoDeclarado) o);
//					count++;
//				} 
//			}
			
		} else if(categoria == 21){		// 21 - Simple con 2 identificador y N parametros (uno de ellos es parametro)
			
			
			List<String> ids = new ArrayList<String>();
			ids.add(sp.getEntrecomillado_step().get(0));
			ids.add(sp.getParametros().get(0));
			
			String prefijotmp = replaceIdentificadorInPrefijoX2(prefijo, ids);
			if(tieneVariablesAAsignar){
				for(String variables : sp.getVariablesAsignar())
					parametros.add(variables);
			}

			parametro = null;
			o = new MetodoDeclarado(contexto, tipoPaso, prefijotmp, parametros, 4);
			
			listadoMetodos.add((MetodoDeclarado) o);
			listadoMetodosTmp.add((MetodoDeclarado) o);
			
			
			
		}
		
		
		return o;
		
	}
	
	private boolean tieneParametroVinculado(String stepFromExcel) {
		return StringUtils.contains(stepFromExcel, "<") || !StringUtils.contains(stepFromExcel, ">");
	}
	
	public List<MetodoDeclarado> getCurrentListadoMetodosByTestStep() {
		return listadoMetodosTmp;				
	}
		
	private void instanciaObjetoSiNoExiste(String excel_step, String data_step, String expected_result) {

		ContextoObject tmp = contextObject;
		
		definirContextObject(excel_step, data_step, expected_result);
		
		if(contextObject != null)
			if(!contextObject.controllerStr.isEmpty())
				if(tmp == null || !contextObject.controllerStr.toString().equals(tmp.controllerStr.toString())){
					instanciaContextObjectParaTestCase(contextObject);
					instanciaImportsPackageParaTestCase(contextObject);
				}
	}
	
	@Override
	protected void instanciaImportsPackageParaTestCase(ContextoObject co) {
		
		if(!this.class_importsDeclarados.contains("org.junit.Test"))
			this.class_importsDeclarados.add("org.junit.Test");
		
		if(!this.class_importsDeclarados.contains("org.junit.Before"))
			this.class_importsDeclarados.add("org.junit.Before");			
		
		if(!this.class_importsDeclarados.contains("com.testing_web.sogeti.___abstraccion_generica.AbstractBaseTestCase"))
			this.class_importsDeclarados.add("com.testing_web.sogeti.___abstraccion_generica.AbstractBaseTestCase");
		
		super.instanciaImportsPackageParaTestCase(co);
		
	}
		
//	private void escribirMetodoEnCuerpoDelTestCase(String excel_step, String sample_data) {
//		
//		if (tieneValidacionesTestStep(excel_step))
//			guardarMetodoEnCuerpoTestCase(excel_step, devolverValidacionesSiTieneSegunExcelStep(excel_step));
//		
//		else if (tieneParametrosSampleData(sample_data))
//			guardarMetodoEnCuerpoTestCase(excel_step, devolverParametrosSiTieneSampleData(sample_data));
//		
//		else
//			guardarMetodoEnCuerpoTestCase(excel_step, null);
//		
//	}
//	
//	private void escribirMetodoEnCuerpoDelTestCase_deepLearning(String excel_step, String step_deepLearning, String methoddlp, String sample_data) {
//		
//		if (tieneValidacionesTestStep(excel_step))
//			guardarMetodoEnCuerpoTestCase_deepLearning(step_deepLearning, methoddlp, null, devolverValidacionesSiTieneSegunExcelStep(excel_step));
//		
//		else if (tieneParametrosSampleData(sample_data))
//			guardarMetodoEnCuerpoTestCase_deepLearning(step_deepLearning, methoddlp, null, devolverParametrosSiTieneSampleData(sample_data));
//		
//		else
//			guardarMetodoEnCuerpoTestCase_deepLearning(step_deepLearning, methoddlp, null, null);
//		
//	}
	
	public void generarMetodoTestCase() {
		
		if(existe_parseado){
		
			MethodDeclaration metodo = getMethodDeclaration("public", "void", tc_nombre_metodo, "Test", new Exception());
			metodo.setBody(cuerpoMetodoDeclarado);
			tc_metodosDeclarados.add(metodo);
			
			resetMetodoAnotacion();
			resetMetodoArgumento();
			resetMetodoLlamada();
		} 
	}
	
	public void generarMetodosSobreescritos() {
		MethodDeclaration method = getMethodDeclaration("public", tc_tipoReturn, tc_nombre_metodo, this.tc_anotaciones, this.tc_exception);
		
		for(Parameter param : this.tc_parametrosMetodo)
			method.addParameter(param);
		
		method.setBody(this.cuerpoMetodoDeclarado);
		this.tc_metodosDeclarados.add(method);
		
		this.tc_anotaciones = new ArrayList<String>();
		this.tc_parametrosMetodo  = new ArrayList<Parameter>();
		this.cuerpoMetodoDeclarado = new BlockStmt();
		
	}
	
	
	
	
}
