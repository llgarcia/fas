package com.testing_web.sogeti.___global_tools.parser.deep_learning;

import lombok.Getter;
import lombok.Setter;

public class MetodoDeclaradoIncorrecto {

	@Getter @Setter	private String contexto;	
	@Getter @Setter	private String tipoMetodo;	
	@Getter @Setter	private String llamadaMetodo;
	@Getter @Setter	private Integer categoria;
	@Getter @Setter	private String error;
	
	public MetodoDeclaradoIncorrecto(String contexto, String tipoMetodo, String llamadaMetodo, String error, Integer categoria) {
		this.contexto = contexto;
		this.tipoMetodo = tipoMetodo;
		this.llamadaMetodo = llamadaMetodo;
		this.error = error;
		this.categoria = categoria;
	}
	
	
	
}
